# Installs Persian Video Studio into Claude Code (Windows). Run from the unzipped folder:
#   powershell -ExecutionPolicy Bypass -File install.ps1
$src = $PSScriptRoot
$dst = Join-Path $env:USERPROFILE ".claude\skills\persian-video-studio"
New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
if ((Resolve-Path $src).Path -ne $dst) { Copy-Item -Recurse -Force $src $dst }
"Installed to $dst - restart Claude, then ask: «ابزارهای استودیوی فارسی رو چک کن»"
