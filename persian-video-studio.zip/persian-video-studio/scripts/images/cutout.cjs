// Cut a painted illustration out of its flat white background, keeping soft dry-brush edges.
// Background = near-white pixels connected to the image border (flood fill). Pixels in that region
// get alpha from their distance to white (so faint brush fringes fade out) and the white is unmixed
// from their colour; everything else stays opaque. Optional split: each separate object (after
// merging parts closer than `gap` px) is written as its own trimmed PNG, sorted top-to-bottom, left-to-right.
// usage: node cutout.cjs in.png outBase [T=26] [soft=60] [split=0] [gap=40] [minArea=4000] [pad=12]
const { execFileSync } = require("child_process");
const fs = require("fs");
const { FF: FFMPEG, FFP: FFPROBE } = require("../lib/ff.cjs");
const [, , inp, outBase, tArg = "26", softArg = "60", splitArg = "0", gapArg = "40", minArg = "4000", padArg = "12", holeArg = "0"] = process.argv;
const HOLEMIN = +holeArg; // >0: enclosed near-white regions at least this many px are background too (holes); 0 keeps them
const T = +tArg, SOFT = +softArg, SPLIT = +splitArg, GAP = +gapArg, MINA = +minArg, PAD = +padArg;
const [W, H] = execFileSync(FFPROBE, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", inp]).toString().trim().split(",").map(Number);
const rgb = execFileSync(FFMPEG, ["-v", "error", "-i", inp, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], { maxBuffer: 1 << 30 });
const N = W * H;
const d = new Uint8Array(N);
for (let i = 0; i < N; i++) d[i] = 255 - Math.min(rgb[3 * i], rgb[3 * i + 1], rgb[3 * i + 2]);
const bg = new Uint8Array(N);
const st = [];
const push = (i) => { if (bg[i] || d[i] >= T) return; bg[i] = 1; st.push(i); };
for (let x = 0; x < W; x++) { push(x); push((H - 1) * W + x); }
for (let y = 0; y < H; y++) { push(y * W); push(y * W + W - 1); }
while (st.length) { const i = st.pop(); const x = i % W; if (x > 0) push(i - 1); if (x < W - 1) push(i + 1); if (i >= W) push(i - W); if (i < N - W) push(i + W); }
if (HOLEMIN > 0) {
  const seen = new Uint8Array(N);
  for (let s = 0; s < N; s++) {
    if (bg[s] || seen[s] || d[s] >= T) continue;
    const comp = [s]; seen[s] = 1; const q = [s];
    while (q.length) { const i = q.pop(); const x = i % W; const nb = [x > 0 ? i - 1 : -1, x < W - 1 ? i + 1 : -1, i >= W ? i - W : -1, i < N - W ? i + W : -1];
      for (const n of nb) if (n >= 0 && !seen[n] && !bg[n] && d[n] < T) { seen[n] = 1; q.push(n); comp.push(n); } }
    if (comp.length >= HOLEMIN) for (const i of comp) bg[i] = 1;
  }
}
// soft fringe: pixels within 2px of the background region that are not bg themselves get alpha by whiteness
const near = new Uint8Array(N);
for (let i = 0; i < N; i++) if (bg[i]) { const x = i % W, y = (i / W) | 0; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { const xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < W && yy < H) near[yy * W + xx] = 1; } }
const rgba = Buffer.alloc(N * 4);
for (let i = 0; i < N; i++) {
  let a;
  if (bg[i]) a = 0; else if (near[i]) a = Math.min(1, d[i] / SOFT); else a = 1;
  let r = rgb[3 * i], g = rgb[3 * i + 1], b = rgb[3 * i + 2];
  if (a > 0 && a < 1) { r = Math.max(0, Math.min(255, (r - (1 - a) * 255) / a)); g = Math.max(0, Math.min(255, (g - (1 - a) * 255) / a)); b = Math.max(0, Math.min(255, (b - (1 - a) * 255) / a)); }
  rgba[4 * i] = r; rgba[4 * i + 1] = g; rgba[4 * i + 2] = b; rgba[4 * i + 3] = Math.round(a * 255);
}
function writePng(buf, w, h, file) {
  execFileSync(FFMPEG, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${w}x${h}`, "-i", "-", "-frames:v", "1", file], { input: buf, maxBuffer: 1 << 30 });
}
function crop(x0, y0, x1, y1, mask) {
  const w = x1 - x0, h = y1 - y0, o = Buffer.alloc(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const si = (y0 + y) * W + (x0 + x), di = (y * w + x) * 4;
    if (mask && !mask[si]) continue;
    rgba.copy(o, di, si * 4, si * 4 + 4);
  }
  return { o, w, h };
}
if (!SPLIT) {
  let x0 = W, y0 = H, x1 = 0, y1 = 0;
  for (let i = 0; i < N; i++) if (rgba[4 * i + 3] > 8) { const x = i % W, y = (i / W) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  x0 = Math.max(0, x0 - PAD); y0 = Math.max(0, y0 - PAD); x1 = Math.min(W, x1 + PAD + 1); y1 = Math.min(H, y1 + PAD + 1);
  const c = crop(x0, y0, x1, y1);
  writePng(c.o, c.w, c.h, outBase + ".png");
  console.log(JSON.stringify({ file: outBase + ".png", w: c.w, h: c.h, box: [x0, y0, x1, y1] }));
} else {
  // components over a coarse grid (cell = GAP/2) so nearby specks merge with their object
  const cs = Math.max(4, Math.round(GAP / 2)), gw = Math.ceil(W / cs), gh = Math.ceil(H / cs);
  const occ = new Uint8Array(gw * gh);
  for (let i = 0; i < N; i++) if (rgba[4 * i + 3] > 20) occ[((((i / W) | 0) / cs) | 0) * gw + (((i % W) / cs) | 0)] = 1;
  const lab = new Int32Array(gw * gh).fill(-1);
  const comps = [];
  for (let s = 0; s < gw * gh; s++) {
    if (!occ[s] || lab[s] >= 0) continue;
    const id = comps.length, q = [s]; lab[s] = id; let cells = [];
    while (q.length) { const c = q.pop(); cells.push(c); const cx = c % gw, cy = (c / gw) | 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const nx = cx + dx, ny = cy + dy; if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue; const n = ny * gw + nx; if (occ[n] && lab[n] < 0) { lab[n] = id; q.push(n); } } }
    comps.push(cells);
  }
  const out = [];
  comps.forEach((cells, id) => {
    let x0 = W, y0 = H, x1 = 0, y1 = 0, area = 0;
    const mask = new Uint8Array(N);
    for (const c of cells) { const cx = (c % gw) * cs, cy = ((c / gw) | 0) * cs;
      for (let y = cy; y < Math.min(H, cy + cs); y++) for (let x = cx; x < Math.min(W, cx + cs); x++) { const i = y * W + x; if (rgba[4 * i + 3] > 0) { mask[i] = 1; area++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; } } }
    if (area < MINA) return;
    out.push({ x0, y0, x1, y1, area, mask });
  });
  // reading order: rows by centre y (row break when vertical gap), then x
  out.sort((a, b) => { const ay = (a.y0 + a.y1) / 2, by = (b.y0 + b.y1) / 2; if (Math.abs(ay - by) > H * 0.18) return ay - by; return (a.x0 + a.x1) / 2 - (b.x0 + b.x1) / 2; });
  out.forEach((c, k) => {
    const x0 = Math.max(0, c.x0 - PAD), y0 = Math.max(0, c.y0 - PAD), x1 = Math.min(W, c.x1 + PAD + 1), y1 = Math.min(H, c.y1 + PAD + 1);
    const r = crop(x0, y0, x1, y1, c.mask);
    const f = `${outBase}-${k + 1}.png`;
    writePng(r.o, r.w, r.h, f);
    console.log(JSON.stringify({ file: f, w: r.w, h: r.h, box: [x0, y0, x1, y1], area: c.area }));
  });
}
