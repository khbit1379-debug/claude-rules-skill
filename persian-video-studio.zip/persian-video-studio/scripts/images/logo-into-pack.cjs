// Put the real Abish logo (rotated like on the wrapper, charcoal monochrome) into the empty oval of the pack sketch.
// usage: node logo-into-pack.cjs pack.png logo.png out.png cx cy scale
const { execFileSync } = require("child_process");
const { FF: FFMPEG, FFP: FFPROBE } = require("../lib/ff.cjs");
const [, , packP, logoP, outP, cxA, cyA, kA] = process.argv;
const size = (p) => execFileSync(FFPROBE, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", p]).toString().trim().split(",").map(Number);
const [PW, PH] = size(packP);
const [LW0, LH0] = size(logoP);
const k = +kA;
const LW = Math.round(LH0 * k), LH = Math.round(LW0 * k); // rotated 90° CCW
const logo = execFileSync(FFMPEG, ["-v", "error", "-i", logoP, "-vf", `transpose=2,scale=${LW}:${LH}:flags=lanczos`, "-f", "rawvideo", "-pix_fmt", "rgba", "-"], { maxBuffer: 1 << 26 });
const pack = execFileSync(FFMPEG, ["-v", "error", "-i", packP, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], { maxBuffer: 1 << 28 });
const ink = [0x17, 0x13, 0x0f], light = [0xf4, 0xf1, 0xea];
const ox = Math.round(+cxA - LW / 2), oy = Math.round(+cyA - LH / 2);
for (let y = 0; y < LH; y++) for (let x = 0; x < LW; x++) {
  // inner ellipse only: drops the gold ring and the violet corners
  const ex = (x + 0.5 - LW / 2) / (LW / 2 * 0.86), ey = (y + 0.5 - LH / 2) / (LH / 2 * 0.88);
  const d = Math.sqrt(ex * ex + ey * ey);
  const a = Math.max(0, Math.min(1, (1 - d) * 18));
  if (a <= 0) continue;
  const i = (y * LW + x) * 4;
  const lum = (0.299 * logo[i] + 0.587 * logo[i + 1] + 0.114 * logo[i + 2]) / 255;
  const t = Math.max(0, Math.min(1, (lum - 0.42) / (0.85 - 0.42))); // green -> ink, lettering -> light
  const px = ox + x, py = oy + y;
  if (px < 0 || py < 0 || px >= PW || py >= PH) continue;
  const j = (py * PW + px) * 3;
  for (let c = 0; c < 3; c++) {
    const v = ink[c] + (light[c] - ink[c]) * t;
    pack[j + c] = Math.round(pack[j + c] * (1 - a) + v * a);
  }
}
execFileSync(FFMPEG, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", `${PW}x${PH}`, "-i", "-", "-frames:v", "1", outP], { input: pack });
console.log("logo", LW, "x", LH, "at", ox, oy);
