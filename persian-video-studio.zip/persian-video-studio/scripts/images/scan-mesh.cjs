// "3D face scan" wireframe that follows a subject's silhouette on a dark/black studio photo.
// Writes an SVG the size of the frame (lines + vertex dots, deterministic) to overlay and reveal with a clip-path.
// usage: node scan-mesh.cjs <photo> <out.svg> [--size 1080x1920] [--band 820] [--spacing 30] [--thresh 22]
//        [--color #7df9ff]
//   --band: height (px) of the region below the top of the subject to cover (head only, skip the shirt).
const { execFileSync } = require("child_process");
const fs = require("fs");
const { FF } = require("../lib/ff.cjs");

const [, , photo, outSvg] = process.argv;
const arg = (k, d) => {
  const i = process.argv.indexOf("--" + k);
  return i > -1 ? process.argv[i + 1] : d;
};
const [W, H] = arg("size", "1080x1920").split("x").map(Number);
const BAND = +arg("band", 820);
const S = +arg("spacing", 30);
const TH = +arg("thresh", 22);
const COLOR = arg("color", "#7df9ff");

const raw = execFileSync(FF, ["-v", "error", "-i", photo, "-vf", `scale=${W}:${H}`, "-f", "rawvideo", "-pix_fmt", "gray", "-"], { maxBuffer: 1 << 28 });
const lum = (x, y) => raw[Math.round(y) * W + Math.round(x)];
const inside = (x, y) => {
  if (x < 4 || y < 4 || x >= W - 4 || y >= H - 4) return false;
  let c = 0;
  for (let dy = -3; dy <= 3; dy += 3) for (let dx = -3; dx <= 3; dx += 3) if (lum(x + dx, y + dy) > TH) c++;
  return c >= 8;
};
let yTop = H;
for (let y = 0; y < H && yTop === H; y += 2) for (let x = 0; x < W; x += 6) if (inside(x, y)) { yTop = y; break; }
const yBottom = Math.min(H - 1, yTop + BAND);
const hash = (i, j) => {
  let h = (i * 374761393 + j * 668265263) ^ 0x5bd1e995;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const pts = new Map();
for (let j = 0; yTop + j * S * 0.866 <= yBottom; j++) {
  for (let i = 0; i * S < W; i++) {
    const x = i * S + (j % 2 ? S / 2 : 0) + (hash(i, j) - 0.5) * 9;
    const y = yTop + 6 + j * S * 0.866 + (hash(j, i) - 0.5) * 9;
    if (inside(x, y)) pts.set(`${i},${j}`, [x, y]);
  }
}
let lines = "";
let dots = "";
const seg = (a, b) => {
  if (!a || !b || !inside((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)) return;
  lines += `M${a[0].toFixed(1)} ${a[1].toFixed(1)}L${b[0].toFixed(1)} ${b[1].toFixed(1)}`;
};
for (const [k, p] of pts) {
  const [i, j] = k.split(",").map(Number);
  const odd = j % 2;
  seg(p, pts.get(`${i + 1},${j}`));
  seg(p, pts.get(`${odd ? i + 1 : i},${j + 1}`));
  seg(p, pts.get(`${odd ? i : i - 1},${j + 1}`));
  dots += `M${(p[0] - 1.6).toFixed(1)} ${p[1].toFixed(1)}a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0`;
}
fs.writeFileSync(outSvg, `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<path d="${lines}" fill="none" stroke="${COLOR}" stroke-width="1.1" stroke-opacity="0.55"/>
<path d="${dots}" fill="${COLOR}" fill-opacity="0.85"/>
</svg>`);
console.log("points", pts.size, "subject top", yTop, "→", yBottom, "→", outSvg);
