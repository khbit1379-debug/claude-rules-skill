param(
  [Parameter(Mandatory = $true)][string]$Name,
  [switch]$WithPack
)
# Generates one image through the Codex CLI (ChatGPT image generation) using a prompt file in prompts\<Name>.txt
$env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
$dir = $PSScriptRoot
$prompt = Get-Content "$dir\prompts\$Name.txt" -Raw -Encoding UTF8
$refs = @()
if ($WithPack) { $refs += @('-i', "$dir\refs\pack.png") }
$refs += @('-i', "$dir\refs\style.jpg")
$start = Get-Date
codex exec --skip-git-repo-check -s workspace-write -C $dir @refs -o "$dir\prompts\$Name.last.txt" $prompt 2>&1 | Out-File "$dir\prompts\$Name.log" -Encoding utf8
$ok = Test-Path "$dir\$Name.png"
"$Name done=$ok in $([int]((Get-Date) - $start).TotalSeconds)s"
