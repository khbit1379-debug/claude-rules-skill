// Final audio master for a rendered reel. The renderer's own mix comes out quiet (≈ −25 LUFS), so the three stems
// are summed here, brought to the target loudness (Instagram ≈ −14 LUFS) with a transparent limiter catching the
// peaks (≤ −1 dBFS), and muxed onto the rendered picture (video stream copied untouched).
// usage: node master.cjs <render.mp4> <duration> [--stems assets/audio] [--lufs -14]
const fs = require("fs"), path = require("path");
const { execFileSync } = require("child_process");
const { FF } = require("../lib/ff.cjs");
const loudness = require("../lib/loudness.cjs");
const [, , video, dur] = process.argv;
const arg = (k, d) => { const i = process.argv.indexOf("--" + k); return i > -1 ? process.argv[i + 1] : d; };
const stems = arg("stems", "assets/audio"), target = +arg("lufs", -14);
const inputs = ["voice.mp3", "music-bed.mp3", "sfx-mix.mp3"].map((f) => path.join(stems, f)).filter((f) => fs.existsSync(f));
const tmp = path.join(path.dirname(video), "_master.wav"), tmp2 = path.join(path.dirname(video), "_master2.wav");
const run = (a) => execFileSync(FF, ["-v", "error", "-y", ...a], { maxBuffer: 1 << 30 });
const sum = `${inputs.map((_, i) => `[${i}:a]`).join("")}amix=inputs=${inputs.length}:normalize=0:duration=longest,atrim=0:${dur}`;
run([...inputs.flatMap((f) => ["-i", f]), "-filter_complex", sum, "-ar", "48000", "-c:a", "pcm_s16le", tmp]);
const before = loudness(tmp);
const gain = target - before.lufs + 0.3; // the limiter shaves a few tenths off
run(["-i", tmp, "-af", `volume=${gain.toFixed(2)}dB,alimiter=limit=0.86:attack=3:release=60:level=disabled,aresample=48000`, "-c:a", "pcm_s16le", tmp2]);
const out = video.replace(/\.mp4$/, ".tmp.mp4");
run(["-i", video, "-i", tmp2, "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-shortest", "-movflags", "+faststart", out]);
fs.renameSync(out, video); fs.rmSync(tmp); fs.rmSync(tmp2);
const after = loudness(video);
console.log(`mix ${before.lufs} LUFS → gain ${gain.toFixed(1)} dB → final ${after.lufs} LUFS, peak ${after.peak} dBFS`);
