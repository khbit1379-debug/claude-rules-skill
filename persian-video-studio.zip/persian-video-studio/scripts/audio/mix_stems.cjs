// Pre-mixes a reel's audio into three plain stems. Studio plays a few MP3s smoothly; dozens of <audio> clips or live
// effect chains make it lag or go silent, so everything is summed here and the composition only places 3 files.
//   voice.mp3      the speaker (the user's own recording or a TTS take)
//   music-bed.mp3  music, sidechain-ducked under the voice, optional swell window, faded in/out
//   sfx-mix.mp3    every cue [name, time, volume] + the caption typing clicks
// usage: node mix_stems.cjs [--voice assets/audio/voice.wav] --end 117.8 --out assets/audio
//   (no --voice: music-only reel, e.g. a 3D explainer; the music is not ducked)
//          [--music assets/audio/music-src.mp3] [--music-db -8] [--swell 63.1,65.0]
//          [--cues tools/sfx-cues.json] [--sfx-dir assets/sfx] [--sfx-gain 0.56]
//          [--typing assets/audio/typing.wav] [--typing-gain 0.24]
// cue names are files in --sfx-dir (".mp3" is added unless the name already ends in .mp3/.wav).
const fs = require("fs"), path = require("path");
const { execFileSync } = require("child_process");
const { FF } = require("../lib/ff.cjs");
const loudness = require("../lib/loudness.cjs");
const arg = (k, d) => { const i = process.argv.indexOf("--" + k); return i > -1 ? process.argv[i + 1] : d; };
const END = +arg("end"), OUT = arg("out", "assets/audio"), SR = 48000, voice = arg("voice");
const run = (a) => execFileSync(FF, ["-v", "error", "-y", ...a], { maxBuffer: 1 << 30 });
fs.mkdirSync(OUT, { recursive: true });
if (voice) run(["-i", voice, "-t", String(END), "-ac", "2", "-ar", "48000", "-c:a", "libmp3lame", "-b:a", "192k", path.join(OUT, "voice.mp3")]);
if (arg("music")) {
  const swell = arg("swell") ? arg("swell").split(",").map(Number) : null;
  const sw = swell ? `volume='1+1.0*between(t,${swell[0]},${swell[1]})*min(1,min((t-${swell[0]})/0.25,(${swell[1]}-t)/0.5))':eval=frame,` : "";
  const head = `[0:a]aresample=48000,atrim=0:${END},volume=${arg("music-db", -8)}dB[m];`;
  const duck = voice
    ? `[1:a]aresample=48000,apad=whole_dur=${END}[sc];[m][sc]sidechaincompress=threshold=0.06:ratio=2.5:attack=30:release=450:makeup=1[d];`
    : "[m]anull[d];";
  run(["-i", arg("music"), ...(voice ? ["-i", voice] : []), "-filter_complex",
    head + duck + `[d]${sw}afade=t=in:d=0.25,afade=t=out:st=${Math.max(0, END - 1.2)}:d=1.2[out]`,
    "-map", "[out]", "-ac", "2", "-c:a", "libmp3lame", "-b:a", "192k", path.join(OUT, "music-bed.mp3")]);
}
const out = new Float32Array(Math.ceil(END * SR) * 2), cache = {};
const load = (f) => (cache[f] ??= (() => { const b = run(["-i", f, "-f", "f32le", "-ac", "2", "-ar", "48000", "-"]); return new Float32Array(b.buffer, b.byteOffset, b.length / 4); })());
const add = (f, t, v) => { const a = load(f), o = Math.round(t * SR) * 2; for (let i = 0; i < a.length && o + i < out.length; i++) if (o + i >= 0) out[o + i] += a[i] * v; };
if (arg("cues")) {
  const dir = arg("sfx-dir", "assets/sfx"), g = +arg("sfx-gain", 0.56);
  for (const [n, t, v] of JSON.parse(fs.readFileSync(arg("cues"), "utf8"))) add(path.join(dir, /\.(mp3|wav)$/.test(n) ? n : n + ".mp3"), t, v * g);
}
if (arg("typing")) add(arg("typing"), 0, +arg("typing-gain", 0.24));
let pk = 0; for (const s of out) pk = Math.max(pk, Math.abs(s));
if (pk > 0.95) for (let i = 0; i < out.length; i++) out[i] *= 0.95 / pk;
execFileSync(FF, ["-v", "error", "-y", "-f", "f32le", "-ar", "48000", "-ac", "2", "-i", "-", "-c:a", "libmp3lame", "-b:a", "192k", path.join(OUT, "sfx-mix.mp3")], { input: Buffer.from(out.buffer) });
// report stem loudness so the balance can be checked without listening
for (const f of ["voice.mp3", "music-bed.mp3", "sfx-mix.mp3"]) {
  const p = path.join(OUT, f); if (!fs.existsSync(p)) continue;
  const { lufs, peak } = loudness(p);
  console.log(f.padEnd(14), `${lufs} LUFS  peak ${peak} dBFS`);
}
console.log(voice ? "aim: voice ≈ −16…−18, music bed ≈ 10–13 LU under the voice, sfx stem ≈ −23…−26 (cute, never harsh)"
  : "aim (no voice): music ≈ −18, sfx stem ≈ −19…−21 so the hits read clearly; master.cjs lifts the sum to −14");
