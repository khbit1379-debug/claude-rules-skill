// What does this machine have for Persian Video Studio? Prints ✓/✗ per tool with the fix for anything missing.
// usage: node SKILL_DIR/scripts/doctor.cjs
const fs = require("fs"), path = require("path"), { spawnSync } = require("child_process");
const cfg = require("./lib/config.cjs");
const ok = (b, name, detail, fix) => console.log(`${b ? "✓" : "✗"} ${name.padEnd(26)} ${b ? detail || "" : "→ " + fix}`);
const ver = (cmd, args = ["--version"]) => { const r = spawnSync(cmd, args, { encoding: "utf8", windowsHide: true, shell: process.platform === "win32" }); return r.status === 0 ? (r.stdout || r.stderr).split(/\r?\n/)[0].trim() : null; };
const node = process.versions.node, major = +node.split(".")[0];
ok(major >= 22, "Node.js 22+", "v" + node, "install Node.js 22 or newer (nodejs.org)");
let ff = null; try { ff = require("./lib/ff.cjs"); } catch (e) {}
ok(!!ff, "FFmpeg + ffprobe", ff ? ff.FF : "", "winget install Gyan.FFmpeg.Essentials (Windows) · brew install ffmpeg (macOS)");
const npx = path.join(path.dirname(process.execPath), process.platform === "win32" ? "npx.cmd" : "npx");
ok(fs.existsSync(npx), "npx (HyperFrames CLI)", npx, "comes with Node.js");
const py = cfg.whisperPython, hasPy = fs.existsSync(py);
let fw = false; if (hasPy) fw = spawnSync(py, ["-c", "import faster_whisper"], { windowsHide: true }).status === 0;
ok(fw, "faster-whisper venv", py, "references/setup.md → Whisper (≈280 MB, ask the user first)");
const wm = path.join(cfg.models, "whisper");
const hasWm = fs.existsSync(wm) && fs.readdirSync(wm).some((d) => /large-v3-turbo/i.test(d));
ok(hasWm, "Whisper model", wm, "downloads on first run of whisper_words.py (1.6 GB, ask first)");
const rvm = path.join(cfg.models, "rvm_resnet50_fp32.onnx");
ok(fs.existsSync(rvm), "RVM matting model", rvm, "references/setup.md → RVM (102.5 MB, ask first)");
const ort = path.join(cfg.nodeModules, "onnxruntime-node");
ok(fs.existsSync(ort), "onnxruntime-node", ort, "npm i onnxruntime-node@1.21.1 in ~/.persian-video-studio (ask first)");
ok(fs.existsSync(path.join(cfg.root, "kit", ".claude", "skills")), "bundled editing kit", "kit/ (MIT, Nate Herk)", "re-extract the skill package");
const fontDir = path.join(process.env.LOCALAPPDATA || "", "Microsoft", "Windows", "Fonts");
let abar = []; try { abar = fs.readdirSync(fontDir).filter((f) => /^Abar/i.test(f)); } catch {}
ok(abar.length > 0, "Abar font (installed)", `${abar.length} files`, "ask the user for their Abar font files; copy into assets/fonts/ of each project");
console.log(`\nconfig: models=${cfg.models}\n        nodeModules=${cfg.nodeModules}\n        (override in ${path.join(cfg.root, "config.local.json")})`);
