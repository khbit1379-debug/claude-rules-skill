// Prepare an AI video clip (e.g. a Seedance start/end-frame morph) for a 1080x1920 @ 30 fps HyperFrames reel:
// download it, conform size/fps, and measure how well its first/last frames match the frames it must join
// (mean absolute difference per pixel on 0-255 grey; under ~1 is an invisible join, above ~5 needs a crossfade).
// usage: node prep-morph.cjs <url-or-local-file> <out.mp4> [--first join-first.png] [--last join-last.png]
//                            [--size 1080x1920] [--fps 30]
const { execFileSync } = require("child_process");
const fs = require("fs");
const path = require("path");
const { FF, FFP } = require("../lib/ff.cjs");

const [, , src, out] = process.argv;
const arg = (k, d) => {
  const i = process.argv.indexOf("--" + k);
  return i > -1 ? process.argv[i + 1] : d;
};
const [W, H] = arg("size", "1080x1920").split("x").map(Number);
const FPS = arg("fps", "30");
const ff = (args) => execFileSync(FF, ["-v", "error", "-y", ...args], { maxBuffer: 1 << 28 });

(async () => {
  let input = src;
  if (/^https?:/i.test(src)) {
    const r = await fetch(src);
    if (!r.ok) throw new Error("download failed: " + r.status);
    input = out.replace(/\.mp4$/i, ".src.mp4");
    fs.writeFileSync(input, Buffer.from(await r.arrayBuffer()));
  }
  const probe = execFileSync(FFP, ["-v", "error", "-show_entries", "stream=width,height,r_frame_rate,nb_frames:format=duration", "-of", "compact", input]).toString();
  console.log("source:", probe.trim().replace(/\n/g, " | "));
  ff(["-i", input, "-vf", `scale=${W}:${H}:flags=lanczos,fps=${FPS},format=yuv420p`, "-an", "-c:v", "libx264", "-crf", "14", "-preset", "slow", "-movflags", "+faststart", out]);

  const grey = (args) => ff([...args, "-vf", "scale=270:480,format=gray", "-frames:v", "1", "-f", "rawvideo", "-"]);
  const mad = (a, b) => {
    let s = 0;
    for (let i = 0; i < a.length; i++) s += Math.abs(a[i] - b[i]);
    return (s / a.length).toFixed(2);
  };
  const first = arg("first");
  const last = arg("last");
  if (first) console.log("first frame vs", path.basename(first), "MAD", mad(grey(["-i", out]), grey(["-i", first])));
  if (last) console.log("last frame  vs", path.basename(last), "MAD", mad(grey(["-sseof", "-0.05", "-i", out]), grey(["-i", last])));
  const dur = execFileSync(FFP, ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", out]).toString().trim();
  console.log("conformed", out, `${W}x${H}@${FPS}`, "duration", (+dur).toFixed(3));
})();
