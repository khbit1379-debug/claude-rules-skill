# Word-level timestamps for Persian speech with faster-whisper (large-v3-turbo).
# The proof-read transcript can be passed as the initial prompt so the decoder spells words the way the captions do.
# usage: <whisper-venv python> whisper_words.py <audio> <out.json> [transcript.txt]
# Models are cached under $PVS_MODELS/whisper (or config.local.json "models", or ~/.persian-video-studio/models).
# GPU needs CUDA 12 cuBLAS/cuDNN DLLs; without them it falls back to CPU int8 (about 30 s per minute of speech).
import json, os, sys, time
from faster_whisper import WhisperModel

here = os.path.dirname(os.path.abspath(__file__))
root_cfg = os.path.join(here, "..", "..", "config.local.json")
models = os.environ.get("PVS_MODELS")
if not models and os.path.exists(root_cfg):
    models = json.load(open(root_cfg, encoding="utf-8")).get("models")
models = models or os.path.join(os.path.expanduser("~"), ".persian-video-studio", "models")
root = os.path.join(models, "whisper")

audio, out = sys.argv[1], sys.argv[2]
prompt = open(sys.argv[3], encoding="utf-8").read()[:600] if len(sys.argv) > 3 else None
t0 = time.time()
try:
    model = WhisperModel("large-v3-turbo", device="cuda", compute_type="float16", download_root=root)
    list(model.transcribe(audio, language="fa", beam_size=1, clip_timestamps=[0, 2])[0])  # probe the GPU libs
    dev = "cuda"
except Exception as e:
    print("GPU unavailable, using CPU:", str(e)[:120])
    model = WhisperModel("large-v3-turbo", device="cpu", compute_type="int8", download_root=root)
    dev = "cpu"
print("model ready on", dev, f"{time.time() - t0:.1f}s")
segs, info = model.transcribe(audio, language="fa", beam_size=5, word_timestamps=True, vad_filter=False,
                              condition_on_previous_text=True, initial_prompt=prompt)
words = []
for s in segs:
    for w in s.words or []:
        words.append({"w": w.word.strip(), "s": round(w.start, 3), "e": round(w.end, 3), "p": round(w.probability, 3)})
json.dump(words, open(out, "w", encoding="utf-8"), ensure_ascii=False)
print(len(words), "words", f"{time.time() - t0:.1f}s")
