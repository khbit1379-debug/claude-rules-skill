// Bridge to the bundled editing kit (kit/): converts our word timing ([{w, s, e}] from align_whisper.cjs or the raw
// faster-whisper output) into the transcript shape the kit's cut-silences / cut-mistakes / beat tools read:
//   { words: [{ text, start, end, type: "word" }], audio_duration_secs }
// usage: node to_kit_transcript.cjs <words.json> <out-transcript.json> [durationSec]
const fs = require("fs");
const [, , inp, out, dur] = process.argv;
const src = JSON.parse(fs.readFileSync(inp, "utf8"));
const words = src.map((x) => ({ text: x.w ?? x.text, start: x.s ?? x.start, end: x.e ?? x.end, type: "word" }));
fs.writeFileSync(out, JSON.stringify({ language_code: "fa", audio_duration_secs: dur ? +dur : words.at(-1).end, words }, null, 1));
console.log(`${words.length} words → ${out}`);
