// Word timing for captions: faster-whisper times mapped onto the PROOF-READ transcript.
// Whisper's Persian spelling is loose («حوش مسئلی» for «هوش مصنوعی»), so words are compared after folding letters
// that sound alike; a Needleman-Wunsch alignment (with 1→2 and 2→1 merges) pairs them. Starts that follow a pause
// are snapped to the nearest voiced onset of the real audio.
// usage: node align_whisper.cjs <transcript.txt> <whisper-words.json> <audio> <out-words.json> [fromSec=0]
//   transcript.txt: the text exactly as it should appear in captions (fix ASR mistakes here, keep the speaker's words)
//   out: [{w, s, e}] in the audio's own seconds
const fs = require("fs");
const { execFileSync } = require("child_process");
const { FF } = require("../lib/ff.cjs");
const [, , txtPath, whPath, audio, outPath, fromArg = "0"] = process.argv;
const FROM = +fromArg;
const ours = fs.readFileSync(txtPath, "utf8").split(/\s+/).filter(Boolean);
const wh = JSON.parse(fs.readFileSync(whPath, "utf8")).filter((x) => x.e > FROM - 0.2 && x.w);

// 10 ms loudness envelope of the audio (for onset snapping)
const raw = execFileSync(FF, ["-v", "error", "-i", audio, "-ac", "1", "-ar", "16000", "-f", "f32le", "-"], { maxBuffer: 1 << 30 });
const a = new Float32Array(raw.buffer, raw.byteOffset, raw.length / 4);
const env = [];
for (let i = 0; i + 160 <= a.length; i += 160) { let s = 0; for (let k = 0; k < 160; k++) s += a[i + k] * a[i + k]; env.push(10 * Math.log10(s / 160 + 1e-12)); }
const sm = env.map((_, i) => (env[i - 1] ?? env[i]) / 3 + env[i] / 3 + (env[i + 1] ?? env[i]) / 3);
const voiced = (t) => (sm[Math.round(t * 100)] ?? -99) > -33;

const FOLD = { "ي": "ی", "ك": "ک", "آ": "ا", "ع": "ا", "أ": "ا", "إ": "ا", "ص": "س", "ث": "س", "ض": "ز", "ظ": "ز", "ذ": "ز", "ط": "ت", "ح": "ه", "غ": "ق", "ة": "ه", "ۀ": "ه", "ئ": "ی", "ؤ": "و" };
const norm = (w) => [...w.replace(/[‌ً-ٟ،؟!.,:?«»"]/g, "")].map((c) => FOLD[c] || c).join("");
const lev = (x, y) => {
  const A = [...x], B = [...y], d = Array.from({ length: A.length + 1 }, (_, i) => [i, ...Array(B.length).fill(0)]);
  for (let j = 1; j <= B.length; j++) d[0][j] = j;
  for (let i = 1; i <= A.length; i++) for (let j = 1; j <= B.length; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (A[i - 1] === B[j - 1] ? 0 : 1));
  return d[A.length][B.length];
};
const sim = (x, y) => { const A = norm(x), B = norm(y); if (!A.length && !B.length) return 1; return 1 - lev(A, B) / Math.max(A.length, B.length, 1); };

const N = ours.length, M = wh.length, GAP = 0.75;
const cost = Array.from({ length: N + 1 }, () => new Float64Array(M + 1).fill(Infinity));
const back = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(null));
cost[0][0] = 0;
for (let i = 0; i <= N; i++) for (let j = 0; j <= M; j++) {
  const c = cost[i][j]; if (c === Infinity) continue;
  const relax = (ni, nj, v, op) => { if (ni <= N && nj <= M && c + v < cost[ni][nj]) { cost[ni][nj] = c + v; back[ni][nj] = [i, j, op]; } };
  if (i < N && j < M) relax(i + 1, j + 1, 1 - sim(ours[i], wh[j].w), "m");
  if (i < N && j + 1 < M) relax(i + 1, j + 2, 1 - sim(ours[i], wh[j].w + wh[j + 1].w) + 0.05, "m12");
  if (i + 1 < N && j < M) relax(i + 2, j + 1, 1 - sim(ours[i] + ours[i + 1], wh[j].w) + 0.05, "m21");
  if (i < N) relax(i + 1, j, GAP, "gapO");
  if (j < M) relax(i, j + 1, GAP, "gapW");
}
const times = new Array(N).fill(null);
let i = N, j = M, matched = 0;
const weak = [];
while (i > 0 || j > 0) {
  const [pi, pj, op] = back[i][j];
  if (op === "m") { times[pi] = [wh[pj].s, wh[pj].e]; matched++; if (sim(ours[pi], wh[pj].w) < 0.4) weak.push(`${ours[pi]}~${wh[pj].w}`); }
  if (op === "m12") { times[pi] = [wh[pj].s, wh[pj + 1].e]; matched++; }
  if (op === "m21") { const mid = (wh[pj].s + wh[pj].e) / 2; times[pi] = [wh[pj].s, mid]; times[pi + 1] = [mid, wh[pj].e]; matched += 2; }
  i = pi; j = pj;
}
for (let k = 0; k < N; k++) if (!times[k]) { // interpolate unmatched words between known neighbours
  let p = k - 1; while (p >= 0 && !times[p]) p--;
  let q = k + 1; while (q < N && !times[q]) q++;
  const t0 = p >= 0 ? times[p][1] : FROM, t1 = q < N ? times[q][0] : t0 + 0.4, n = q - p - 1, idx = k - p;
  times[k] = [t0 + ((t1 - t0) * (idx - 1)) / n, t0 + ((t1 - t0) * idx) / n];
}
let snapped = 0;
for (let k = 0; k < N; k++) { // after a pause, start on the voiced onset
  const s = times[k][0], prevEnd = k ? times[k - 1][1] : FROM;
  if (k && s - prevEnd < 0.12) continue;
  for (let d = -0.25; d <= 0.35; d += 0.01) {
    const t = s + d;
    if (!voiced(t - 0.02) && voiced(t) && voiced(t + 0.05)) { if (Math.abs(d) > 0.02) { times[k][0] = t; snapped++; } break; }
  }
}
for (let k = 1; k < N; k++) if (times[k][0] < times[k - 1][0] + 0.03) times[k][0] = times[k - 1][0] + 0.03;
for (let k = 0; k < N; k++) { if (k + 1 < N) times[k][1] = Math.min(times[k][1], times[k + 1][0]); times[k][1] = Math.max(times[k][1], times[k][0] + 0.06); }
fs.writeFileSync(outPath, JSON.stringify(ours.map((w, k) => ({ w, s: +times[k][0].toFixed(3), e: +times[k][1].toFixed(3) }))));
console.log(`words ${N}, whisper ${M}, matched ${matched}, snapped ${snapped}, weak matches ${weak.length}${weak.length ? ": " + weak.slice(0, 15).join(" ") : ""}`);
