// Typed Persian captions: pages + per-word typing times + the typing-click sound stem.
// Input words come from timing/align_whisper.cjs ([{w, s, e}] in audio seconds).
// usage:
//   node build_captions.cjs --words work/words.json --comp compositions/captions.html --end 117.8
//        [--offset 0.767]          seconds trimmed from the head of the audio (comp time = audio time − offset)
//        [--hl hl.json]            {"lime": ["کلمه", …], "red": ["نه", …]} words to highlight (marker / red)
//        [--maxc 23] [--maxw 4]    max characters / words per page (pages are always ONE line)
//        [--cta "اِ"]             first word of the closing call-to-action: pages from there sit higher
//        [--bumps 49.05,49.63]     comp times where the caption hops (he points at it)
//        [--typing assets/audio/typing.wav] [--clicks <dir with k1..k5.wav>]
//        [--json assets/captions.json]
const fs = require("fs"), path = require("path");
const { execFileSync } = require("child_process");
const { FF } = require("../lib/ff.cjs");
const arg = (k, d) => { const i = process.argv.indexOf("--" + k); return i > -1 ? process.argv[i + 1] : d; };
const words0 = JSON.parse(fs.readFileSync(arg("words"), "utf8"));
const OFFSET = +arg("offset", 0), END = +arg("end"), MAXC = +arg("maxc", 23), MAXW = +arg("maxw", 4);
const hl = arg("hl") ? JSON.parse(fs.readFileSync(arg("hl"), "utf8")) : { lime: [], red: [] };
const cls = (w) => (hl.red?.includes(w) ? 2 : hl.lime?.includes(w) ? 1 : 0);
const words = words0.map(({ w, s, e }) => {
  const t = +(s - OFFSET).toFixed(3), d = e - s, n = [...w].length;
  // letters appear while the word is spoken: over 75 % of it, never slower than 60 ms a letter
  return { w, t, type: +Math.min(d * 0.75, 0.06 * n).toFixed(3), h: cls(w), end: +(e - OFFSET).toFixed(3) };
}).filter((x) => x.t < END);
// pages: one line each; break at sentence ends, at commas once 2+ words, at real pauses, or when too long
const groups = [];
for (let i = 0; i < words.length;) {
  let j = i, chars = [...words[i].w].length;
  while (j + 1 < words.length) {
    const nx = words[j + 1], c2 = chars + 1 + [...nx.w].length;
    if (/[.؟!?]$/.test(words[j].w)) break;
    if (/[،,]$/.test(words[j].w) && j - i + 1 >= 2) break;
    if (nx.t - words[j].end > 0.3) break;
    if (c2 > MAXC || j - i + 2 > MAXW) break;
    chars = c2; j++;
  }
  groups.push([i, j]); i = j + 1;
}
// fold a lonely short word into its neighbour when they are spoken together
const len = (r) => [...words.slice(r[0], r[1] + 1).map((x) => x.w).join(" ")].length;
for (let g = 0; g < groups.length; g++) {
  const [a, b] = groups[g];
  if (a !== b || [...words[a].w].length > 5) continue;
  const nxt = groups[g + 1], prv = groups[g - 1];
  if (nxt && !/[.؟!،]$/.test(words[b].w) && words[nxt[0]].t - words[b].end < 0.4 && len([a, nxt[1]]) <= MAXC + 4) { groups.splice(g, 2, [a, nxt[1]]); g--; }
  else if (prv && !/[.؟!]$/.test(words[prv[1]].w) && words[a].t - words[prv[1]].end < 0.4 && len([prv[0], b]) <= MAXC + 4) { groups.splice(g - 1, 2, [prv[0], b]); g -= 2; }
}
const pages = groups.map(([a, b], p) => {
  const ws = words.slice(a, b + 1).map(({ w, t, type, h }) => ({ w, t, type, h }));
  const start = Math.max(0, ws[0].t - 0.08);
  const next = groups[p + 1] ? words[groups[p + 1][0]].t - 0.1 : END;
  return { start: +start.toFixed(3), end: +Math.min(next, words[b].end + 0.9, END).toFixed(3), text: ws.map((x) => x.w).join(" "), words: ws };
});
if (arg("json")) fs.writeFileSync(arg("json"), JSON.stringify({ end: END, pages }, null, 1));
const cta = arg("cta") ? (words.find((w) => w.w === arg("cta"))?.t ?? 1e9) - 0.12 : 1e9;
const bumps = arg("bumps") ? arg("bumps").split(",").map(Number) : [];
const comp = arg("comp");
fs.writeFileSync(comp, fs.readFileSync(comp, "utf8")
  .replace(/\/\*PAGES\*\/[\s\S]*?\/\*END\*\//, `/*PAGES*/${JSON.stringify(pages)}/*END*/`)
  .replace(/\/\*CTA\*\/[\s\S]*?\/\*ENDCTA\*\//, `/*CTA*/${cta.toFixed(3)}/*ENDCTA*/`)
  .replace(/\/\*BUMPS\*\/[\s\S]*?\/\*ENDBUMPS\*\//, `/*BUMPS*/${JSON.stringify(bumps)}/*ENDBUMPS*/`)
  .replace(/(data-composition-id="captions"[^>]*?data-duration=")[^"]*"/, `$1${END}"`));
// typing clicks: one soft click every two letters across each word's typing window
if (arg("typing")) {
  const clickDir = arg("clicks", path.join(__dirname, "../../assets/sfx/clicks"));
  let seed = 11; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const SR = 48000, samp = {};
  for (let s = 1; s <= 5; s++) {
    const r = execFileSync(FF, ["-v", "error", "-i", path.join(clickDir, `k${s}.wav`), "-f", "f32le", "-ac", "1", "-ar", "48000", "-"]);
    samp[s] = new Float32Array(r.buffer, r.byteOffset, r.length / 4);
  }
  const out = new Float32Array(Math.ceil(END * SR));
  for (const w of words) {
    const n = [...w.w].length, k = Math.max(1, Math.round(n / 2));
    for (let q = 0; q < k; q++) {
      const a = samp[1 + Math.floor(rnd() * 5)], g = 0.55 + rnd() * 0.45, o = Math.round((w.t + (w.type * q) / k) * SR);
      for (let z = 0; z < a.length && o + z < out.length; z++) out[o + z] += a[z] * g;
    }
  }
  let pk = 0; for (const v of out) pk = Math.max(pk, Math.abs(v));
  for (let z = 0; z < out.length; z++) out[z] *= pk > 0 ? 0.7 / pk : 1;
  execFileSync(FF, ["-v", "error", "-y", "-f", "f32le", "-ar", "48000", "-ac", "1", "-i", "-", "-ac", "2", arg("typing")], { input: Buffer.from(out.buffer) });
}
console.log(`pages ${pages.length}, words ${words.length}` + (cta < 1e9 ? `, CTA from ${cta.toFixed(2)}` : ""));
for (const p of pages) if ([...p.text].length > MAXC + 2) console.log("  long page:", p.start, p.text);
