// Refines the RVM cut-out for compositing on new backgrounds.
//  1. Colour unmixing against the real background (the "luma key for dark hair" a compositor would pull):
//     the local background colour B is estimated from nearby pixels RVM calls background; where B is light and
//     the pixel is colourless (hair/wall mixes are grey; skin is not), the true alpha of dark hair F over B is
//     solved from the ORIGINAL pixel colour. White cabinet seen through curls (which RVM often marks solid,
//     e.g. next to the ear) goes transparent; real strands stay.
//  2. Colour extend: remaining see-through pixels take their colour from the nearby solid subject, so no
//     background tint survives on the edges.
//  3. Faint alpha haze is trimmed.
// node refine.mjs <matte.mp4> <original video> <startFrame> <frames> <out.webm>
//   matte.mp4 is the stacked RVM output (fg on top, alpha below); the original is read with the same framing.
import { spawn } from "node:child_process";
import { createRequire } from "node:module";
const { FF } = createRequire(import.meta.url)("../lib/ff.cjs");

const [matte, orig, s0, nf, out] = [process.argv[2], process.argv[3], +process.argv[4], +process.argv[5], process.argv[6]];
const origStart = +(process.env.ORIG_START ?? s0); // frame index of s0 inside the original video
const W = 1080, H = 1920, N = W * H, HW = W / 2, HH = H / 2, HN = HW * HH;
// colour of the subject's hair/beard (dark brown-black by default); override with HAIR_RGB="r,g,b"
const HAIR = (process.env.HAIR_RGB || "30,26,24").split(",").map(Number);
const smooth = (e0, e1, x) => { const t = Math.min(1, Math.max(0, (x - e0) / (e1 - e0))); return t * t * (3 - 2 * t); };
const lumOf = (r, g, b) => (0.299 * r + 0.587 * g + 0.114 * b) / 255;
const satOf = (r, g, b) => { const mx = Math.max(r, g, b); return mx > 0 ? (mx - Math.min(r, g, b)) / mx : 0; };

// ---- streaming frame readers ----
function reader(args, frameBytes) {
  const p = spawn(FF, args, { stdio: ["ignore", "pipe", "inherit"] });
  let buf = Buffer.alloc(0), ended = false, waiting = null;
  const tryResolve = () => {
    if (!waiting) return;
    if (buf.length >= frameBytes) { const f = buf.subarray(0, frameBytes); buf = buf.subarray(frameBytes); const w = waiting; waiting = null; w(f); p.stdout.resume(); }
    else if (ended) { const w = waiting; waiting = null; w(null); }
  };
  p.stdout.on("data", (c) => { buf = Buffer.concat([buf, c]); if (buf.length > frameBytes * 2) p.stdout.pause(); tryResolve(); });
  p.stdout.on("end", () => { ended = true; tryResolve(); });
  return () => new Promise((res) => { waiting = res; tryResolve(); });
}
const nextMatte = reader(["-v", "error", "-i", matte, "-vf",
  `trim=start_frame=${s0}:end_frame=${s0 + nf},setpts=PTS-STARTPTS,scale=in_range=full:in_color_matrix=bt709:out_range=full,format=rgb24`,
  "-f", "rawvideo", "-"], W * H * 2 * 3);
const nextOrig = reader(["-v", "error", "-i", orig, "-an", "-vf",
  `scale=${W}:${H}:in_color_matrix=bt709:flags=lanczos,fps=30,trim=start_frame=${origStart}:end_frame=${origStart + nf},setpts=PTS-STARTPTS,format=rgb24`,
  "-f", "rawvideo", "-"], W * H * 3);
const enc = spawn(FF, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", "30", "-i", "-",
  "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "0", "-crf", "20", "-row-mt", "1", "-deadline", "good", "-cpu-used", "3", "-auto-alt-ref", "0", out],
  { stdio: ["pipe", "inherit", "inherit"] });

// separable box blur on a half-res float plane, radius r, in place
const tmp = new Float32Array(HN);
function boxBlur(src, r) {
  const w = HW, h = HH, d = 2 * r + 1;
  for (let y = 0; y < h; y++) {
    let acc = 0; const o = y * w;
    for (let x = -r; x <= r; x++) acc += src[o + Math.min(w - 1, Math.max(0, x))];
    for (let x = 0; x < w; x++) { tmp[o + x] = acc / d; acc += src[o + Math.min(w - 1, x + r + 1)] - src[o + Math.max(0, x - r)]; }
  }
  for (let x = 0; x < w; x++) {
    let acc = 0;
    for (let y = -r; y <= r; y++) acc += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
    for (let y = 0; y < h; y++) { src[y * w + x] = acc / d; acc += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x]; }
  }
}
const planes = () => [0, 1, 2, 3].map(() => new Float32Array(HN));
const sN = planes(), sF = planes(), bN = planes(), bF = planes();
const outBuf = Buffer.alloc(N * 4);
const pick = (P, j, min) => (P[3][j] > min ? [P[0][j] / P[3][j], P[1][j] / P[3][j], P[2][j] / P[3][j], P[3][j]] : null);

function processFrame(m, o) {
  // half-res premultiplied sums: solid subject colour (from RVM fg) and background colour (from the original)
  for (const P of [sN, bN]) for (const p of P) p.fill(0);
  for (let y = 0; y < HH; y++) for (let x = 0; x < HW; x++) {
    let sr = 0, sg = 0, sb = 0, sw = 0, br = 0, bg = 0, bb = 0, bw = 0;
    for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) {
      const X = x * 2 + dx, Y = y * 2 + dy, i = (Y * W + X) * 3, ia = ((Y + H) * W + X) * 3;
      const a = m[ia] / 255, ks = smooth(0.88, 0.98, a), kb = 1 - smooth(0.02, 0.1, a);
      sr += m[i] * ks; sg += m[i + 1] * ks; sb += m[i + 2] * ks; sw += ks;
      br += o[i] * kb; bg += o[i + 1] * kb; bb += o[i + 2] * kb; bw += kb;
    }
    const j = y * HW + x;
    sN[0][j] = sr; sN[1][j] = sg; sN[2][j] = sb; sN[3][j] = sw;
    bN[0][j] = br; bN[1][j] = bg; bN[2][j] = bb; bN[3][j] = bw;
  }
  for (let c = 0; c < 4; c++) {
    sF[c].set(sN[c]); bF[c].set(bN[c]);
    boxBlur(sN[c], 8); boxBlur(sN[c], 8); boxBlur(sF[c], 40);
    boxBlur(bN[c], 14); boxBlur(bN[c], 14); boxBlur(bF[c], 34);
  }
  for (let Y = 0; Y < H; Y++) for (let X = 0; X < W; X++) {
    const p = Y * W + X, i = p * 3, ia = ((Y + H) * W + X) * 3, q = p * 4;
    let a = Math.min(1, Math.max(0, (m[ia] / 255 - 0.035) / 0.95));
    let r = m[i], g = m[i + 1], b = m[i + 2];
    if (a <= 0) { outBuf[q] = r; outBuf[q + 1] = g; outBuf[q + 2] = b; outBuf[q + 3] = 0; continue; }
    const j = Math.min(HH - 1, Y >> 1) * HW + Math.min(HW - 1, X >> 1);
    // 1) colour unmixing against a light background
    let conf = 0;
    const B = pick(bN, j, 0.01) || pick(bF, j, 0.003);
    if (B) {
      const Ir = o[i], Ig = o[i + 1], Ib = o[i + 2];
      const lumB = lumOf(B[0], B[1], B[2]), lumF = lumOf(...HAIR);
      const grey = 1 - smooth(0.1, 0.18, satOf(Ir, Ig, Ib));
      conf = grey * smooth(0.3, 0.5, lumB - lumF) * (1 - smooth(0.12, 0.2, satOf(B[0], B[1], B[2])));
      if (conf > 0) {
        const fr = HAIR[0] - B[0], fg = HAIR[1] - B[1], fb = HAIR[2] - B[2];
        const aEst = Math.min(1, Math.max(0, ((Ir - B[0]) * fr + (Ig - B[1]) * fg + (Ib - B[2]) * fb) / (fr * fr + fg * fg + fb * fb)));
        a = a + (Math.min(aEst, a + 0.3) - a) * conf;
      }
    }
    // 2) colour: unmixed pixels are hair; other see-through pixels borrow the nearby solid subject's colour
    if (a < 0.97 || conf > 0) {
      const E = pick(sN, j, 0.02) || pick(sF, j, 0.002) || HAIR;
      const k = smooth(0.35, 0.97, a);
      let er = E[0] + (r - E[0]) * k, eg = E[1] + (g - E[1]) * k, eb = E[2] + (b - E[2]) * k;
      if (conf > 0) { const c = conf * (1 - smooth(0.9, 1.0, a) * 0.6); er += (HAIR[0] - er) * c; eg += (HAIR[1] - eg) * c; eb += (HAIR[2] - eb) * c; }
      r = er; g = eg; b = eb;
    }
    outBuf[q] = r; outBuf[q + 1] = g; outBuf[q + 2] = b; outBuf[q + 3] = Math.round(a * 255);
  }
}

let done = 0;
for (;;) {
  const [m, o] = await Promise.all([nextMatte(), nextOrig()]);
  if (!m || !o) break;
  processFrame(m, o);
  if (!enc.stdin.write(Buffer.from(outBuf))) await new Promise((r) => enc.stdin.once("drain", r));
  if (++done % 60 === 0) console.log("frame", done);
}
enc.stdin.end();
enc.on("close", (code) => console.log(`done ${done} frames -> ${out} (exit ${code})`));
