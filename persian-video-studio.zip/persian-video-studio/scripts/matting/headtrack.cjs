// Head track from the RVM matte: per frame, bbox + centroid of the alpha in the head band (y < 1000 px),
// computed on a 270x480 downscale of the matte half of work/matte-full.mp4. Output in 1080x1920 px.
// node headtrack.cjs <startFrame> <frames> <out.json>
const { spawn } = require("child_process");
const fs = require("fs");
const { FF } = require("../lib/ff.cjs");
const [s0, nf, out] = [+process.argv[2], +process.argv[3], process.argv[4]];
const W = 270, H = 480, K = 4;
const p = spawn(FF, ["-v", "error", "-i", "work/matte-full.mp4", "-vf", `trim=start_frame=${s0}:end_frame=${s0 + nf},crop=1080:1920:0:1920,scale=${W}:${H}:in_range=full,format=gray`, "-f", "rawvideo", "-"]);
let buf = Buffer.alloc(0); const res = [];
p.stdout.on("data", (c) => {
  buf = Buffer.concat([buf, c]);
  while (buf.length >= W * H) {
    const f = buf.subarray(0, W * H); buf = buf.subarray(W * H);
    let top = H, l = W, r = 0, sx = 0, sy = 0, n = 0;
    for (let y = 0; y < 250; y++) for (let x = 0; x < W; x++) if (f[y * W + x] > 128) {
      if (y < top) top = y; n++; sx += x; sy += y;
    }
    // head width measured on the band 20..70 px below the top of the hair
    for (let y = top + 20; y < Math.min(250, top + 70); y++) for (let x = 0; x < W; x++) if (f[y * W + x] > 128) { if (x < l) l = x; if (x > r) r = x; }
    res.push({ t: +(res.length / 30).toFixed(4), cx: Math.round((sx / n) * K), cy: Math.round((sy / n) * K), top: top * K, l: l * K, r: r * K });
  }
});
p.on("close", () => { fs.writeFileSync(out, JSON.stringify(res)); console.log(res.length, "frames");
  for (const i of [15, 45, 75, 105, 147, 180, 210, 246, 285, 330, 360, 405, 437]) if (res[i]) console.log(i, JSON.stringify(res[i])); });
