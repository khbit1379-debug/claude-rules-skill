// RobustVideoMatting (ResNet50, ONNX) on the GPU through DirectML.
// node rvm.mjs <input> <out.mkv> [--ss sec] [--t sec] [--skip frames] [--ratio 0.25] [--w 1080 --h 1920] [--clean]
// Decodes the input with ffmpeg, runs RVM frame by frame (recurrent state carried across frames),
// and writes a lossless RGBA FFV1 .mkv: RGB = RVM's predicted foreground colour (background spill
// removed from hair), A = alpha matte. --skip warms the recurrent state on pre-roll frames that are
// not written, so the first kept frame already has a settled matte.
import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import { performance } from "node:perf_hooks";

const require = createRequire(import.meta.url);
const cfg = require("../lib/config.cjs");
const { FF } = require("../lib/ff.cjs");
// onnxruntime-node ships DirectML on Windows, so RVM runs on the GPU without CUDA
const ort = createRequire(cfg.nodeModules + "/_.js")("onnxruntime-node");

const MODEL = cfg.models + "/rvm_resnet50_fp32.onnx";

const args = process.argv.slice(2);
const [input, output] = args;
const opt = (k, d) => { const i = args.indexOf("--" + k); return i > -1 ? args[i + 1] : d; };
const W = +opt("w", 1080), H = +opt("h", 1920);
const skip = +opt("skip", 0);
const ratio = +opt("ratio", 0.25);
const ss = opt("ss", null), dur = opt("t", null);
const clean = args.includes("--clean");
const smooth = (e0, e1, x) => { const t = Math.min(1, Math.max(0, (x - e0) / (e1 - e0))); return t * t * (3 - 2 * t); };

const session = await ort.InferenceSession.create(MODEL, { executionProviders: ["dml", "cpu"], graphOptimizationLevel: "all" });
console.log("inputs", session.inputNames.join(","), "outputs", session.outputNames.join(","));

const decArgs = ["-v", "error", ...(ss ? ["-ss", ss] : []), "-i", input, ...(dur ? ["-t", dur] : []),
  "-an", "-vf", `scale=${W}:${H}:in_color_matrix=bt709:flags=lanczos,format=rgb24`, "-f", "rawvideo", "-"];
const dec = spawn(FF, decArgs, { stdio: ["ignore", "pipe", "inherit"] });
// .mkv -> lossless RGBA FFV1 (short clips). .mp4 -> "stacked" H.264: foreground on top, matte (grey) below,
// 1080x3840, full range; a whole take stays a few hundred MB instead of >10 GB. Unstack with
// crop=W:H:0:0 [fg] + crop=W:H:0:H,format=gray [a] + alphamerge.
const stacked = output.endsWith(".mp4");
const enc = stacked
  ? spawn(FF, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", "30", "-i", "-",
      "-filter_complex", `[0]split[c][m];[m]alphaextract,format=rgb24[a];[c]format=rgb24[f];[f][a]vstack,scale=out_color_matrix=bt709:out_range=full,format=yuv420p`,
      "-c:v", "libx264", "-crf", "10", "-preset", "medium", "-color_range", "pc", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", output],
      { stdio: ["pipe", "inherit", "inherit"] })
  : spawn(FF, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", "30", "-i", "-",
      "-c:v", "ffv1", "-level", "3", "-pix_fmt", "bgra", output], { stdio: ["pipe", "inherit", "inherit"] });

const N = W * H, FRAME = N * 3;
const src = new Float32Array(3 * N);
const out = Buffer.alloc(N * 4);
let rec = { r1i: null, r2i: null, r3i: null, r4i: null };
const zero = () => new ort.Tensor("float32", new Float32Array(1), [1, 1, 1, 1]);
for (const k of Object.keys(rec)) rec[k] = zero();
const dsr = new ort.Tensor("float32", new Float32Array([ratio]), [1]);

let pending = Buffer.alloc(0), idx = 0, kept = 0, tInf = 0;
const queue = [];
let busy = false, ended = false;

async function runFrame(buf) {
  for (let i = 0, j = 0; i < N; i++, j += 3) {
    src[i] = buf[j] / 255; src[N + i] = buf[j + 1] / 255; src[2 * N + i] = buf[j + 2] / 255;
  }
  const t0 = performance.now();
  const res = await session.run({ src: new ort.Tensor("float32", src, [1, 3, H, W]), ...rec, downsample_ratio: dsr });
  tInf += performance.now() - t0;
  rec = { r1i: res.r1o, r2i: res.r2o, r3i: res.r3o, r4i: res.r4o };
  if (idx++ < skip) return;
  const fgr = res.fgr.data, pha = res.pha.data;
  for (let i = 0, j = 0; i < N; i++, j += 4) {
    const r = Math.min(1, Math.max(0, fgr[i])), g = Math.min(1, Math.max(0, fgr[N + i])), b = Math.min(1, Math.max(0, fgr[2 * N + i]));
    let a = Math.min(1, Math.max(0, pha[i]));
    if (clean && a < 0.9) {
      // the hair is black: a see-through edge pixel that is near-white and colourless is the white
      // cabinet leaking through the curls, not the subject (skin keeps its saturation, so blurred hands survive)
      const mx = Math.max(r, g, b), sat = mx > 0 ? (mx - Math.min(r, g, b)) / mx : 0;
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      const white = smooth(0.6, 0.78, lum) * (1 - smooth(0.1, 0.2, sat));
      a *= 1 - white * (1 - smooth(0.75, 0.9, a));
    }
    out[j] = Math.round(r * 255);
    out[j + 1] = Math.round(g * 255);
    out[j + 2] = Math.round(b * 255);
    out[j + 3] = Math.round(a * 255);
  }
  kept++;
  if (!enc.stdin.write(Buffer.from(out))) await new Promise((r) => enc.stdin.once("drain", r));
  if (kept % 30 === 0) console.log(`frame ${kept} kept (${(tInf / idx).toFixed(0)} ms/frame inference)`);
}

async function pump() {
  if (busy) return;
  busy = true;
  dec.stdout.pause();
  while (queue.length) await runFrame(queue.shift());
  busy = false;
  if (ended) { enc.stdin.end(); } else dec.stdout.resume();
}

dec.stdout.on("data", (chunk) => {
  pending = Buffer.concat([pending, chunk]);
  while (pending.length >= FRAME) { queue.push(pending.subarray(0, FRAME)); pending = pending.subarray(FRAME); }
  pump();
});
dec.stdout.on("end", () => { ended = true; if (!busy) { (async () => { await pump(); })(); } });
enc.on("close", (code) => console.log(`done: ${kept} frames -> ${output} (exit ${code}), avg ${(tInf / Math.max(1, idx)).toFixed(0)} ms/frame`));
