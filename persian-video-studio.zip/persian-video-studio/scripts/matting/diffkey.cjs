// Alpha-matte a static-camera clip shot on plain paper: difference against a median "clean plate",
// merged (max) with an existing AI matte so fast, motion-blurred limbs are never dropped.
// The plate takes, per pixel, the sampled frame value closest to the known paper image, so the character never leaks into it.
// usage: node diffkey.cjs in.mp4 aiMatte.webm out.webm paper.jpg
const { spawn, execFileSync } = require("child_process");
const fs = require("fs");
const { FF: FFMPEG, FFP: FFPROBE } = require("../lib/ff.cjs");
const [, , inp, ai, out, paperImg] = process.argv;
const W = 1080, H = 1920, N = W * H;
function frames(args, bpp) {
  // returns an async iterator of frame buffers
  const p = spawn(FFMPEG, ["-v", "error", ...args, "-f", "rawvideo", "-"], { stdio: ["ignore", "pipe", "inherit"] });
  const size = N * bpp;
  let buf = Buffer.alloc(0);
  const queue = [], waiters = [];
  let ended = false;
  p.stdout.on("data", (d) => { buf = Buffer.concat([buf, d]); while (buf.length >= size) { const f = buf.subarray(0, size); buf = buf.subarray(size); const fr = Buffer.from(f); if (waiters.length) waiters.shift()(fr); else queue.push(fr); } });
  p.stdout.on("end", () => { ended = true; while (waiters.length) waiters.shift()(null); });
  return { next: () => queue.length ? Promise.resolve(queue.shift()) : ended ? Promise.resolve(null) : new Promise((r) => waiters.push(r)) };
}
(async () => {
  // pass 1: median plate from every 4th frame
  const samples = [];
  const s1 = frames(["-i", inp, "-pix_fmt", "rgb24"], 3);
  for (let k = 0; ; k++) { const f = await s1.next(); if (!f) break; if (k % 4 === 0) samples.push(f); }
  const M = samples.length, plate = Buffer.alloc(N * 3);
  const paper = execFileSync(FFMPEG, ["-v", "error", "-i", paperImg, "-vf", `scale=${W}:${H}`, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], { maxBuffer: 1 << 30 });
  for (let i = 0; i < N; i++) {
    let best = 0, bd = 1e9;
    for (let m = 0; m < M; m++) { const s = samples[m]; const d = Math.abs(s[3 * i] - paper[3 * i]) + Math.abs(s[3 * i + 1] - paper[3 * i + 1]) + Math.abs(s[3 * i + 2] - paper[3 * i + 2]); if (d < bd) { bd = d; best = m; } }
    const s = samples[best]; plate[3 * i] = s[3 * i]; plate[3 * i + 1] = s[3 * i + 1]; plate[3 * i + 2] = s[3 * i + 2];
  }
  samples.length = 0;
  console.log("plate from", M, "frames");
  // pass 2: key every frame
  const enc = spawn(FFMPEG, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", "30", "-i", "-", "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "0", "-crf", "18", "-row-mt", "1", "-auto-alt-ref", "0", out], { stdio: ["pipe", "inherit", "inherit"] });
  const src = frames(["-i", inp, "-pix_fmt", "rgb24"], 3);
  const mat = frames(["-c:v", "libvpx-vp9", "-i", ai, "-pix_fmt", "rgba"], 4);
  const a = new Float32Array(N), b = new Float32Array(N);
  let n = 0;
  for (;;) {
    const f = await src.next(); if (!f) break;
    const m = await mat.next();
    for (let i = 0; i < N; i++) {
      const d = Math.max(Math.abs(f[3 * i] - plate[3 * i]), Math.abs(f[3 * i + 1] - plate[3 * i + 1]), Math.abs(f[3 * i + 2] - plate[3 * i + 2]));
      const t = Math.min(1, Math.max(0, (d - 16) / 30));
      a[i] = t * t * (3 - 2 * t);
    }
    // 3x3 box soften of the difference matte, then max with the AI matte
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; b[i] = (a[i - W - 1] + a[i - W] + a[i - W + 1] + a[i - 1] + a[i] + a[i + 1] + a[i + W - 1] + a[i + W] + a[i + W + 1]) / 9; }
    const o = Buffer.alloc(N * 4);
    for (let i = 0; i < N; i++) {
      const al = Math.max(b[i], m ? m[4 * i + 3] / 255 : 0);
      o[4 * i] = f[3 * i]; o[4 * i + 1] = f[3 * i + 1]; o[4 * i + 2] = f[3 * i + 2]; o[4 * i + 3] = Math.round(al * 255);
    }
    if (!enc.stdin.write(o)) await new Promise((r) => enc.stdin.once("drain", r));
    n++;
  }
  enc.stdin.end();
  await new Promise((r) => enc.on("close", r));
  console.log("keyed", n, "frames ->", out);
})();
