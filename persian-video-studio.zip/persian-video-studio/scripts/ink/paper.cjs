// Deterministic paper texture: warm off-white, soft blotches, fine tooth grain, faint fibres.
// usage: node paper.cjs out.jpg [W=1080] [H=1920] [seed=7]
const { execFileSync } = require("child_process");
const { FF } = require("../lib/ff.cjs");
const [, , out, wArg = "1080", hArg = "1920", sArg = "7"] = process.argv;
const W = +wArg, H = +hArg;
let s = +sArg >>> 0 || 1;
const rnd = () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
function grid(cell, dw = W, dh = H) { // value noise, bilinear, over a dw x dh domain
  const gw = Math.ceil(dw / cell) + 2, gh = Math.ceil(dh / cell) + 2, g = new Float32Array(gw * gh);
  for (let i = 0; i < g.length; i++) g[i] = rnd();
  return (x, y) => { const fx = x / cell, fy = y / cell, x0 = fx | 0, y0 = fy | 0, tx = fx - x0, ty = fy - y0;
    const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
    const a = g[y0 * gw + x0], b = g[y0 * gw + x0 + 1], c = g[(y0 + 1) * gw + x0], d = g[(y0 + 1) * gw + x0 + 1];
    return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy; };
}
const big = grid(520), mid = grid(170), sm = grid(38), fib = grid(9, W * 0.35, H * 1.6);
const base = [0xef, 0xeb, 0xe3];
const buf = Buffer.alloc(W * H * 3);
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  const blot = (big(x, y) - 0.5) * 10 + (mid(x, y) - 0.5) * 6 + (sm(x, y) - 0.5) * 3;
  const tooth = (rnd() - 0.5) * 7 + (fib(x * 0.35, y * 1.6) - 0.5) * 4; // slightly stretched fibres
  const v = blot + tooth;
  const i = (y * W + x) * 3;
  buf[i] = Math.max(0, Math.min(255, base[0] + v));
  buf[i + 1] = Math.max(0, Math.min(255, base[1] + v * 0.98));
  buf[i + 2] = Math.max(0, Math.min(255, base[2] + v * 0.94));
}
execFileSync(FF, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", `${W}x${H}`, "-i", "-", "-frames:v", "1", "-q:v", "3", out], { input: buf });
console.log("paper", W, H);
