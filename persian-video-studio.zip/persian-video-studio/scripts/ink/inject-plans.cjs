// Inline the stroke plans into a composition: replaces __PLANS__ or an existing `const PLANS = {...};` line.
// usage: node inject-plans.cjs compositions/act1.html head=assets/plans/head.json engine=... nozzle=...
const fs = require("fs");
const [, , file, ...pairs] = process.argv;
const plans = {};
for (const p of pairs) { const [k, f] = p.split("="); plans[k] = JSON.parse(fs.readFileSync(f, "utf8")); }
let s = fs.readFileSync(file, "utf8");
const json = JSON.stringify(plans);
if (s.includes("__PLANS__")) s = s.replace("__PLANS__", json);
else s = s.replace(/const PLANS = \{.*\};/, "const PLANS = " + json + ";");
fs.writeFileSync(file, s);
console.log(file, (json.length / 1024).toFixed(1) + " KB of plans");
