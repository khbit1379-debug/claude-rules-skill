// Stroke plan for drawing an ink-alpha image by hand:
//   contours: outer silhouettes (largest first), traced from their top point, smoothed — the hand outlines these first
//   sweeps:   a back-and-forth hatching zigzag from top to bottom, trimmed to the ink extent of each band
// Output JSON in image pixel coordinates.
// usage: node strokeplan.cjs in.png out.json [spacing=150] [maxContours=1] [wave=18] [yFrom=0] [yTo=1]
const fs = require("fs");
const { execFileSync } = require("child_process");
const { FF: FFMPEG, FFP: FFPROBE } = require("../lib/ff.cjs");
const [, , inp, out, sArg = "150", cArg = "1", wArg = "18", yFromArg = "0", yToArg = "1"] = process.argv;
const S = +sArg, MAXC = +cArg, WAVE = +wArg;
const [W, H] = execFileSync(FFPROBE, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", inp]).toString().trim().split(",").map(Number);
const px = execFileSync(FFMPEG, ["-v", "error", "-i", inp, "-f", "rawvideo", "-pix_fmt", "rgba", "-"], { maxBuffer: 1 << 28 });
const F = 4, gw = Math.ceil(W / F), gh = Math.ceil(H / F);
let m = new Uint8Array(gw * gh);
for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
  let mx = 0;
  for (let dy = 0; dy < F; dy++) for (let dx = 0; dx < F; dx++) { const X = x * F + dx, Y = y * F + dy; if (X < W && Y < H) mx = Math.max(mx, px[(Y * W + X) * 4 + 3]); }
  m[y * gw + x] = mx > 60 ? 1 : 0;
}
const yFrom = Math.floor(+yFromArg * gh), yTo = Math.ceil(+yToArg * gh);
for (let y = 0; y < gh; y++) if (y < yFrom || y >= yTo) for (let x = 0; x < gw; x++) m[y * gw + x] = 0;
function dilate(a, r) {
  const t = new Uint8Array(gw * gh), o = new Uint8Array(gw * gh);
  for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) { let v = 0; for (let k = -r; k <= r && !v; k++) { const xx = x + k; if (xx >= 0 && xx < gw && a[y * gw + xx]) v = 1; } t[y * gw + x] = v; }
  for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) { let v = 0; for (let k = -r; k <= r && !v; k++) { const yy = y + k; if (yy >= 0 && yy < gh && t[yy * gw + x]) v = 1; } o[y * gw + x] = v; }
  return o;
}
const invert = (a) => a.map((v) => 1 - v);
// close small gaps and fill holes -> solid silhouettes
const R = 4;
let c = dilate(m, R);
const outside = new Uint8Array(gw * gh), st = [];
const push = (x, y) => { if (x < 0 || y < 0 || x >= gw || y >= gh) return; const i = y * gw + x; if (outside[i] || c[i]) return; outside[i] = 1; st.push(i); };
for (let x = 0; x < gw; x++) { push(x, 0); push(x, gh - 1); }
for (let y = 0; y < gh; y++) { push(0, y); push(gw - 1, y); }
while (st.length) { const i = st.pop(); const x = i % gw, y = (i / gw) | 0; push(x + 1, y); push(x - 1, y); push(x, y + 1); push(x, y - 1); }
let solid = invert(dilate(outside, R)); // erode back
// components
const lab = new Int32Array(gw * gh).fill(-1), comps = [];
for (let i = 0; i < gw * gh; i++) {
  if (!solid[i] || lab[i] >= 0) continue;
  const id = comps.length, q = [i]; lab[i] = id; let n = 0, top = i;
  while (q.length) { const j = q.pop(); n++; if (j < top) top = j; const x = j % gw, y = (j / gw) | 0;
    for (const [xx, yy] of [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]]) { if (xx < 0 || yy < 0 || xx >= gw || yy >= gh) continue; const k = yy * gw + xx; if (solid[k] && lab[k] < 0) { lab[k] = id; q.push(k); } } }
  comps.push({ id, n, top });
}
comps.sort((a, b) => b.n - a.n);
// Moore-neighbour boundary trace starting at the top pixel, heading left (counter-clockwise on screen)
function trace(comp) {
  const inC = (x, y) => x >= 0 && y >= 0 && x < gw && y < gh && lab[y * gw + x] === comp.id;
  const sx = comp.top % gw, sy = (comp.top / gw) | 0;
  const dirs = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
  let x = sx, y = sy, back = 4; // backtrack neighbour is west (outside)
  const pts = [[x, y]];
  for (let guard = 0; guard < gw * gh * 2; guard++) {
    let found = false;
    for (let k = 0; k < 8; k++) {
      const di = (back + 1 + k) % 8; // sweep clockwise from the backtrack direction
      const nx = x + dirs[di][0], ny = y + dirs[di][1];
      if (inC(nx, ny)) { back = (di + 4) % 8; x = nx; y = ny; found = true; break; }
    }
    if (!found) break;
    if (x === sx && y === sy) break;
    pts.push([x, y]);
  }
  return pts;
}
function rdp(pts, eps) {
  if (pts.length < 3) return pts;
  const [a, b] = [pts[0], pts[pts.length - 1]];
  let idx = 0, dm = 0;
  for (let i = 1; i < pts.length - 1; i++) {
    const p = pts[i], dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1;
    const d = Math.abs(dy * p[0] - dx * p[1] + b[0] * a[1] - b[1] * a[0]) / L;
    if (d > dm) { dm = d; idx = i; }
  }
  if (dm <= eps) return [a, b];
  return rdp(pts.slice(0, idx + 1), eps).slice(0, -1).concat(rdp(pts.slice(idx), eps));
}
function chaikin(pts, it) {
  for (let k = 0; k < it; k++) {
    const o = [pts[0]];
    for (let i = 0; i < pts.length - 1; i++) { const [p, q] = [pts[i], pts[i + 1]]; o.push([p[0] * 0.75 + q[0] * 0.25, p[1] * 0.75 + q[1] * 0.25], [p[0] * 0.25 + q[0] * 0.75, p[1] * 0.25 + q[1] * 0.75]); }
    o.push(pts[pts.length - 1]); pts = o;
  }
  return pts;
}
const big = comps.filter((cc) => cc.n > comps[0].n * 0.08).slice(0, MAXC);
const contours = big.map((cc) => {
  let p = trace(cc);
  // simplify a closed curve: split at the point farthest from the start, simplify both halves
  let far = 0, fd = 0;
  p.forEach((q, i) => { const d = Math.hypot(q[0] - p[0][0], q[1] - p[0][1]); if (d > fd) { fd = d; far = i; } });
  const h1 = rdp(p.slice(0, far + 1), 1.2), h2 = rdp(p.slice(far).concat([p[0]]), 1.2);
  p = chaikin(h1.slice(0, -1).concat(h2), 2);
  return p.map(([x, y]) => [+(x * F + F / 2).toFixed(1), +(y * F + F / 2).toFixed(1)]);
});
// sweeps
let top = gh, bot = 0;
for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) if (solid[y * gw + x]) { if (y < top) top = y; if (y > bot) bot = y; }
const y0 = top * F, y1 = (bot + 1) * F;
const nb = Math.max(1, Math.round((y1 - y0) / S));
const s = (y1 - y0) / nb;
// continuous zigzag: vertex k sits on alternating sides at the local ink extent, sweep k runs vertex k -> k+1
const extentAt = (yc) => {
  const ya = Math.max(0, Math.floor((yc - s) / F)), yb = Math.min(gh - 1, Math.ceil((yc + s) / F));
  let l = gw, r = -1;
  for (let y = ya; y <= yb; y++) for (let x = 0; x < gw; x++) if (solid[y * gw + x]) { if (x < l) l = x; if (x > r) r = x; }
  return r < 0 ? null : [l * F - 12, (r + 1) * F + 12];
};
const verts = [];
let lastExt = null;
for (let k = 0; k <= nb; k++) {
  const yc = Math.min(y1 - s * 0.25, y0 + s * 0.5 + k * s);
  const e = extentAt(yc) || lastExt || [0, W];
  lastExt = e;
  verts.push([k % 2 === 0 ? e[1] : e[0], yc]);
}
const sweeps = [];
for (let k = 0; k < nb; k++) {
  const [xa, ya] = verts[k], [xb, yb] = verts[k + 1];
  const L = Math.hypot(xb - xa, yb - ya), n = Math.max(6, Math.round(L / 34));
  const nx = -(yb - ya) / L, ny = (xb - xa) / L;
  const pts = [];
  for (let i = 0; i <= n; i++) {
    const u = i / n, w = Math.sin(u * Math.PI * 2.4 + k * 1.7) * WAVE * Math.sin(u * Math.PI);
    pts.push([+(xa + (xb - xa) * u + nx * w).toFixed(1), +(ya + (yb - ya) * u + ny * w).toFixed(1)]);
  }
  sweeps.push(pts);
}
const plan = { W, H, spacing: +s.toFixed(1), strokeWidth: +(2 * s + 2 * WAVE + 24).toFixed(1), inkTop: y0, inkBottom: y1, contours, sweeps };
fs.writeFileSync(out, JSON.stringify(plan));
console.log(out, "contours", contours.map((c) => c.length), "sweeps", sweeps.length, "spacing", plan.spacing, "width", plan.strokeWidth, "ink y", y0, y1);
