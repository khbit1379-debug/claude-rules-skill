// bbox of dark pixels (< th) inside a search window. usage: node bbox.cjs img x0 y0 x1 y1 [th=70]
const { execFileSync } = require("child_process");
const { FF: FFMPEG, FFP: FFPROBE } = require("../lib/ff.cjs");
const [, , img, ...r] = process.argv;
const [x0, y0, x1, y1, th = 70] = r.map(Number);
const [W, H] = execFileSync(FFPROBE, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", img]).toString().trim().split(",").map(Number);
const g = execFileSync(FFMPEG, ["-v", "error", "-i", img, "-f", "rawvideo", "-pix_fmt", "gray", "-"], { maxBuffer: 1 << 28 });
// per-row extent of the widest dark run through the window centre column
const cx = Math.round((x0 + x1) / 2);
let top = -1, bot = -1, left = W, right = 0;
for (let y = y0; y <= y1; y++) {
  if (g[y * W + cx] >= th) continue;
  let l = cx, rr = cx;
  while (l > x0 && g[y * W + l - 1] < th) l--;
  while (rr < x1 && g[y * W + rr + 1] < th) rr++;
  if (rr - l < 20) continue;
  if (top < 0) top = y; bot = y; left = Math.min(left, l); right = Math.max(right, rr);
}
console.log(JSON.stringify({ W, H, left, top, right, bottom: bot, cx: (left + right) / 2, cy: (top + bot) / 2, w: right - left, h: bot - top }));
