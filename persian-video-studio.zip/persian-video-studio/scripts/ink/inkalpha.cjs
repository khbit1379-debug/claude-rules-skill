// Turn a black-on-white drawing into charcoal ink with alpha: RGB = ink colour, A = darkness.
// Pure paper-white becomes fully transparent, so the drawing sits on any paper without blend modes.
// usage: node inkalpha.cjs in.png out.png [white=242] [inkHex=17130f] [logo]
//   logo mode: keep only the inner ellipse of the image and treat light lettering as paper (holes).
const { execFileSync } = require("child_process");
const { FF: FFMPEG, FFP: FFPROBE } = require("../lib/ff.cjs");
const [, , inp, out, wArg = "242", inkHex = "17130f", mode = ""] = process.argv;
const WHITE = +wArg;
const [W, H] = execFileSync(FFPROBE, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", inp]).toString().trim().split(",").map(Number);
const px = execFileSync(FFMPEG, ["-v", "error", "-i", inp, "-f", "rawvideo", "-pix_fmt", "rgba", "-"], { maxBuffer: 1 << 28 });
const ink = [0, 2, 4].map((o) => parseInt(inkHex.slice(o, o + 2), 16));
const o = Buffer.alloc(W * H * 4);
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  const i = (y * W + x) * 4;
  const lum = 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2];
  let a;
  if (mode === "logo") {
    const ex = (x + 0.5 - W / 2) / (W / 2 * 0.9), ey = (y + 0.5 - H / 2) / (H / 2 * 0.9);
    const edge = Math.max(0, Math.min(1, (1 - Math.sqrt(ex * ex + ey * ey)) * 30));
    a = Math.max(0, Math.min(1, (0.85 * 255 - lum) / ((0.85 - 0.42) * 255))) * edge;
  } else {
    a = Math.max(0, Math.min(1, (WHITE - lum) / WHITE));
  }
  a *= px[i + 3] / 255;
  o[i] = ink[0]; o[i + 1] = ink[1]; o[i + 2] = ink[2]; o[i + 3] = Math.round(a * 255);
}
execFileSync(FFMPEG, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-i", "-", "-frames:v", "1", "-compression_level", "9", out], { input: o });
console.log(out, W, H);
