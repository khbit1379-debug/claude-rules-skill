// "Lines" layer of an ink-alpha PNG: keep only the strong strokes and solid blacks (first drawing pass).
// usage: node lines.cjs in.png out.png [lo=0.42] [hi=0.8]
const { execFileSync } = require("child_process");
const { FF: FFMPEG, FFP: FFPROBE } = require("../lib/ff.cjs");
const [, , inp, out, loA = "0.42", hiA = "0.8"] = process.argv;
const lo = +loA * 255, hi = +hiA * 255;
const [W, H] = execFileSync(FFPROBE, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", inp]).toString().trim().split(",").map(Number);
const px = execFileSync(FFMPEG, ["-v", "error", "-i", inp, "-f", "rawvideo", "-pix_fmt", "rgba", "-"], { maxBuffer: 1 << 28 });
for (let i = 3; i < px.length; i += 4) { const t = Math.max(0, Math.min(1, (px[i] - lo) / (hi - lo))); px[i] = Math.round(255 * t * t * (3 - 2 * t)); }
execFileSync(FFMPEG, ["-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-i", "-", "-frames:v", "1", "-compression_level", "9", out], { input: px });
console.log(out);
