// Build a self-contained storyboard.html from storyboard.src.html: every assets/... reference becomes a data URI
// (images downsized to preview size), so the sheet renders in any viewer, including sandboxed previews.
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");
const { FF } = require("../lib/ff.cjs");
const root = path.resolve(__dirname, "..");
let html = fs.readFileSync(path.join(root, "storyboard.src.html"), "utf8");
const cache = {};
function dataUri(ref) {
  if (cache[ref]) return cache[ref];
  const file = path.join(root, ref);
  const ext = path.extname(ref).toLowerCase();
  let mime, buf;
  if (ext === ".otf" || ext === ".ttf") {
    mime = ext === ".otf" ? "font/otf" : "font/ttf";
    buf = fs.readFileSync(file);
  } else {
    // stage art: 640 px wide WebP keeps alpha; gallery originals: 480 px JPEG
    const gallery = ref.startsWith("assets/gen/");
    const w = gallery ? 480 : ref.endsWith("paper.jpg") ? 540 : 640;
    const args = ["-v", "error", "-i", file, "-vf", `scale='min(${w},iw)':-2:flags=lanczos`, "-frames:v", "1"];
    if (gallery) { mime = "image/jpeg"; args.push("-q:v", "4", "-f", "mjpeg", "-"); }
    else { mime = "image/webp"; args.push("-c:v", "libwebp", "-quality", "82", "-pix_fmt", "yuva420p", "-f", "webp", "-"); }
    buf = execFileSync(FF, args, { maxBuffer: 1 << 26 });
  }
  return (cache[ref] = `data:${mime};base64,${buf.toString("base64")}`);
}
html = html.replace(/(href|src)="(assets\/[^"]+)"/g, (m, attr, ref) => `${attr}="${dataUri(ref)}"`);
html = html.replace(/url\("(assets\/[^"]+)"\)/g, (m, ref) => `url("${dataUri(ref)}")`);
fs.writeFileSync(path.join(root, "storyboard.html"), html);
console.log("storyboard.html", (html.length / 1048576).toFixed(2), "MB,", Object.keys(cache).length, "assets inlined");
