// Is the text really centred in its box? Measures the INK (not the CSS box) inside a box in a rendered frame.
// Persian fonts like Abar sit high in their line box (ascent 1.10em / descent 0.70em), so CSS centring alone leaves
// the letters visibly above centre. Run this on a snapshot after every layout change to a boxed label or caption.
// usage: node measure_text_center.cjs <frame.png> <x0> <y0> <x1> <y1> [--tol 3]
//   x0..y1: a rectangle that lies INSIDE the box's border (the fill area). The box fill colour is taken as the most
//   common colour in that rectangle; ink = pixels much darker than a light fill (or much lighter than a dark fill),
//   so marker highlights and coloured accents are ignored. For a rotated pill, measure a narrow band of columns
//   around its centre (rotation skews the edges), or snapshot it once with rotation 0.
// prints the four gaps between the ink and the rectangle edge plus the vertical/horizontal correction to apply
// (e.g. "move text DOWN 4px" → add 4px to padding-top and remove 4px from padding-bottom, or top: +4px).
const { execFileSync } = require("child_process");
const { FF, FFP } = require("../lib/ff.cjs");
const [, , img, ...rest] = process.argv;
const [x0, y0, x1, y1] = rest.slice(0, 4).map(Number);
const tolI = rest.indexOf("--tol"), TOL = tolI > -1 ? +rest[tolI + 1] : 3;
const [W, H] = execFileSync(FFP, ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", img]).toString().trim().split(",").map(Number);
const px = execFileSync(FF, ["-v", "error", "-i", img, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], { maxBuffer: 1 << 30 });
const at = (x, y) => { const i = (y * W + x) * 3; return [px[i], px[i + 1], px[i + 2]]; };
// fill colour = mode of quantised colours in the rectangle
const hist = new Map();
for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const [r, g, b] = at(x, y); const k = (r >> 3) + "," + (g >> 3) + "," + (b >> 3); hist.set(k, (hist.get(k) || 0) + 1); }
const fill = [...hist.entries()].sort((a, b) => b[1] - a[1])[0][0].split(",").map((v) => v * 8 + 4);
const lum = (c) => 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2];
const fillL = lum(fill), lightFill = fillL > 128;
let t = H, bt = -1, l = W, r = -1;
for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
  const L = lum(at(x, y));
  if (lightFill ? L < fillL - 120 : L > fillL + 120) { if (y < t) t = y; if (y > bt) bt = y; if (x < l) l = x; if (x > r) r = x; }
}
if (bt < 0) { console.log("no ink found in the rectangle"); process.exit(1); }
const gT = t - y0, gB = y1 - 1 - bt, gL = l - x0, gR = x1 - 1 - r;
const dy = (gB - gT) / 2, dx = (gR - gL) / 2;
console.log(`fill rgb(${fill.join(",")})  ink ${l},${t} → ${r},${bt}`);
console.log(`gaps  top ${gT}  bottom ${gB}  left ${gL}  right ${gR}`);
const v = Math.abs(dy) <= TOL ? "vertical OK" : `move text ${dy > 0 ? "DOWN" : "UP"} ${Math.abs(dy).toFixed(1)}px`;
const h = Math.abs(dx) <= TOL ? "horizontal OK" : `move text ${dx > 0 ? "RIGHT" : "LEFT"} ${Math.abs(dx).toFixed(1)}px`;
console.log(`${v}; ${h}`);
process.exit(Math.abs(dy) <= TOL && Math.abs(dx) <= TOL ? 0 : 2);
