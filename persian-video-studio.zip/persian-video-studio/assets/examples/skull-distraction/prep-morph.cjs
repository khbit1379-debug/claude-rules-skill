// Download a Seedance morph clip, conform it to 1080x1920 @ 30 fps, and measure how well its first/last frames
// match the frames it has to join (mean absolute difference per pixel, 0-255; lower is better).
// usage: node tools/prep-morph.cjs <url> <out.mp4> <joinFirst.png|-> <joinLast.png|->
const { execFileSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const [, , url, out, firstRef, lastRef] = process.argv;
const tmp = out.replace(/\.mp4$/, ".src.mp4");
const ff = (args, opts = {}) => execFileSync("ffmpeg", ["-v", "error", "-y", ...args], { maxBuffer: 1 << 28, ...opts });

(async () => {
  const r = await fetch(url);
  if (!r.ok) throw new Error("download " + r.status);
  fs.writeFileSync(tmp, Buffer.from(await r.arrayBuffer()));
  const probe = execFileSync("ffprobe", ["-v", "error", "-show_entries", "stream=width,height,r_frame_rate,nb_frames:format=duration", "-of", "compact", tmp]).toString();
  console.log("source:", probe.trim().replace(/\n/g, " | "));
  ff(["-i", tmp, "-vf", "scale=1080:1920:flags=lanczos,fps=30,format=yuv420p", "-an", "-c:v", "libx264", "-crf", "14", "-preset", "slow", "-movflags", "+faststart", out]);

  const gray = (args) => ff([...args, "-vf", "scale=270:480,format=gray", "-frames:v", "1", "-f", "rawvideo", "-"]);
  const mad = (a, b) => {
    let s = 0;
    for (let i = 0; i < a.length; i++) s += Math.abs(a[i] - b[i]);
    return (s / a.length).toFixed(2);
  };
  const dur = parseFloat(execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", out]).toString());
  if (firstRef && firstRef !== "-") console.log("first frame vs", path.basename(firstRef), "MAD", mad(gray(["-i", out]), gray(["-i", firstRef])));
  if (lastRef && lastRef !== "-") console.log("last frame vs", path.basename(lastRef), "MAD", mad(gray(["-sseof", "-0.05", "-i", out]), gray(["-i", lastRef])));
  console.log("conformed", out, "duration", dur.toFixed(3));
})();
