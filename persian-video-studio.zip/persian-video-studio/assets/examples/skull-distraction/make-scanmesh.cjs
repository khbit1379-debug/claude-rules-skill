// Build a "3D face scan" wireframe that follows the head silhouette in the BEFORE profile photo.
// Output: assets/scan-mesh.svg (1080x1920), lines + vertex dots, deterministic.
const { execFileSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const W = 1080;
const H = 1920;
const raw = execFileSync("ffmpeg", ["-v", "error", "-i", path.join(root, "assets/images/child-before-profile.png"), "-vf", `scale=${W}:${H}`, "-f", "rawvideo", "-pix_fmt", "gray", "-"], { maxBuffer: 64 << 20 });
const lum = (x, y) => raw[Math.round(y) * W + Math.round(x)];

// foreground mask (background is pure black), smoothed by requiring a small neighbourhood
const inside = (x, y) => {
  if (x < 4 || y < 4 || x >= W - 4 || y >= H - 4) return false;
  let c = 0;
  for (let dy = -3; dy <= 3; dy += 3) for (let dx = -3; dx <= 3; dx += 3) if (lum(x + dx, y + dy) > 22) c++;
  return c >= 8;
};

// head band only (the shirt starts lower)
let yTop = H;
let yBottom = 0;
for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 6) if (inside(x, y)) { yTop = Math.min(yTop, y); break; }
yBottom = Math.min(H - 1, yTop + 820);

const S = 30; // lattice spacing
const hash = (i, j) => {
  let h = (i * 374761393 + j * 668265263) ^ 0x5bd1e995;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const pts = new Map();
for (let j = 0; (yTop + j * S * 0.866) <= yBottom; j++) {
  const y0 = yTop + 6 + j * S * 0.866;
  for (let i = 0; i * S < W; i++) {
    const x0 = i * S + (j % 2 ? S / 2 : 0);
    const x = x0 + (hash(i, j) - 0.5) * 9;
    const y = y0 + (hash(j, i) - 0.5) * 9;
    if (inside(x, y)) pts.set(`${i},${j}`, [x, y]);
  }
}
let lines = "";
let dots = "";
const seg = (a, b) => {
  if (!a || !b) return;
  // keep the edge only when its midpoint is inside too
  if (!inside((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)) return;
  lines += `M${a[0].toFixed(1)} ${a[1].toFixed(1)}L${b[0].toFixed(1)} ${b[1].toFixed(1)}`;
};
for (const [k, p] of pts) {
  const [i, j] = k.split(",").map(Number);
  const odd = j % 2;
  seg(p, pts.get(`${i + 1},${j}`));
  seg(p, pts.get(`${odd ? i + 1 : i},${j + 1}`));
  seg(p, pts.get(`${odd ? i : i - 1},${j + 1}`));
  dots += `M${(p[0] - 1.6).toFixed(1)} ${p[1].toFixed(1)}a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0 -3.2 0`;
}
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<path d="${lines}" fill="none" stroke="#7df9ff" stroke-width="1.1" stroke-opacity="0.55"/>
<path d="${dots}" fill="#c9fdff" fill-opacity="0.85"/>
</svg>`;
fs.writeFileSync(path.join(root, "assets/scan-mesh.svg"), svg);
console.log("points", pts.size, "head y", yTop, "-", yBottom, "svg KB", (svg.length / 1024).toFixed(0));
