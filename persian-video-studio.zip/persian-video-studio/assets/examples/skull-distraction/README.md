# Example: 60 s 3D surgery reel (Three.js + HyperFrames + 2 AI morphs)

Final files from the real project («جراح فک و صورت دکتر romeo», scored 7/10 by the user — see
references/3d-threejs.md for what would add the missing detail).

- `index.html` → project root. Scenes: scan 0–3.2, AI morph 3.2–7.2, live 3D 7.2–33.2, AI morph back 33.2–37.2,
  eye guides, profile wipe, before/after, end card. `BRAND` logo slot = `assets/brand/logo.png`.
- `skull-scene.js` → `assets/js/`. Child-proportion warp (`VAULT_SCALE`), `fitPose()` camera fit to the photo
  landmarks (`MATCH`), device built from primitives, GTAO (seeded) + warm CT grade, time table `T`.
- `sfx-cues.json` → `tools/` (cue = [file, start, volume]; starts are set so each file's peak hits the contact).
- Not included: the NIH skull GLB (CC BY, see references), AI photos, morph clips, audio, fonts.
