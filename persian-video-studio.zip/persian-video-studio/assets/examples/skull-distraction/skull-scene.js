// 3D skull + external distraction device, rendered with Three.js and driven only by HyperFrames time.
// Skull: "Skull and Eyes - Visible Human Male" (NIH 3D, 3DPX-020591, CC BY 4.0). Device is built here from primitives.
import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { GTAOPass } from "three/addons/postprocessing/GTAOPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { ShaderPass } from "three/addons/postprocessing/ShaderPass.js";

const W = 1080;
const H = 1920;

// ---- timing (seconds) ------------------------------------------------------------------------------------------
// The 3D section starts at this global time (right after the AI morph photo -> skull); tau = t - OFFSET.
// tau 0 and tau END are "matched" poses: the camera is fitted so the skull sits exactly on the head in the
// before/after profile photos, which makes the AI morph clips (photo <-> skull) join the live 3D without a jump.
export const OFFSET = 7.2;
export const END = 26.0;
export const T = {
  intro: [0.3, 1.8], // matched pose -> working framing
  redPulse: [1.2, 3.8],
  bar: [3.6, 4.6],
  screws: [
    [4.4, 5.4],
    [4.9, 5.9],
    [5.4, 6.4],
  ],
  post: [6.5, 7.4],
  arms: [7.3, 8.3],
  drivers: [
    { in: [8.5, 8.9], turn: [8.9, 9.7], out: [9.7, 10.1] },
    { in: [11.0, 11.4], turn: [11.4, 12.2], out: [12.2, 12.6] },
  ],
  adv1: [9.2, 10.8],
  adv2: [11.8, 14.0],
  orbit: [14.0, 17.0],
  unscrew: [
    [17.4, 18.4],
    [17.7, 18.7],
    [18.0, 19.0],
  ],
  armsOut: [18.8, 19.5],
  postOut: [19.3, 20.1],
  barOut: [19.8, 20.7],
  greenGlow: [20.8, 23.0],
  push: [20.7, 22.6],
  outro: [22.6, 25.0], // working framing -> matched pose for the after photo
};
// Where the bone landmarks must land on screen (px) in the two profile photos: soft-tissue nasion/menton measured on
// the photos, moved ~7 mm (nasion) and ~10 mm (chin) inside to reach the bone.
const MATCH = {
  before: { nasion: [301, 895], menton: [302, 1222] },
  after: { nasion: [320, 900], menton: [320, 1224] },
};

const clamp01 = (x) => Math.min(1, Math.max(0, x));
const seg = (t, [a, b]) => clamp01((t - a) / (b - a));
const easeOut = (x) => 1 - Math.pow(1 - x, 3);
const easeIn = (x) => x * x * x;
const easeInOut = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const easeOutBack = (x) => {
  const c1 = 1.4;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};
const lerp = (a, b, k) => a + (b - a) * k;

// ---- renderer / scene -------------------------------------------------------------------------------------------
const canvas = document.getElementById("three-layer");
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(1);
renderer.setSize(W, H, false);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.setClearColor(0x000000, 1);

const scene = new THREE.Scene();
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.45;

const camera = new THREE.PerspectiveCamera(24, W / H, 1, 600);

const key = new THREE.DirectionalLight(0xfff1dc, 2.6);
key.castShadow = true;
key.shadow.mapSize.set(2048, 2048);
key.shadow.bias = -0.0004;
key.shadow.normalBias = 0.02;
scene.add(key, key.target);
const rim = new THREE.DirectionalLight(0xbfd6ff, 1.6);
scene.add(rim, rim.target);
const fill = new THREE.HemisphereLight(0xfff4e6, 0x1a1410, 0.55);
scene.add(fill);

// ---- post: ambient occlusion in the crevices + warm "CT" grade --------------------------------------------------
// GTAO builds its noise with SimplexNoise(Math.random); seed it so every render worker gets identical frames.
function seeded(seed, fn) {
  const orig = Math.random;
  let a = seed >>> 0;
  Math.random = () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  try {
    return fn();
  } finally {
    Math.random = orig;
  }
}
const composer = new EffectComposer(renderer);
composer.setPixelRatio(1);
composer.setSize(W, H);
composer.addPass(new RenderPass(scene, camera));
const gtao = seeded(7, () => new GTAOPass(scene, camera, W, H));
gtao.output = GTAOPass.OUTPUT.Default;
gtao.blendIntensity = 1.0;
gtao.updateGtaoMaterial({ radius: 4.5, distanceExponent: 2.0, thickness: 6.0, scale: 1.7, samples: 24 });
gtao.updatePdMaterial({ lumaPhi: 10, depthPhi: 2, normalPhi: 3, radius: 6, rings: 2, samples: 16 });
composer.addPass(gtao);
composer.addPass(new OutputPass());
// Warm split-tone on low-saturation pixels (bone): shadows go amber-brown like a CT volume render; purple stays purple.
const grade = new ShaderPass({
  uniforms: { tDiffuse: { value: null } },
  vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
  fragmentShader: `
    uniform sampler2D tDiffuse; varying vec2 vUv;
    void main(){
      vec4 c = texture2D(tDiffuse, vUv);
      float mx = max(c.r, max(c.g, c.b)); float mn = min(c.r, min(c.g, c.b));
      float sat = mx > 0.001 ? (mx - mn) / mx : 0.0;
      float lum = dot(c.rgb, vec3(0.299, 0.587, 0.114));
      float boneMask = 1.0 - smoothstep(0.38, 0.55, sat);
      vec3 shadowTone = c.rgb * vec3(1.18, 0.78, 0.42);
      vec3 midTone = c.rgb * vec3(1.06, 0.97, 0.80);
      vec3 g = mix(shadowTone, midTone, smoothstep(0.12, 0.62, lum));
      g = mix(g, c.rgb * vec3(1.02, 1.0, 0.95), smoothstep(0.7, 0.95, lum));
      c.rgb = mix(c.rgb, g, boneMask);
      gl_FragColor = c;
    }`,
});
composer.addPass(grade);

// ---- materials --------------------------------------------------------------------------------------------------
const purple = new THREE.MeshPhysicalMaterial({
  color: 0x9b30d9,
  metalness: 0.7,
  roughness: 0.3,
  clearcoat: 0.6,
  clearcoatRoughness: 0.25,
});
const steel = new THREE.MeshStandardMaterial({ color: 0xc8ccd2, metalness: 1, roughness: 0.28 });
const darkSteel = new THREE.MeshStandardMaterial({ color: 0x2a2b2f, metalness: 0.9, roughness: 0.38 });
const holeMat = new THREE.MeshStandardMaterial({ color: 0x0b0b0d, metalness: 0.4, roughness: 0.6 });

// ---- helpers ----------------------------------------------------------------------------------------------------
class Helix extends THREE.Curve {
  constructor(radius, length, turns) {
    super();
    this.r = radius;
    this.len = length;
    this.turns = turns;
  }
  getPoint(t, target = new THREE.Vector3()) {
    const a = t * this.turns * Math.PI * 2;
    return target.set(this.r * Math.cos(a), -t * this.len, this.r * Math.sin(a));
  }
}

// A screw pointing down (-Y): head top at y=0, tip at y=-len.
function makeScrew(len, r, mat) {
  const g = new THREE.Group();
  const core = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.35, len, 20), mat);
  core.position.y = -len / 2 - 0.25;
  const thread = new THREE.Mesh(
    new THREE.TubeGeometry(new Helix(r * 1.08, len * 0.92, Math.round(len * 2.4)), Math.round(len * 60), r * 0.32, 6),
    mat,
  );
  thread.position.y = -0.3;
  const head = new THREE.Mesh(new THREE.CylinderGeometry(r * 2.3, r * 2.0, 0.42, 28), mat);
  head.position.y = -0.21;
  const socket = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.95, r * 0.95, 0.06, 6), holeMat);
  socket.position.y = 0.0;
  g.add(core, thread, head, socket);
  g.traverse((o) => o.isMesh && (o.castShadow = true));
  return g;
}

function roundedRect(w, h, r) {
  const s = new THREE.Shape();
  s.moveTo(-w / 2 + r, -h / 2);
  s.lineTo(w / 2 - r, -h / 2);
  s.quadraticCurveTo(w / 2, -h / 2, w / 2, -h / 2 + r);
  s.lineTo(w / 2, h / 2 - r);
  s.quadraticCurveTo(w / 2, h / 2, w / 2 - r, h / 2);
  s.lineTo(-w / 2 + r, h / 2);
  s.quadraticCurveTo(-w / 2, h / 2, -w / 2, h / 2 - r);
  s.lineTo(-w / 2, -h / 2 + r);
  s.quadraticCurveTo(-w / 2, -h / 2, -w / 2 + r, -h / 2);
  return s;
}

const VAULT_SCALE = { x: 1.45, y: 1.68, z: 1.38 }; // tall vault, like Crouzon turribrachycephaly
const FIT_SPREAD = 1.08; // child proportions: big cranium, small face
const norm = (s) => (s || "").toLowerCase().replace(/[_\s]+/g, " ");
const MIDFACE = ["maxilla", "zygomatic", "nasal", "lacrimal", "palatine", "vomer", "upper teeth"];
const JAW = ["mandible", "lower teeth"];

// ---- scene state filled by build() -----------------------------------------------------------------------------
const S = { ready: false };

function build(gltfRoot) {
  const oriented = new THREE.Group();
  oriented.add(gltfRoot);
  const skullRoot = new THREE.Group();
  skullRoot.add(oriented);
  scene.add(skullRoot);
  skullRoot.updateMatrixWorld(true);

  const meshes = [];
  gltfRoot.traverse((o) => {
    if (!o.isMesh) return;
    const name = norm(o.name);
    if (name.includes("eye")) {
      o.visible = false;
      return;
    }
    meshes.push(o);
  });
  const find = (word) => meshes.filter((m) => norm(m.name).includes(word));
  const centerOf = (list) => {
    const b = new THREE.Box3();
    list.forEach((m) => b.expandByObject(m));
    return b.getCenter(new THREE.Vector3());
  };

  // Orient: face -> screen left (-X), crown -> up (+Y), no mirroring.
  const f = centerOf(find("maxilla")).sub(centerOf(find("occipital"))).normalize();
  const u = centerOf(find("parietal").concat(find("pareital"))).sub(centerOf(find("mandible")));
  u.sub(f.clone().multiplyScalar(u.dot(f))).normalize();
  const s = new THREE.Vector3().crossVectors(f, u);
  const B = new THREE.Matrix4().makeBasis(f, u, s);
  const Tm = new THREE.Matrix4().makeBasis(new THREE.Vector3(-1, 0, 0), new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 0, -1));
  const R = Tm.multiply(B.clone().transpose());
  oriented.setRotationFromMatrix(R);
  skullRoot.updateMatrixWorld(true);
  const box0 = new THREE.Box3();
  meshes.forEach((m) => box0.expandByObject(m));
  oriented.position.sub(box0.getCenter(new THREE.Vector3()));
  skullRoot.updateMatrixWorld(true);

  // Bake every bone into world space, then make the adult skull child-like: a smooth spatial warp enlarges the
  // cranial vault (behind/above the face) while the face and jaw keep their size. The field is continuous, so
  // neighbouring bones move together and no gaps open at the sutures.
  meshes.forEach((m) => {
    m.geometry = m.geometry.clone();
    m.geometry.applyMatrix4(m.matrixWorld);
    m.position.set(0, 0, 0);
    m.quaternion.identity();
    m.scale.set(1, 1, 1);
    skullRoot.add(m);
  });
  skullRoot.updateMatrixWorld(true);
  const C = centerOf(find("sphenoid"));
  const smooth = (e0, e1, x) => {
    const u = clamp01((x - e0) / (e1 - e0));
    return u * u * (3 - 2 * u);
  };
  const v = new THREE.Vector3();
  meshes.forEach((m) => {
    const pos = m.geometry.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      v.fromBufferAttribute(pos, i).sub(C);
      const front = smooth(-1.0, -5.0, v.x); // 1 well in front of the cranial base
      const low = smooth(2.0, -1.5, v.y); // 1 below the orbit roof
      const jaw = smooth(-1.5, -4.0, v.y); // 1 well below: mandible and teeth
      const face = Math.max(front * low, jaw);
      const kx = THREE.MathUtils.lerp(VAULT_SCALE.x, 1.0, face);
      const ky = THREE.MathUtils.lerp(VAULT_SCALE.y, 1.0, face);
      const kz = THREE.MathUtils.lerp(VAULT_SCALE.z, 1.0, face);
      pos.setXYZ(i, C.x + v.x * kx, C.y + v.y * ky, C.z + v.z * kz);
    }
    pos.needsUpdate = true;
    m.geometry.computeBoundingBox();
    m.geometry.computeBoundingSphere();
  });
  skullRoot.updateMatrixWorld(true);

  // Bone material: warm CT-ivory, keeps the scan's normal map.
  const boneMats = new Map();
  meshes.forEach((m) => {
    const src = m.material;
    const isTooth = norm(m.name).includes("teeth");
    const mat = new THREE.MeshPhysicalMaterial({
      color: isTooth ? 0xf1e6cc : 0xe2c48a,
      map: src.map || null,
      normalMap: src.normalMap || null,
      normalScale: src.normalScale ? src.normalScale.clone().multiplyScalar(1.3) : new THREE.Vector2(1, 1),
      roughness: isTooth ? 0.32 : 0.58,
      metalness: 0,
      clearcoat: 0.18,
      clearcoatRoughness: 0.5,
      sheen: 0.4,
      sheenColor: new THREE.Color(0xffd29a),
      sheenRoughness: 0.6,
      emissive: new THREE.Color(0x000000),
    });
    m.material = mat;
    m.castShadow = true;
    m.receiveShadow = true;
    boneMats.set(m, mat);
  });

  // Moving groups (attach() keeps world placement).
  const midGroup = new THREE.Group();
  skullRoot.add(midGroup);
  const midMeshes = meshes.filter((m) => MIDFACE.some((w) => norm(m.name).includes(w)));
  midMeshes.forEach((m) => midGroup.attach(m));
  const jawMeshes = meshes.filter((m) => JAW.some((w) => norm(m.name).includes(w)));
  const jawBox = new THREE.Box3();
  jawMeshes.forEach((m) => jawBox.expandByObject(m));
  const jawPivot = new THREE.Group();
  jawPivot.position.set(jawBox.max.x - 1.2, jawBox.max.y - 1.0, 0);
  skullRoot.add(jawPivot);
  skullRoot.updateMatrixWorld(true);
  jawMeshes.forEach((m) => jawPivot.attach(m));

  const sb = new THREE.Box3();
  meshes.forEach((m) => sb.expandByObject(m));
  const mb = new THREE.Box3();
  midMeshes.forEach((m) => mb.expandByObject(m));
  const front = sb.min.x;
  const back = sb.max.x;
  const top = sb.max.y;
  const bottom = sb.min.y;
  const side = sb.max.z;

  // Front-most bone point at the midline for a given height (where the device wires go in).
  const ray = new THREE.Raycaster();
  const hitFront = (y) => {
    ray.set(new THREE.Vector3(front - 20, y, 0), new THREE.Vector3(1, 0, 0));
    const h = ray.intersectObjects(midMeshes, false)[0];
    return h ? h.point.clone() : new THREE.Vector3(mb.min.x + 0.6, y, 0);
  };

  // ---- device ----
  const device = new THREE.Group();
  skullRoot.add(device);
  const barY = mb.max.y + (top - mb.max.y) * 0.2;
  const barZ = side + 0.35;
  const postX = front - 2.9;
  const barX0 = postX - 0.4;
  const barX1 = front + (back - front) * 0.6;
  const barLen = barX1 - barX0;

  // lateral cranial bar with real holes
  const barShape = roundedRect(barLen, 0.95, 0.35);
  const holeXs = [];
  for (let i = 0; i < 6; i++) holeXs.push(barLen / 2 - 0.75 - i * 0.95);
  holeXs.forEach((hx) => {
    const p = new THREE.Path();
    p.absarc(hx, 0, 0.24, 0, Math.PI * 2, true);
    barShape.holes.push(p);
  });
  const barGeo = new THREE.ExtrudeGeometry(barShape, { depth: 0.4, bevelEnabled: true, bevelSize: 0.06, bevelThickness: 0.06, bevelSegments: 3, curveSegments: 24 });
  barGeo.translate(0, 0, -0.2);
  const bar = new THREE.Mesh(barGeo, purple);
  bar.castShadow = true;
  const barGroup = new THREE.Group();
  barGroup.add(bar);
  // two dark knobs near the front of the bar (locking screws)
  [0, 1].forEach((i) => {
    const k = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.3, 28), darkSteel);
    k.rotation.x = Math.PI / 2;
    k.position.set(-barLen / 2 + 1.6 + i * 0.9, 0, 0.34);
    k.castShadow = true;
    barGroup.add(k);
  });
  // cross piece from the lateral bar to the midline post (seen nearly end-on)
  const cross = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.95, barZ + 0.3), purple);
  cross.position.set(-barLen / 2 + 0.45, 0, -(barZ + 0.3) / 2 + 0.2);
  cross.castShadow = true;
  barGroup.add(cross);
  barGroup.position.set(barX0 + barLen / 2, barY, barZ);
  device.add(barGroup);

  // screws dropping into the posterior holes
  const screwLen = 4.2;
  const screws = [0, 2, 4].map((hi) => {
    const sc = makeScrew(screwLen, 0.17, darkSteel);
    const hx = barGroup.position.x + holeXs[hi];
    device.add(sc);
    return { obj: sc, x: hx, y: barY + 0.55, z: barZ - 0.05 };
  });

  // vertical post at the midline in front of the face
  const postTop = barY + 0.9;
  const postBottom = mb.min.y - 1.1;
  const postLen = postTop - postBottom;
  const postGroup = new THREE.Group();
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, postLen, 20), steel);
  rod.position.y = -postLen / 2;
  const rodThread = new THREE.Mesh(new THREE.TubeGeometry(new Helix(0.17, postLen * 0.96, Math.round(postLen * 5)), Math.round(postLen * 90), 0.035, 5), steel);
  rodThread.position.y = -postLen * 0.02;
  const rail = new THREE.Mesh(new THREE.BoxGeometry(0.22, postLen, 0.5), darkSteel);
  rail.position.set(0.42, -postLen / 2, 0);
  const capTop = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.7, 1.0), purple);
  capTop.position.y = -0.2;
  const capBottom = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.55, 0.9), purple);
  capBottom.position.y = -postLen + 0.25;
  const actScrew = new THREE.Group();
  const actHead = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.36, 6), steel);
  actHead.position.y = 0.33;
  actScrew.add(actHead);
  postGroup.add(rod, rodThread, rail, capTop, capBottom, actScrew);
  postGroup.traverse((o) => o.isMesh && (o.castShadow = true));
  postGroup.position.set(postX, postTop, 0);
  device.add(postGroup);

  // carriage: two clamps on the post with arms and wires into the midface; moves forward with the bone
  const carriage = new THREE.Group();
  device.add(carriage);
  const levels = [mb.max.y - 2.4, mb.min.y + 0.9];
  const armParts = [];
  levels.forEach((y) => {
    const tip = hitFront(y);
    const clamp = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.75, 0.85), purple);
    clamp.position.set(postX, y, 0);
    const knob = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.5, 6), darkSteel);
    knob.rotation.x = Math.PI / 2;
    knob.position.set(postX, y, 0.62);
    const armLen = tip.x - 0.35 - (postX + 0.42);
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, armLen, 12), steel);
    arm.rotation.z = Math.PI / 2;
    arm.position.set(postX + 0.42 + armLen / 2, y, 0);
    const wire = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.2, 8), steel);
    wire.rotation.z = Math.PI / 2;
    wire.position.set(tip.x + 0.2, y, 0);
    // purple traction rod coming in from the left edge
    const pr = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 9, 20), purple);
    pr.rotation.z = Math.PI / 2;
    pr.position.set(postX - 0.45 - 4.5, y, 0.1);
    const grp = new THREE.Group();
    grp.add(clamp, knob, arm, wire, pr);
    grp.traverse((o) => o.isMesh && (o.castShadow = true));
    carriage.add(grp);
    armParts.push({ grp, y, armLen, arm, wire, pr });
  });

  // screwdriver for the activation screw
  const driver = new THREE.Group();
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 3.2, 12), steel);
  shaft.position.y = 1.6;
  const tipHex = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.3, 6), steel);
  tipHex.position.y = 0.15;
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.48, 3.4, 32), purple);
  handle.position.y = 3.2 + 1.7;
  const ferrule = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.5, 24), darkSteel);
  ferrule.position.y = 3.2 + 0.1;
  driver.add(shaft, tipHex, handle, ferrule);
  driver.traverse((o) => o.isMesh && (o.castShadow = true));
  device.add(driver);

  // lights relative to the skull
  const c = sb.getCenter(new THREE.Vector3());
  key.position.set(c.x - 22, c.y + 22, c.z + 70);
  key.target.position.copy(c);
  const sc = key.shadow.camera;
  sc.left = -22;
  sc.right = 22;
  sc.top = 22;
  sc.bottom = -22;
  sc.near = 10;
  sc.far = 120;
  sc.updateProjectionMatrix();
  rim.position.set(c.x + 30, c.y + 10, c.z - 25);
  rim.target.position.copy(c);

  // camera framing: skull height ~58% of the frame, face about 30% from the left edge
  const visH = (top - bottom) / 0.6;
  const visW = (visH * W) / H;
  const dist = visH / 2 / Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
  const target = new THREE.Vector3(front + 0.2 * visW, (top + bottom) / 2 - visH * 0.02, 0);

  Object.assign(S, {
    ready: true,
    skullRoot,
    midGroup,
    midMats: midMeshes.map((m) => boneMats.get(m)),
    allMats: [...boneMats.values()],
    jawPivot,
    barGroup,
    barHome: barGroup.position.clone(),
    screws,
    postGroup,
    postHome: postGroup.position.clone(),
    actScrew,
    carriage,
    armParts,
    driver,
    postX,
    postTop,
    dist,
    target,
    front,
    D0: 0.9,
    D1: 0.55,
  });

  // ---- matched poses for the morph joins --------------------------------------------------------------------------
  const nasalMeshes = midMeshes.filter((m) => norm(m.name).includes("nasal"));
  const mandMeshes = jawMeshes.filter((m) => norm(m.name).includes("mandible"));
  const worldVerts = (list) => {
    const out = [];
    const v = new THREE.Vector3();
    list.forEach((m) => {
      const pos = m.geometry.attributes.position;
      for (let i = 0; i < pos.count; i++) out.push(v.fromBufferAttribute(pos, i).applyMatrix4(m.matrixWorld).clone());
    });
    return out;
  };
  const landmarks = (mid, jawDeg) => {
    S.midGroup.position.x = mid;
    S.jawPivot.rotation.z = THREE.MathUtils.degToRad(jawDeg);
    skullRoot.updateMatrixWorld(true);
    const nv = worldVerts(nasalMeshes);
    const nTop = Math.max(...nv.map((p) => p.y));
    const nasion = nv.filter((p) => p.y > nTop - 0.45).reduce((a, p) => (p.x < a.x ? p : a));
    const mv = worldVerts(mandMeshes);
    const mFront = Math.min(...mv.map((p) => p.x));
    const menton = mv.filter((p) => p.x < mFront + 1.6).reduce((a, p) => (p.y < a.y ? p : a));
    return { nasion, menton };
  };
  S.P0 = fitPose(landmarks(S.D0, 5), MATCH.before);
  S.PE = fitPose(landmarks(-S.D1, 2), MATCH.after);
  window.__skullDebug = { P0: S.P0, PE: S.PE };
}

function setCam(p) {
  const d = p.dist;
  camera.position.set(p.tx + Math.sin(p.yaw) * d, p.ty + p.elev * d, Math.cos(p.yaw) * d);
  camera.up.set(Math.sin(p.roll), Math.cos(p.roll), 0);
  camera.lookAt(p.tx, p.ty, 0);
  camera.updateMatrixWorld(true);
}
function toPx(v) {
  const q = v.clone().project(camera);
  return [(q.x * 0.5 + 0.5) * W, (-q.y * 0.5 + 0.5) * H];
}
// Solve camera distance / target / roll so world landmarks N, M project onto screen points n, m (yaw 0, level).
function fitPose(lm, tgt) {
  const N = lm.nasion;
  const M = lm.menton;
  // spread the targets a little about their midpoint: the bony face sits slightly larger than the soft-tissue
  // landmarks, which also lets the (warped) vault fill the child's head
  const cxm = (tgt.nasion[0] + tgt.menton[0]) / 2;
  const cym = (tgt.nasion[1] + tgt.menton[1]) / 2;
  const sp = (q) => [cxm + (q[0] - cxm) * FIT_SPREAD, cym + (q[1] - cym) * FIT_SPREAD];
  const n = sp(tgt.nasion);
  const m = sp(tgt.menton);
  const p = { tx: N.x, ty: (N.y + M.y) / 2, dist: S.dist * 1.6, yaw: 0, roll: 0, elev: 0 };
  const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));
  let err = 0;
  for (let i = 0; i < 60; i++) {
    setCam(p);
    let a = toPx(N);
    let b = toPx(M);
    p.dist *= Math.hypot(b[0] - a[0], b[1] - a[1]) / Math.hypot(m[0] - n[0], m[1] - n[1]);
    p.roll += wrap(Math.atan2(b[1] - a[1], b[0] - a[0]) - Math.atan2(m[1] - n[1], m[0] - n[0]));
    setCam(p);
    a = toPx(N);
    b = toPx(M);
    const cx = (a[0] + b[0]) / 2 - (n[0] + m[0]) / 2;
    const cy = (a[1] + b[1]) / 2 - (n[1] + m[1]) / 2;
    const wpp = (2 * p.dist * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2))) / H;
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
    const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
    p.tx += (right.x * cx - up.x * cy) * wpp;
    p.ty += (right.y * cx - up.y * cy) * wpp;
    setCam(p);
    a = toPx(N);
    b = toPx(M);
    err = Math.max(Math.hypot(a[0] - n[0], a[1] - n[1]), Math.hypot(b[0] - m[0], b[1] - m[1]));
  }
  p.err = +err.toFixed(2);
  return p;
}

// ---- per-frame state -------------------------------------------------------------------------------------------
let lastTau = null;
function renderAt(globalT) {
  if (!S.ready) {
    composer.render();
    return;
  }
  // outside the 3D section nothing is visible (its wrapper is hidden): keep the last frame, skip the GPU work
  if (globalT < OFFSET - 1.0 || globalT > OFFSET + END + 1.0) return;
  const t = Math.min(END, Math.max(0, globalT - OFFSET));
  if (t === lastTau) return;
  lastTau = t;

  // camera: matched pose -> working framing (slow push, a little yaw, a 30-degree orbit, a push on the result)
  // -> matched pose for the after photo
  const k = easeInOut(clamp01((t - 0.3) / 14));
  const orbit = Math.sin(Math.PI * easeInOut(seg(t, T.orbit)));
  const push = easeInOut(seg(t, T.push));
  const work = {
    tx: S.target.x,
    ty: S.target.y - 0.6 * push,
    dist: S.dist * (lerp(1.1, 0.98, k) + 0.06 * orbit - 0.1 * push),
    yaw: THREE.MathUtils.degToRad(lerp(-6, 0, k) + 30 * orbit),
    roll: 0,
    elev: 0.06 + 0.03 * orbit,
  };
  const mix = (A, B, w) => Object.fromEntries(Object.keys(B).map((key) => [key, lerp(A[key] ?? B[key], B[key], w)]));
  let pose = mix(S.P0, work, easeInOut(seg(t, T.intro)));
  pose = mix(pose, S.PE, easeInOut(seg(t, T.outro)));
  setCam(pose);
  renderer.toneMappingExposure = 1.0;

  // mouth slightly open (Crouzon kids rest with lips apart); closes a little once the midface is forward
  const advAll = 0.45 * easeInOut(seg(t, T.adv1)) + 0.55 * easeInOut(seg(t, T.adv2));
  S.jawPivot.rotation.z = THREE.MathUtils.degToRad(lerp(5, 2, advAll));

  // deficiency glow (red) at the start, healthy glow (green) on the result
  const pk = seg(t, T.redPulse);
  const red = pk > 0 && pk < 1 ? Math.sin(pk * Math.PI) * (0.55 + 0.45 * Math.sin(t * 9)) : 0;
  const gk = seg(t, T.greenGlow);
  const green = gk > 0 && gk < 1 ? Math.sin(gk * Math.PI) * 0.8 : 0;
  S.midMats.forEach((m) => m.emissive.setRGB(0.55 * red + 0.16 * green, 0.04 * red + 0.15 * green, 0.02 * red + 0.12 * green));

  // midface: starts retruded (+X = backwards), two activation steps bring it forward
  const mx = lerp(S.D0, -S.D1, advAll);
  S.midGroup.position.x = mx;

  // bar slides in from the right, leaves to the right
  const bk = easeOut(seg(t, T.bar));
  const bo = easeIn(seg(t, T.barOut));
  S.barGroup.visible = bk > 0 && bo < 1;
  S.barGroup.position.x = S.barHome.x + lerp(28, 0, bk) + lerp(0, 30, bo);

  // screws: drop in while turning; after 4 months they turn back out and rise away
  S.screws.forEach((s, i) => {
    const sk = seg(t, T.screws[i]);
    const uk = seg(t, T.unscrew[i]);
    s.obj.visible = sk > 0 && uk < 1;
    const drop = easeOut(sk);
    const lift = easeIn(uk);
    s.obj.position.set(s.x, s.y + lerp(16, 0, drop) + lerp(0, 18, lift), s.z);
    s.obj.rotation.y = -drop * Math.PI * 8 + lift * Math.PI * 8;
  });

  // post drops from the top, rises away at the end
  const pin = easeOutBack(seg(t, T.post));
  const pout = easeIn(seg(t, T.postOut));
  S.postGroup.visible = seg(t, T.post) > 0 && pout < 1;
  S.postGroup.position.y = S.postHome.y + lerp(22, 0, pin) + lerp(0, 26, pout);

  // clamps/arms slide in from the left, ride forward with the bone, slide out to the left
  const ak = easeOut(seg(t, T.arms));
  const ao = easeIn(seg(t, T.armsOut));
  S.carriage.visible = ak > 0 && ao < 1;
  S.carriage.position.x = lerp(-16, 0, ak) + (mx - S.D0) + lerp(0, -18, ao);

  // screwdriver: two activation turns
  let dv = false;
  let dy = 14;
  let rot = 0;
  T.drivers.forEach((dr, i) => {
    const din = easeOut(seg(t, dr.in));
    const dout = easeInOut(seg(t, dr.out));
    const turn = easeInOut(seg(t, dr.turn));
    rot += turn * Math.PI * 3;
    if (din > 0 && dout < 1) {
      dv = true;
      dy = lerp(14, 0, din) + lerp(0, 14, dout);
    }
  });
  S.driver.visible = dv;
  S.driver.position.set(S.postX, S.postTop + 0.5 + dy, 0);
  S.driver.rotation.y = rot;
  S.actScrew.rotation.y = rot;

  composer.render();
}

// ---- load + HyperFrames wiring -----------------------------------------------------------------------------------
const loaded = new Promise((resolve, reject) => {
  new GLTFLoader().load(
    "assets/models/vh-skull.glb",
    (g) => {
      build(g.scene);
      renderAt(window.__hfThreeTime || 0);
      resolve();
    },
    undefined,
    reject,
  );
});
window.__hf = window.__hf || {};
window.__hf.buildReady = window.__hf.buildReady || {};
window.__hf.buildReady.skull = loaded;

window.addEventListener("hf-seek", (e) => renderAt(e.detail.time));
renderAt(window.__hfThreeTime || 0);
