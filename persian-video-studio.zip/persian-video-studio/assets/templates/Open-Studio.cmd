@echo off
chcp 65001 >nul
title HyperFrames Studio
cd /d "%~dp0"
echo.
echo   HyperFrames Studio - this project
echo   Browser: http://localhost:3003
echo   Close this window to stop the server.
echo.
rem  keep the same hyperframes version as package.json
call npx --yes hyperframes@0.8.79 preview --port 3003
pause
