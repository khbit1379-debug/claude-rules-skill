// Charcoal Kit — the one hand that draws everything in this reel.
// Shared by every act composition: builds drawings that are revealed by charcoal strokes (SVG masks with
// pathLength=1 dash reveals) while the hand's charcoal tip rides the same paths with the same eases
// (MotionPathPlugin), sheds a little dust, and travels between strokes with a small lift.
// Everything is added to the caller's paused timeline; nothing reads clocks or randomness.
(function () {
  const NS = "http://www.w3.org/2000/svg";

  window.CharcoalKit = function (tl, cfg) {
    // cfg: { hand, handRot, dust (svg <g>), mrough ("url(#…)"), rough ("url(#…)"), rot, dustSeed, travelRate (px/s), travelMax (s) }
    const K = {};
    const prand = (n) => {
      const s = Math.sin(n * 12.9898 + 78.233) * 43758.5453;
      return s - Math.floor(s);
    };
    const make = (tag, attrs, parent) => {
      const e = document.createElementNS(NS, tag);
      for (const k in attrs) e.setAttribute(k, attrs[k]);
      if (parent) parent.appendChild(e);
      return e;
    };
    const dOf = (pts) => "M" + pts.map((p) => p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" L");
    const lengths = (pts) => {
      const c = [0];
      for (let i = 1; i < pts.length; i++) c.push(c[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
      return c;
    };
    const pointAt = (pts, cum, f) => {
      const L = cum[cum.length - 1] * Math.min(1, Math.max(0, f));
      let i = 1;
      while (i < cum.length - 1 && cum[i] < L) i++;
      const seg = cum[i] - cum[i - 1] || 1;
      const u = (L - cum[i - 1]) / seg;
      return [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * u, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * u];
    };
    const arcPts = (cx, cy, r, a0, a1, n) => {
      const o = [];
      for (let i = 0; i <= n; i++) {
        const a = a0 + ((a1 - a0) * i) / n;
        o.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
      }
      return o;
    };
    // sample any SVG path element into a polyline (its d must be set before this is called)
    const sample = (pathEl, n) => {
      const total = pathEl.getTotalLength();
      const o = [];
      for (let i = 0; i <= n; i++) {
        const p = pathEl.getPointAtLength((total * i) / n);
        o.push([p.x, p.y]);
      }
      return o;
    };
    // a wavy right-to-left writing line through a word: x from xr to xl around yc
    const writeLine = (xr, xl, yc, amp, waves, n) => {
      const o = [];
      for (let i = 0; i <= n; i++) {
        const u = i / n;
        o.push([xr + (xl - xr) * u, yc + Math.sin(u * Math.PI * waves) * amp]);
      }
      return o;
    };
    Object.assign(K, { prand, make, dOf, lengths, pointAt, arcPts, sample, writeLine });

    // ---------- the hand ----------
    const hand = cfg.hand, handRot = cfg.handRot;
    let rot = cfg.rot == null ? -4 : cfg.rot;
    let wob = 0;
    K.at = null;
    K.t = 0;
    K.place = (p) => {
      gsap.set(hand, { x: p[0], y: p[1] });
      gsap.set(handRot, { rotation: rot, scale: 1 });
      K.at = p;
    };
    const setRot = (t, to, d, ease) => {
      tl.fromTo(handRot, { rotation: rot }, { rotation: to, duration: d, ease: ease || "sine.inOut", immediateRender: false }, t);
      rot = to;
    };
    K.setRot = setRot;
    // the tip follows a polyline; returns the end time
    K.path = (pts, t, d, ease) => {
      tl.to(hand, { motionPath: { path: dOf(pts) }, duration: d, ease, immediateRender: false }, t);
      wob++;
      setRot(t, -4 + (wob % 2 ? 3.5 : -3.5), d);
      K.at = pts[pts.length - 1];
      K.t = t + d;
      return t + d;
    };
    // lift and travel to a point; duration follows distance when d is null
    K.travel = (to, t, d) => {
      if (d == null) d = Math.min(cfg.travelMax || 0.25, Math.max(0.03, Math.hypot(to[0] - K.at[0], to[1] - K.at[1]) / (cfg.travelRate || 2600)));
      tl.fromTo(hand, { x: K.at[0], y: K.at[1] }, { x: to[0], y: to[1], duration: d, ease: "power2.inOut", immediateRender: false }, t);
      tl.fromTo(handRot, { scale: 1 }, { scale: 1.045, duration: d / 2, ease: "sine.out", immediateRender: false }, t);
      tl.fromTo(handRot, { scale: 1.045 }, { scale: 1, duration: d / 2, ease: "sine.in", immediateRender: false }, t + d / 2);
      K.at = to;
      K.t = t + d;
      return t + d;
    };
    // carry the hand rigidly with something that moves (e.g. pushing the nozzle)
    K.carry = (from, to, t, d, ease) => {
      tl.fromTo(hand, { x: from[0], y: from[1] }, { x: to[0], y: to[1], duration: d, ease, immediateRender: false }, t);
      K.at = to;
      K.t = t + d;
      return t + d;
    };

    // ---------- charcoal dust ----------
    let dustN = cfg.dustSeed || 0;
    K.puff = (p, t, spread, count) => {
      for (let i = 0; i < count; i++) {
        const n = ++dustN;
        const a = prand(n) * Math.PI * 2;
        const dist = (0.35 + prand(n + 0.5) * 0.65) * spread;
        const c = make("circle", { cx: p[0].toFixed(1), cy: p[1].toFixed(1), r: (2 + prand(n + 0.25) * 5).toFixed(1), opacity: 0 }, cfg.dust);
        tl.fromTo(
          c,
          { x: 0, y: 0, opacity: 0.75 },
          { x: Math.cos(a) * dist, y: Math.sin(a) * dist * 0.6 + dist * 0.5, opacity: 0, duration: 0.45 + prand(n + 0.75) * 0.5, ease: "power2.out", immediateRender: false },
          t,
        );
      }
    };
    K.dustAlong = (pts, t, d, ease, every) => {
      const cum = lengths(pts);
      const E = gsap.parseEase(ease);
      for (let s = 0.04; s < d; s += every) K.puff(pointAt(pts, cum, E(s / d)), t + s, 26, 2);
    };

    // ---------- stroke reveals ----------
    K.reveal = (path, t, d, ease, from, to) =>
      tl.fromTo(path, { attr: { "stroke-dashoffset": from == null ? 1.02 : from } }, { attr: { "stroke-dashoffset": to == null ? 0 : to }, duration: d, ease, immediateRender: false }, t);
    // reveal a dash-drawn path while the tip draws it (pts in world space); travels there first if needed
    K.stroke = (pathEl, pts, t, d, ease, travelD) => {
      if (Math.hypot(pts[0][0] - K.at[0], pts[0][1] - K.at[1]) > 4) t = K.travel(pts[0], t, travelD == null ? null : travelD);
      K.reveal(pathEl, t, d, ease);
      K.dustAlong(pts, t, d, ease, 0.08);
      return K.path(pts, t, d, ease);
    };

    // ---------- drawings: lines layer + tone layer revealed by charcoal strokes ----------
    // svg: the drawing's own <svg> (viewBox = image px); toWorld maps image px -> world px
    K.drawing = (svg, plan, layers, toWorld, contourWidth) => {
      const W = plan.W, H = plan.H, id = layers.id || svg.id;
      plan.contours.forEach((c, i) => {
        if (c.length > 7 && c[6][0] > c[0][0]) plan.contours[i] = [c[0]].concat(c.slice(1).reverse()); // head left from the top
      });
      const maskOf = (suffix) => make("mask", { id: id + suffix, maskUnits: "userSpaceOnUse", x: -300, y: -300, width: W + 600, height: H + 600 }, svg);
      const strokeAttrs = (w) => ({ fill: "none", stroke: "#fff", "stroke-width": w, "stroke-linecap": "round", "stroke-linejoin": "round", pathLength: 1, "stroke-dasharray": "1 1.05", "stroke-dashoffset": 1.02 });
      const out = { contour: [], sweepsL: [], sweepsT: [], plan, toWorld, layers: {}, svg };
      const mL = layers.lines ? maskOf("-mL") : null;
      const mT = maskOf("-mT");
      const gL = mL ? make("g", { filter: cfg.mrough }, mL) : null;
      const gT = make("g", { filter: cfg.mrough }, mT);
      if (gL) plan.contours.forEach((c) => out.contour.push(make("path", Object.assign({ d: dOf(c) }, strokeAttrs(contourWidth)), gL)));
      plan.sweeps.forEach((s) => {
        if (gL) out.sweepsL.push(make("path", Object.assign({ d: dOf(s) }, strokeAttrs(plan.strokeWidth)), gL));
        out.sweepsT.push(make("path", Object.assign({ d: dOf(s) }, strokeAttrs(plan.strokeWidth)), gT));
      });
      let holder = svg;
      if (layers.wrap || layers.clip) holder = make("g", { id: id + "-art" }, svg);
      if (layers.clip) {
        const cp = make("clipPath", { id: id + "-clip" }, svg);
        make("rect", { x: layers.clip[0], y: layers.clip[1], width: layers.clip[2], height: layers.clip[3] }, cp);
        holder.setAttribute("clip-path", "url(#" + id + "-clip)");
      }
      if (layers.lines) out.layers.lines = make("image", { href: layers.lines, width: W, height: H, mask: "url(#" + id + "-mL)" }, holder);
      out.layers.tone = make("image", { href: layers.tone, width: W, height: H, mask: "url(#" + id + "-mT)" }, holder);
      out.holder = holder;
      return out;
    };
    // outline(s) first, then back-and-forth hatching; the tone layer trails the hatching by `lag`
    K.draw = (D, t, o) => {
      const toW = (pts) => pts.map(D.toWorld);
      if (o.contour && D.contour.length) {
        D.plan.contours.forEach((c, ci) => {
          const cw = toW(c);
          const cd = typeof o.contour === "function" ? o.contour(ci) : o.contour;
          if (K.at && Math.hypot(K.at[0] - cw[0][0], K.at[1] - cw[0][1]) > 4) t = K.travel(cw[0], t, ci === 0 ? o.travelIn || 0.2 : null);
          const ce = o.contourEase || "power1.inOut";
          K.reveal(D.contour[ci], t, cd, ce);
          K.dustAlong(cw, t, cd, ce, 0.07);
          t = K.path(cw, t, cd, ce);
        });
      }
      D.plan.sweeps.forEach((s, i) => {
        const sw = toW(s);
        const d = typeof o.sweep === "function" ? o.sweep(i) : o.sweep;
        if (Math.hypot(sw[0][0] - K.at[0], sw[0][1] - K.at[1]) > 4) t = K.travel(sw[0], t, i === 0 && !o.contour ? o.travelIn || 0.2 : null);
        if (D.sweepsL[i]) K.reveal(D.sweepsL[i], t, d, "sine.inOut");
        K.reveal(D.sweepsT[i], t + (D.sweepsL[i] ? o.lag : 0), d, "sine.inOut");
        K.dustAlong(sw, t, d, "sine.inOut", 0.09);
        t = K.path(sw, t, d, "sine.inOut");
      });
      return t;
    };

    // ---------- camera: pan (world units) inside zoom (about the frame centre) ----------
    K.camera = (panEl, zoomEl) => {
      let cam = null;
      return (c, s, t, d, ease) => {
        const pan = { x: 540 - c[0], y: 960 - c[1] };
        if (!cam) {
          gsap.set(panEl, pan);
          gsap.set(zoomEl, { scale: s });
        } else {
          tl.fromTo(panEl, { x: 540 - cam.c[0], y: 960 - cam.c[1] }, Object.assign({ duration: d, ease, immediateRender: false }, pan), t);
          tl.fromTo(zoomEl, { scale: cam.s }, { scale: s, duration: d, ease, immediateRender: false }, t);
        }
        cam = { c, s };
      };
    };

    // ---------- a hand-drawn dial (fuel / performance) ----------
    // returns elements plus world points for the arc; labels: [left, right] short strings or null
    K.gauge = (parent, cx, cy, r, labels) => {
      const g = make("g", { transform: `translate(${cx} ${cy})`, filter: cfg.rough, fill: "none", stroke: "#17130f", "stroke-linecap": "round" }, parent);
      const dash = { pathLength: 1, "stroke-dasharray": "1 1.05", "stroke-dashoffset": 1.02 };
      const arc = make("path", Object.assign({ d: `M${-r} 0 A${r} ${r} 0 0 1 ${r} 0`, "stroke-width": 13 }, dash), g);
      const ticks = [180, 225, 270, 315, 360].map((deg) => {
        const a = (deg * Math.PI) / 180, c = Math.cos(a), s = Math.sin(a);
        return make("path", Object.assign({ d: `M${(r * c).toFixed(1)} ${(r * s).toFixed(1)} L${(r * 0.8 * c).toFixed(1)} ${(r * 0.8 * s).toFixed(1)}`, "stroke-width": 9 }, dash), g);
      });
      const lab = (labels || []).map((txt, i) => {
        const x = (i ? 1 : -1) * r * 0.66;
        if (txt === "E") return make("path", Object.assign({ d: `M${x - 13} -18 L${x - 13} -62 L${x + 13} -62 M${x - 13} -40 L${x + 7} -40 M${x - 13} -18 L${x + 13} -18`, "stroke-width": 8, "stroke-linejoin": "round" }, dash), g);
        if (txt === "F") return make("path", Object.assign({ d: `M${x - 13} -18 L${x - 13} -62 L${x + 13} -62 M${x - 13} -40 L${x + 7} -40`, "stroke-width": 8, "stroke-linejoin": "round" }, dash), g);
        if (txt === "-") return make("path", Object.assign({ d: `M${x - 14} -40 L${x + 14} -40`, "stroke-width": 9 }, dash), g);
        if (txt === "+") return make("path", Object.assign({ d: `M${x - 14} -40 L${x + 14} -40 M${x} -54 L${x} -26`, "stroke-width": 9 }, dash), g);
        return null;
      });
      const needle = make("g", {}, g);
      const needleLine = make("path", Object.assign({ d: `M0 0 L0 ${-r * 0.8}`, "stroke-width": 11 }, dash), needle);
      const hub = make("circle", { r: 15, fill: "#17130f", stroke: "none", opacity: 0 }, g);
      return { g, arc, ticks, labels: lab.filter(Boolean), needle, needleLine, hub, arcWorld: arcPts(cx, cy, r, Math.PI, Math.PI * 2, 24) };
    };
    // draw a gauge with the hand; the needle draws itself at `deg`
    K.drawGauge = (G, t, deg) => {
      t = K.stroke(G.arc, G.arcWorld, t, 0.3, "sine.inOut");
      G.ticks.forEach((k, i) => K.reveal(k, t - 0.22 + i * 0.05, 0.08, "power1.out"));
      G.labels.forEach((l, i) => K.reveal(l, t - 0.05 + i * 0.05, 0.12, "power1.out"));
      gsap.set(G.needle, { rotation: deg, transformOrigin: "50% 100%" });
      tl.fromTo(G.hub, { opacity: 0 }, { opacity: 1, duration: 0.05, immediateRender: false }, t + 0.02);
      K.reveal(G.needleLine, t + 0.02, 0.1, "power1.out");
      return t;
    };
    K.tremble = (el, deg, amp, t0, t1) => {
      tl.fromTo(el, { rotation: deg }, { rotation: deg + amp, duration: 0.07, ease: "sine.inOut", yoyo: true, repeat: Math.max(0, Math.floor((t1 - t0) / 0.07) - 1), immediateRender: false }, t0);
    };

    return K;
  };
})();
