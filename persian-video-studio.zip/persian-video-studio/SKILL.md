---
name: persian-video-studio
description: >
  Complete Persian (Farsi) video studio by romeo.designs6 — make or edit Instagram Reels, YouTube Shorts and ads in
  Persian with HyperFrames, ElevenLabs and local AI tools: typed Persian captions that stay centred and never jump,
  Abar-font typography, RTL text, word-exact caption sync (local Whisper), cutting a person out of footage (curly hair
  included), talking-head editing with B-roll, motion graphics, cute sound design, music, mixing to −14 LUFS, and
  30 fps delivery, plus real 3D reels (medical/product/mechanism) in Three.js. Includes Nate Herk's MIT editing kit (cut silences/mistakes, short-form edit).
  Use this skill whenever the user speaks Persian about video work — «ریلز»، «ویدیو»، «ادیت»، «زیرنویس»، «موشن
  گرافیک»، «تیزر»، «استوری‌بورد»، «ویس»، «افکت صوتی»، «بک‌گراند رو جدا کن»، «کپشن فارسی»، «سه‌بعدی» — or asks for any Farsi
  subtitles, Persian text on video, a reel/short/teaser/ad, editing their own recorded footage, or HyperFrames work
  with Persian content, even if they do not name this skill.
---

# Persian Video Studio · by romeo.designs6

Everything learned while making real Persian reels with this creator — product teasers, explainer reels, a
charcoal-drawn reel and an edit of their own talking-head footage — turned into one workflow. Each rule below
exists because something went wrong once and the user had to point it out. Follow them and the user never has to
explain these things again.

The skill root is the folder this file sits in (call it `SKILL_DIR`). Scripts run with `node SKILL_DIR/scripts/…`.
Machine paths (FFmpeg, models, Whisper) are resolved by `scripts/lib/config.cjs`; first run
`node SKILL_DIR/scripts/doctor.cjs` to see what is installed, and read `references/setup.md` for anything missing.

## 1. Working with this creator

- **Talk in Persian**, keep code, commands and file names in English. Explain technical things simply.
- **Do the work yourself.** The user wants results, not homework. Only ask when a decision is genuinely theirs:
  spending money, downloading something (say what, from where, how big), accepting terms, or a click only they can
  do (e.g. picking a file in an upload widget). When you must ask, offer 2–3 concrete options with a recommendation.
- **Be economical.** Price paid generations first (`estimate_only`), generate one variation at a time, reuse
  assets across projects, and report what was spent. Prefer free local tools and code-drawn graphics.
- **Show prices as a small table and start with the cheapest tier that works.** This user turned down Seedance 2.5
  at 1080p (≈ 25k credits per 4 s) and approved 720p (≈ 11k). Never run a premium tier without an explicit yes.
- **Recreating someone else's reel for a new brand:** copy the structure, pacing and techniques, never their
  patient photos, logo or brand. Put a `BRAND` slot (name + logo path) in from the start, so the user can send
  the brand later.
- **Transitions must feel organic.** Generic hologram rings and crossfades read as cheap («یهویی»). Use a real
  morph (AI clip with start/end frames) or a motivated match cut. Never leave hard edges (e.g. a neck cut off
  under a skull).
- **Plan before spending effort.** Animated pieces: storyboard + every image first, animate only after approval.
  Footage edits: build a 10–15 s sample in the final style first. Give a time estimate for long jobs and a short
  progress note every few minutes.
- **Never add words the user didn't write** — no invented taglines, claims or numbers. Product claims must match the
  label (2.6 g sugar ⇒ «شکر افزوده نداره», not «شکرش صفره»). If you correct a transcript word by context, say so.
- **Verify before showing.** Snapshot every beat, measure centring, loudness and sync with the scripts here, look at
  full-size crops. The user checks every frame; they circle mistakes.
- **Audio scope follows the brief**: sometimes the user brings voice/music, sometimes Claude makes them. If the
  brief says nothing about audio, ask once.
- Studio preview: give every project an `Open-Studio.cmd` (template in `assets/templates/`); the user opens it from
  CMD in their own browser (the in-app pane lagged and played no audio).

## 2. Persian text — the rules that matter most

Read `references/persian-text.md` before placing any Persian text.

1. **Font: Abar** (AbarHigh Black/ExtraBold/Bold for display and captions, AbarHighFaNum for digits). It is the
   user's own licence — never bundled; copy it into `assets/fonts/` of each project and declare `@font-face`.
2. **Text must sit exactly in the middle of its box.** Abar's ink sits high (ascent 1.10em / descent 0.70em), so
   flex/`text-align` centring alone leaves letters visibly above centre. Start with about 0.11em more padding on top
   than on the bottom, then **measure every boxed label and caption** on a snapshot:
   `node scripts/project/measure_text_center.cjs frame.png x0 y0 x1 y1` (rectangle inside the box). Fix until the
   top and bottom ink gaps match within 3 px. Horizontally the box should hug the text with equal side padding.
3. **One line per caption page, never re-wrapping while typing.** Pages of ≤ ~23 characters / 4 words, split at
   sentence ends, commas and real pauses. A pill that grows from the centre around the typed text, a zero-width
   caret, no `text-wrap: balance`. See `references/captions.md`.
4. **RTL/bidi pitfalls**: absolutely positioned elements inside `direction: rtl` need an explicit `left`/`right`
   (their static position is the right edge); numbers next to Persian can reorder («۱۰۰٪ فِر» came out reversed) —
   rephrase or isolate them; no emoji or ASCII art (¯\_(ツ)_/¯ broke the line); use Persian digits `۰–۹` and
   `٬` thousands separators; keep ZWNJ (نیم‌فاصله) in words like «می‌بینی».
5. **Clearance**: lettering only in open space, ≥ 80 px from artwork and never over the face; phone-safe area for
   9:16 is roughly x 90–930, y 200–1600 (the bottom and right edge carry Instagram UI).
6. **AI images cannot write Persian.** Never ask an image model for Persian lettering or a Persian logo: request an
   empty area and composite the real text/logo (`scripts/images/logo-into-pack.cjs`).

## 3. Choose the pipeline

| The user brings | Pipeline | Read |
| --- | --- | --- |
| a script (+ usually their own voice-over) for an animated reel/teaser/explainer | **A. Animated reel** | `references/animated-reels.md` |
| their own filmed footage (talking head, vlog, ad) to edit | **B. Footage edit** | `references/footage-editing.md` |
| only an idea / brief | help write a short script first, then A | `references/animated-reels.md` |
| a 3D reference («سه‌بعدی»): medical/product/mechanism, often recreating someone else's reel for a new brand | **C. 3D with Three.js** — real 3D, free, exact; price AI video only for single organic shots | `references/3d-threejs.md` + `assets/examples/skull-distraction/` |

All pipelines share: `references/captions.md`, `references/audio.md`, `references/hyperframes-notes.md`,
`references/elevenlabs.md`. The whole story of how these rules were learned is in `references/project-history.md`.

### A. Animated reel (summary)
1. Brief: format (9:16 default), length, **30 fps**, style reference, who makes the audio, CTA.
2. Time everything to the voice-over (the user's own recording is preferred; edit out retakes with Whisper times).
3. Storyboard: one frame per scene with real generated images, timed to VO lines → `storyboard.html`
   (`scripts/project/inline-storyboard.cjs` makes it self-contained). Wait for approval.
4. Images: one style bible + real product photos as references; cut-outs with `scripts/images/cutout.cjs`.
   Motion shots only where they matter (Veo 3.1 Lite ≈ 0.13 USD per 4 s).
5. Build HyperFrames compositions (one per scene), captions, SFX cues, music; mix stems; check; render; master.

### B. Footage edit (summary)
1. Probe the file (rotation, fps, audio streams); the user may also send a cleaned audio mixdown — check its offset
   by cross-correlation and use it.
2. Words: local Whisper → `scripts/timing/whisper_words.py`, align onto the proof-read text →
   `scripts/timing/align_whisper.cjs`. **Never estimate word times from the waveform** (it drifted 6 s once).
3. Ask how natural it should stay. If cuts are wanted, use the kit: `kit/.claude/skills/cut-silences/GUIDE.md` then
   `cut-mistakes/GUIDE.md` (convert words with `scripts/timing/to_kit_transcript.cjs`). If the user says «کات نزن»,
   keep every stumble and only trim leading silence.
4. Story: hook in the first 3 s, then make every claim **happen on screen when it is said**; where the speaker
   points («اینجا») look at the frames and put the graphic exactly there; B-roll scenes where they help
   (the speaker may be absent from frame). Method: `kit/.claude/skills/short-form-edit/GUIDE.md`,
   `kit/.claude/skills/video-storytelling/GUIDE.md`, `kit/MOTION_PHILOSOPHY.md`.
5. Background removal only where it is a feature (a showcase moment), with RVM + refine — never u2net on hair.
6. Sample first, then the full piece; re-time everything from one word map (`scripts/timing/retime-example.cjs`).

## 4. Sound

- **Check every SFX for shrill highs before the user hears it:** compare `highpass=5000` mean volume with the full
  mean. A "scanner" with most of its energy above 5 kHz was called «جیغ». Regenerate as "warm, low, no high
  frequencies" and keep `treble=g=-4:f=7000` on the SFX stem.
- Captions **always** type with an audible, cute typing sound (`build_captions.cjs --typing`, clicks in
  `assets/sfx/clicks`). SFX: many, small, soft, never harsh — starter kit in `assets/sfx/kit`, more from ElevenLabs
  sound effects (≈ 0.001 USD each). Place cues on the visual event, from the word map.
- Music: ElevenLabs music v2, instrumental, full length (check it doesn't end early or start silent), ducked under
  the voice. Mix into three stems with `scripts/audio/mix_stems.cjs`; master the render with
  `scripts/audio/master.cjs` (the renderer's own mix is ≈ −25 LUFS; target −14 LUFS, peak ≤ −1 dBFS).
- TTS in Persian is fragile — see `references/audio.md` before generating any voice.

## 5. Deliver

- Render at 30 fps, 1080×1920, quality `delivery`; master the audio; make an Instagram copy
  (`-crf 19 -maxrate 18M`). Verify: frame count/duration, A/V offset (cross-correlate with the source, expect
  ≈ 3 ms), loudness, and a strip of frames from every scene. Send the file and a short Persian summary: what is in
  it, what was checked, what it cost, what to look at.

## 6. Tools in this skill

| Script | Does |
| --- | --- |
| `scripts/doctor.cjs` | shows what is installed and what is missing |
| `scripts/project/measure_text_center.cjs` | measures whether text ink is centred in its box |
| `scripts/project/inline-storyboard.cjs` | makes a self-contained storyboard.html |
| `scripts/captions/build_captions.cjs` + `assets/templates/captions.html` | typed sticker captions + typing clicks |
| `scripts/timing/whisper_words.py` · `align_whisper.cjs` · `to_kit_transcript.cjs` | exact Persian word timing |
| `scripts/timing/retime-example.cjs` | pattern: move every graphic/SFX to corrected word times |
| `scripts/audio/mix_stems.cjs` · `master.cjs` | three stems with ducking/swell · −14 LUFS master |
| `scripts/matting/rvm.mjs` · `refine.mjs` · `headtrack.cjs` · `diffkey.cjs` | person cut-out, hair clean-up, head track, locked-camera key |
| `scripts/images/cutout.cjs` · `logo-into-pack.cjs` · `codex-gen.ps1` | illustration cut-outs, real logo compositing, ChatGPT images via Codex |
| `scripts/video/prep-morph.cjs` | conform an AI clip (Seedance/Veo) to 1080×1920@30 + measure its joins to the frames around it |
| `scripts/images/scan-mesh.cjs` | "3D face scan" wireframe SVG that follows the subject's silhouette on a black-studio photo |
| `assets/examples/skull-distraction/` | full 3D surgery reel: Three.js scene (skull warp, camera fit to photo, device, GTAO, grade), composition, SFX cues |
| `scripts/ink/*` + `assets/js/charcoal-kit.js` | charcoal "hand draws it" style: ink-alpha, stroke plans, paper |
| `kit/` | Nate Herk's HyperFrames editing kit (MIT): cut-silences, cut-mistakes, short-form-edit, edit-video, video-storytelling, motion-showreel, style-library (406 cards) … |

Credits: this skill is by **romeo.designs6**. The `kit/` folder is Nate Herk's hyperframes-student-kit, used under
its MIT licence and use permission (kept in `kit/LICENSE`, `kit/licenses/`); HyperFrames is by HeyGen (Apache-2.0).
