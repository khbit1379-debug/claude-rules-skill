# Typed Persian captions

The creator's signature caption: a sticker pill (paper fill, 6 px ink border, hard offset shadow, Abar Black
~70 px) whose words **type in letter by letter with an audible, cute typing click**, keywords marked with a lime
marker stripe or red for negatives. Template: `assets/templates/captions.html`; data from
`scripts/captions/build_captions.cjs`.

## Why they are built this way (things the user rejected)

1. **Jumping captions** («زیرنویس پرش داره هی میپره»). Causes: `text-wrap: balance` re-wrapping as text grows, an
   inline caret changing the line width, vertical centring moving lines between pages.
   → pages are ONE line, the caret is zero-width (the bar is an absolute `::after`), the line has a fixed y.
2. **Text not centred in its box** («متن وسط کادر نیست»). A full-width pill with right-aligned typed text leaves the
   left side empty while typing, and Abar sits high.
   → the pill hugs the typed text and grows from the centre; asymmetric padding; measured with
   `measure_text_center.cjs` (see persian-text.md).
3. **Out of sync** («زیرنویس با حرف‌های من سینک نیست»). Envelope-estimated word times drifted up to 6 s.
   → word times only from Whisper + alignment (below).

## Build

```bash
# 1. word times (see footage-editing.md for the full chain)
<whisper-python> SKILL_DIR/scripts/timing/whisper_words.py voice.wav work/whisper.json work/transcript.txt
node SKILL_DIR/scripts/timing/align_whisper.cjs work/transcript.txt work/whisper.json voice.wav work/words.json
# 2. pages + typing sound, injected into the caption composition
cp SKILL_DIR/assets/templates/captions.html compositions/captions.html
node SKILL_DIR/scripts/captions/build_captions.cjs --words work/words.json --comp compositions/captions.html \
     --end 117.8 --offset 0.767 --hl work/hl.json --cta "اِ" --typing assets/audio/typing.wav
```

- `transcript.txt` is the proof-read text exactly as it should read on screen. ASR mistakes are fixed here by
  meaning (e.g. Scribe's «مایه خدا تو هم» was really «ماهی خدا تومن»); tell the user about every such correction.
- `--offset` = seconds trimmed off the head of the audio (comp time = audio time − offset).
- `hl.json`: `{"lime": [...keywords], "red": [...negatives like «نه»، «اخراج»، «نمیدم.»]}` — highlight words the
  speaker stresses, not every noun.
- `--cta` lifts the caption line for the closing call-to-action so the keyword card can own the bottom.
- `--bumps 49.05,49.63`: the pill hops at those times — used when the speaker points at the caption
  («زیرنویس می‌ذاره اینجا»).
- Pages never cross a pause > 0.3 s; single short words are folded into a neighbour.
- Include `<div … data-track-kind="captions">` for the host so Studio shows it as the caption track.

## Style knobs

- Line position `#cap-line { top: 1268px }` (over the chest). Move per page with the `topFor` rule when a gesture
  or graphic needs the spot.
- Page pop-in 0.14 s with a tiny overshoot, drop-out 0.08 s, alternating ±1.6° rotation.
- Typing speed: letters over 75 % of the spoken word, never slower than 60 ms per letter; one click per two
  letters, mixed at about 0.24 gain in the SFX stem.
- For long-form or calmer pieces, a plain white stroke caption can replace the pill — keep the no-jump rules.
