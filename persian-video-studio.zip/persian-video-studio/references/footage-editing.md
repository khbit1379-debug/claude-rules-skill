# Editing the creator's own footage

Built from the «ادیتورت رو اخراج کن» reel (a 2-minute handheld vertical selfie monologue) plus Nate Herk's kit in
`kit/`. The kit's method — hook in the first three seconds, open loops, every shot with a reason, event-based sound,
footage ledgers, verification gates — lives in `kit/.claude/skills/short-form-edit/GUIDE.md`,
`kit/.claude/skills/video-storytelling/GUIDE.md`, `kit/.claude/skills/edit-video/GUIDE.md` and
`kit/MOTION_PHILOSOPHY.md`. Read those for story and pacing; this file adds what Persian footage needs.

## 1. Intake

- Probe: `ffprobe` duration, rotation side data (iPhone footage is 1920×1080 with rotation −90 → 1080×1920),
  fps, audio streams (iPhones add an extra spatial `apac` track — use stream 0:a:0).
- The user may send a cleaned audio mixdown from their DAW. Cross-correlate it with the camera audio to confirm
  the offset (it was exactly 0 ms) and use it as the voice.
- Leading silence: find the first word (10 ms envelope) and start ~60 ms before it, on a frame boundary.
- Tell the user the story back in a few lines before editing — they use this to check you understood.

## 2. Exact word timing (Persian)

ElevenLabs Scribe is excellent at Persian text but, through the connector, returns **text only**. The kit's
`scripts/transcribe-elevenlabs.mjs` needs an API key. So:
1. Get good text: Scribe via the connector (the user picks the file in the upload widget), or Whisper's own text.
   Proof-read it into `transcript.txt` (fix ASR errors by context; keep the speaker's colloquial words).
2. Times: `whisper_words.py` (faster-whisper large-v3-turbo, local, ~1 min per 2 min of speech on CPU) →
   `align_whisper.cjs` maps Whisper's loosely spelled words onto `transcript.txt` (sound-alike letter folding,
   alignment with merges, onset snapping).
3. Sanity-check a few anchors against the audio: long pauses, sibilant clusters («چس‌مثقال»، «سنگینه»), and
   where the speaker points on camera.
4. For the kit's cut tools: `to_kit_transcript.cjs words.json transcript.json`.

Never distribute words over the waveform by syllable guesses — that drifted 6 s in the middle of a 2-minute take
and put every graphic late.

## 3. Cuts

- Ask how natural it should stay. This creator once said: no cuts, stumbles and repeats are fine («طبیعی‌تره») —
  then only the leading silence goes.
- Otherwise: `kit/.claude/skills/cut-silences/GUIDE.md` (keeps a natural breath) → `kit/.claude/skills/cut-mistakes/GUIDE.md`
  (review every proposed cut with its context; intentional repetition stays) → render once, re-time words from the
  EDL, and build everything on the cut timeline.

## 4. Story on screen

- Make every claim happen visually at the moment it is spoken: «کارت پرسنلی ادیتور» slides in, the salary counter
  spins to «خدا تومن!», the «اخراج!» stamp slams on «اخراج», the card gets kicked out on «بره».
- **Pointing («اینجا»)**: pull a contact sheet around every «اینجا» (5 fps, grid overlay) and put the target, label
  or caption exactly where the finger points; if the hand passes in front, place the marker *behind* the speaker
  (needs the matte) so the hand occludes it. Re-check these after any re-timing — a word can move to a different
  gesture.
- B-roll (the speaker may be completely out of frame): full-screen code-drawn scenes in the same sticker style —
  firing line of ID cards, piggy bank + «صرفه‌جویی» stamp, magnifier over a tiny coin feeding an AI chip, stopwatch
  «۱۵ تا ۲۰ دقیقه», an editor-timeline whose tracks fill as each job is named, a month calendar ticking every day,
  income line with coins, bar chart «رشد!». Slide in/out 0.2 s with a whoosh; keep them 1.5–5 s, one idea each.
- «همین ویدیویی که داری می‌بینی»: shrink the whole frame into a phone on a table.
- Camera: settle-in on the first frame, punch-ins on emphasis words, a comic zoom on a repeated line, a shake on
  impacts, a slow push under the CTA.
- CTA: the keyword (e.g. «ادیتور») types itself big where the speaker points, with «این کلمه رو بفرست».

## 5. Cutting the speaker out (background removal)

Only where it is the point (e.g. "no editor could cut me out" → the room peels off and drops away). The user said
the whole video does not need it.
- `hyperframes remove-background` (u2net_human_seg) fails on curly hair — blobs with wall chunks.
- Use **RVM ResNet50** (`scripts/matting/rvm.mjs`, GPU via DirectML, ~40 ms/frame at 1080×1920):
  `--ratio 0.25` for a head-and-shoulders close-up (0.4 was worse), `--skip 23` warms the recurrent state on
  pre-roll frames, `--clean` drops colourless near-white edge pixels. Output `.mp4` = stacked fg/alpha (small),
  `.mkv` = lossless RGBA (short clips).
- Then **always** `scripts/matting/refine.mjs matte.mp4 original.mov start n out.webm` (VP9 alpha): colour
  unmixing against the real background removes wall showing through curls and next to the ear; colour-extend
  cleans edge tint. Set `HAIR_RGB` if the subject's hair isn't dark brown-black.
- Never put a white stroke "sticker outline" around a hair cut-out and never a white glow behind the head — both
  read as a bad key. A soft dark contact shadow is enough.
- Check at full size on a saturated colour (lime) — hair edges, ears, fast hands — before showing the user.
- Locked-off camera on a plain background (animated scenes): `scripts/matting/diffkey.cjs` (clean-plate
  difference key max'd with an AI matte keeps motion-blurred limbs).
- `scripts/matting/headtrack.cjs` gives the head position per frame from the matte, for graphics that must follow
  the head.

## 6. After the sample

Once the sample is approved, build the full piece with the same style. If word times change later, do not move
numbers by hand: map old→new word times and shift every timeline child, host window, SFX cue and music swell
(`scripts/timing/retime-example.cjs` shows the pattern). Scenes not tied to words scale uniformly.
