# Setup

Run `node SKILL_DIR/scripts/doctor.cjs` — it lists what is present and what is missing. Install only what the
current job needs, and **ask the user before any download** (say what, from where, how big).

| Need | Install | Size |
| --- | --- | --- |
| Always | **Node.js 22+** (nodejs.org) and **FFmpeg** with ffprobe (Windows: `winget install Gyan.FFmpeg.Essentials`; macOS: `brew install ffmpeg`) | ~100 MB |
| Always | **HyperFrames CLI** runs through `npx --yes hyperframes@<version>`; official skills: `npx hyperframes skills update` | npm cache |
| Persian text | the user's **Abar** font files (their licence) → each project's `assets/fonts/` | — |
| Exact caption sync | **faster-whisper** in a venv + model **large-v3-turbo** (HuggingFace, auto-download on first run) | ~280 MB + 1.6 GB |
| Cutting a person out | **onnxruntime-node** (`npm i onnxruntime-node@1.21.1` in `~/.persian-video-studio`) + **RVM** `rvm_resnet50_fp32.onnx` (GitHub PeterL1n/RobustVideoMatting, release v1.0.0) | ~60 MB + 102.5 MB |
| AI images / music / SFX / TTS / Scribe | the **ElevenLabs** connector in Claude (user's account and credits) | — |
| Optional images via ChatGPT | Codex CLI `npm i -g @openai/codex`, the user runs `codex login` themselves | — |
| Editing kit extras | `kit/` is bundled; for its example projects clone github.com/nateherkai/hyperframes-student-kit | ~10 MB sparse |

## Commands

```bash
# Whisper (one time)
python -m venv ~/.persian-video-studio/whisper-venv
~/.persian-video-studio/whisper-venv/Scripts/python -m pip install faster-whisper     # bin/python on macOS/Linux
# the model downloads on first use into ~/.persian-video-studio/models/whisper (1.6 GB)

# RVM (one time)
mkdir -p ~/.persian-video-studio/models && cd ~/.persian-video-studio && npm i onnxruntime-node@1.21.1
curl -L -o models/rvm_resnet50_fp32.onnx \
  https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_resnet50_fp32.onnx

# The kit's workflows are inside this skill as kit/.claude/skills/<name>/GUIDE.md (renamed from SKILL.md so the
# package holds a single skill). Read the guide you need; run its scripts from kit/ as the working directory.
```

- On Windows, Whisper on the GPU needs CUDA 12 cuBLAS/cuDNN DLLs; without them it runs on CPU int8 automatically
  (≈ 1 min per 2 min of speech). RVM uses DirectML on Windows (any modern GPU) and CPU elsewhere.
- Paths can be overridden per machine in `SKILL_DIR/config.local.json` (copy `config.example.json`) or with
  `FFMPEG`, `FFPROBE`, `PVS_MODELS`, `PVS_NODE_MODULES`, `PVS_WHISPER_PY`.
- Kit scripts: run `npm ci` inside `kit/` once if you use its validators; its own transcription script needs an
  ElevenLabs API key in `kit/.env` — for Persian use this skill's Whisper chain instead.
