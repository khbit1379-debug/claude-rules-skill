# Persian text on video

## Font: Abar

- The creator's brand font is the **Abar** family: `AbarHigh-{Black,ExtraBold,Bold,SemiBold,Regular}.otf`,
  `AbarMid-*`, `AbarLow-*`, plus `*FaNum-*.ttf` cuts with Persian digits. It is their own licence and is not in
  this skill — ask for the files (Windows per-user fonts live in
  `%LOCALAPPDATA%\Microsoft\Windows\Fonts\Abar*`) and copy them into each project's `assets/fonts/`.
- HyperFrames renders only local fonts: declare every face used, inside each composition's `<template>`:
  ```css
  @font-face { font-family: "AbarHigh"; src: url("assets/fonts/AbarHigh-Black.otf") format("opentype"); font-weight: 900; }
  @font-face { font-family: "AbarNum";  src: url("assets/fonts/AbarHighFaNum-Black.ttf") format("truetype"); font-weight: 900; }
  ```
- Roles: AbarHigh Black for captions, stickers, titles and stamps; Bold/ExtraBold for secondary lines; AbarHighFaNum
  for any number (counters, prices, dates). If the user brings a different font, the same rules apply — measure it.

## Centring text inside a box (the rule the user cares about most)

Abar's font box has ascent ≈ 1.10em and descent ≈ 0.70em, so the ink of most words sits **above** the centre of
its line box, and tall marks (dots, «ک» strokes, digits) can poke out of tight containers. CSS centring
(`display:flex; align-items:center`, `text-align:center`, equal padding) therefore looks off-centre on video.
Measured cases:
- «فقط» sits ≈ 0.275em high; FaNum digits ≈ 0.18em high with their top at LH/2 − 0.59em.
- Caption pill at 70 px, line-height 1.25: equal padding left the ink 4 px high — fixed with
  `padding: 18px 40px 10px` (≈ 0.11em more on top) and verified: ink gaps 14 px / 14 px.

Recipe:
1. Box with `display:flex; align-items:center; justify-content:center`, line-height 1.2–1.3.
2. Start with top padding ≈ bottom padding + 0.11em (or `position:relative; top:+0.06em` on the text).
3. Snapshot the frame and measure: `node scripts/project/measure_text_center.cjs frame.png x0 y0 x1 y1`
   where the rectangle lies inside the box border. It reports the ink gaps and "move text DOWN n px".
   For rotated stickers measure a narrow band of columns around the centre, or snapshot once without rotation.
4. Repeat until vertical and horizontal offsets are ≤ 3 px. Do this for every boxed label, badge, stamp, button
   and caption style in the project — not just the first one.
5. Containers with `overflow:hidden` (digit reels, masks): make the cell ≥ 1.1em tall and nudge the text, or the
   top of the digits gets clipped.
6. Highlights (marker stripes) belong inside the letter body: `linear-gradient(transparent 50%, lime 50%, lime 82%,
   transparent 82%)` — never touching the box border.

The checker's `content_overlap` warnings can be false alarms for Abar because its font box is taller than its ink;
confirm visually, then mark the element `data-layout-allow-overlap`.

## Right-to-left and bidi

- Put `direction: rtl` on containers of Persian text. An absolutely positioned child without `left`/`right` takes
  its static position at the **right** edge — give animated overlays an explicit `left: 0` (a playhead once ended up
  off-screen because of this).
- Mixed digits/symbols reorder: «۱۰۰٪ فِر» rendered reversed. Rephrase («فِرِ اصل!»), put the number in its own
  element, or wrap it in `<bdi>`; always look at the rendered frame.
- No emoji and no ASCII art in rendered text (¯\_(ツ)_/¯ broke the whole line); draw icons as inline SVG.
- Persian digits `۰۱۲۳۴۵۶۷۸۹` and the Arabic thousands separator `٬`:
  `n.toLocaleString("en-US").replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]).replace(/,/g, "٬")`.
- Keep ZWNJ (U+200C) in words like «می‌بینی»، «ادیت‌هایی»، «چس‌مثقال»; when splitting text into letters for typing,
  split with `[...str]` so the ZWNJ travels with its word.
- Typing letter by letter is fine: the browser re-shapes the partial word correctly at each step.

## Placement and clearance

- Lettering only in genuinely empty space: ≥ 80 px from any artwork, never over the face, and check the whole time
  the text is visible (later drawings, camera moves, a hand passing).
- 9:16 phone-safe area ≈ x 90–930, y 200–1600; captions around y 1270–1420 over the chest, moved when the
  speaker's hands or a key graphic need that spot.
- Snapshot the text's final state and the last frame of its shot and look for contact before showing the user.

## Persian inside AI images

Image models garble Persian lettering and logos. Ask for blank labels / an empty oval, then composite the real
text in HTML or the real logo with `scripts/images/logo-into-pack.cjs`. Never trace or regenerate a real brand mark.
