# HyperFrames notes from real builds

Load the official skills first (`hyperframes`, `hyperframes-core`, `hyperframes-cli` …). These are the things that
still bit us.

## Project
- `npx hyperframes@latest init <dir> --non-interactive --example=blank` (refuses a non-empty dir: init, then move
  your work in). Pin the version in scripts; keep the same pin for the whole project.
- One sub-composition per scene / overlay group / B-roll scene; captions host gets `data-track-kind="captions"`.
- Layer order is DOM order: backdrop → footage (`<video class="clip" muted playsinline>` in a non-timed wrapper you
  animate) → graphics behind the subject → cut-out subject (alpha WebM) → front graphics → full-screen B-roll hosts
  → captions → `<audio id=…>` stems.
- A "camera": wrap everything that should punch in/shake in one non-timed `#stage` div and animate that.
- Studio edits add `data-hf-id` attributes to your files — patch files with tolerant regexes, and don't overwrite
  tracks the user added in Studio.

## Timelines
- Seek-safe state: drive text/counters/typing from ONE clock tween over the whole composition with `onUpdate`
  computing everything from time (`tl.call` does not fire on seeks).
- GSAP 3 has no `className` tween — use `tl.set(el, { attr: { class: "…" } })`.
- Moving tweens after authoring: `child.startTime(x)` on `tl.getChildren(false, true, true)` works (used to re-time a
  whole reel after word times changed).
- Do not tween `visibility`/`autoAlpha` on `.clip` elements; animate children.

## Checker and lint
- A lint error disables the layout/contrast audits (they report 0 samples) — fix lint first.
- `text_not_painted`: a transparent span counts as unpainted → use `visibility:hidden` for invisible measure copies.
- Decorative ghost text trips WCAG contrast → `aria-hidden="true"` (and `data-layout-ignore`) on purely decorative
  rows.
- Abar false `content_overlap`: verify visually, then `data-layout-allow-overlap`.
- Audio slot longer than the file → set `data-duration` to the media length.
- Snapshots: `npx hyperframes snapshot --at t1,t2,… --no-end --timeout 30000`; tile them with ffmpeg and look.
  A wrong `position` (e.g. a card missing `position:absolute` ended up at the top) is only caught this way.

- Lint **error**: a `fromTo` that makes a hidden element visible must put `opacity: 1` in the *destination* vars
  too, or cold render workers can leave it invisible.
- Repeated `fromTo` on the same element → use `.to()` for the follow-up (e.g. a pulse after a pop-in).
- Re-timing many tweens with text replace: never search for bare `"}, 37.6);"`. A swapped value hid a whole scene
  for 2 s. Replace whole lines or anchor on the selector, then snapshot every scene start.

## Three.js / WebGL
- See `references/3d-threejs.md`. Root needs `data-duration`.
  - Drive everything from `hf-seek`.
  - Register `window.__hf.buildReady`.
  - Seed `Math.random` while constructing GTAO.
  - Skip GPU work outside the section's time window.
- To debug in the browser pane, serve the project over HTTP (`python -m http.server 8765`). A pane tab opened
  from a file is a `data:` URL, and relative assets (GLB, fonts) fail there.
- Clean frame captures (for AI start/end frames): add a temporary
  `<style>#brand,.label{display:none!important}</style>`, snapshot, then remove it.
- Snapshot file names: `frame-NN-at-<t>s.png`. Shell globs over them can fail on Windows ffmpeg; list the names.

## Render
- `npx hyperframes render --fps 30 --quality delivery --output renders/x.mp4` (≈ 1 min per 15 s, 5 min per 2 min
  on a desktop GPU). If the drawElement self-check fails it falls back to screenshot capture automatically.
- Then master the audio (`scripts/audio/master.cjs`) and make the Instagram copy.

## FFmpeg gotchas
- FFmpeg 9 removed `-filter_complex_script`: use `-/filter_complex file.txt`.
- In `xfade` custom expressions never use `st()/ld()` — slice threads share the registers (rainbow streaks).
- Pixel analysis: decode with `-f rawvideo -pix_fmt rgb24|gray` into Node and measure (ink bounds, envelopes,
  cross-correlation) — faster and more reliable than eyeballing.

## Studio for the user
- `assets/templates/Open-Studio.cmd` → `npx hyperframes@<pin> preview --port 3003`; the user double-clicks it.
- Keep playback light: 3 audio stems, display-sized WebP, alpha videos at display size, no heavy SVG filters.
