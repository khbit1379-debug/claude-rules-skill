# Animated reels from a script

Learned on the Abish product reels: a keto protein-bar teaser (colourful → kraft paper → 15 s and 25 s cuts), a
charcoal "hand draws everything" reel, and a painterly 10-scene educational reel.

## Order of work (agreed with the user)
1. The user gives: style reference, script, usually their own voice-over, CTA.
2. Claude delivers the **storyboard and every image in one pass** — `STORYBOARD.md` + `storyboard.html` with the
   real images, each frame timed to the VO lines. Stop and wait for review.
3. Only then animate. Reworking scenes after animation is the expensive path.
4. For an unfamiliar look, approve one style test (or scene 1) before producing the set.

## Script and claims
- Keep the user's words. Never add a tagline they didn't write (a «پر از پروتئین… خالی از بهونه» line was
  rejected). Educational ≠ story: when they ask for educational, teach; when they ask for a story, tell one.
- Every product claim must match the label; "gluten-free" or "no sugar" claims need the ingredient list to back
  them. Ask when unsure.
- Size the script to the length: a TTS voice reads ~1.7 words/s in Persian; the user's natural pace is faster.

## Styles that worked (each chosen from the user's reference)
- **Kraft/illustrated paper** — cut-out objects on kraft, legible ink infographics. Never draw pointers that point
  at nothing.
- **Gritty graphic-novel** — AI illustration with dark grade, ink lines, grain (user rejected flat vector + solid
  colour blocks).
- **Charcoal, drawn by a hand** — `scripts/ink/`: `inkalpha.cjs` turns drawings into ink+alpha (sits on paper without
  blend modes), `strokeplan.cjs` builds contour + zigzag hatching plans, `lines.cjs` extracts the first pass,
  `paper.cjs` makes deterministic paper, `inject-plans.cjs` inlines plans, `assets/js/charcoal-kit.js` reveals strokes
  with SVG masks while the hand's charcoal tip rides the same paths (MotionPathPlugin).
- **Painterly gouache / dry-brush on tan paper** (from a rooster reference) — use the technique, never copy another
  artist's character.
- **Sticker/pop** — ink borders, hard offset shadows, lime/red accents; see `assets/templates/sticker-kit.css`.

## Images
- Generate through the ElevenLabs connector (image models) or, if the user has ChatGPT Plus, the Codex CLI
  (`scripts/images/codex-gen.ps1`). Free plans hit daily caps after a few images — plan the set.
- Hold consistency with references: one **style bible** image, one **hero character** image, the **real product
  photos**. Pass them to every generation. Nano Banana Pro (gemini-3-pro-image, 2K) ≈ 1.8–3k credits/image; GPT
  Image models are good for rendered text (never Persian text though).
- Keep recurring characters identical by always passing the same head/hero image.
- Cut-outs from white backgrounds: `scripts/images/cutout.cjs in.png outBase [T] [soft] [split] …` (flood fill,
  hole removal, optional splitting of sheets into separate objects).
- Real logos: composite, never generate (`logo-into-pack.cjs`). Display-sized WebP for everything in Studio.

## Motion clips (only where motion matters)
- Veo 3.1 Lite: 4 s, 720p, no audio ≈ 727 credits ≈ $0.13 — cheap for 2–3 shots per reel. Retry once with a
  stricter prompt if it drifts (a take once dropped a prop and changed the outfit).
- Seedance 2.5 and other premium video models only with the user's explicit OK and a count ("two, no more").
- Cut the subject out of a generated clip with a clean-plate difference key when the camera is locked
  (`diffkey.cjs`), scaled to display size as a WebM with alpha.

## Build notes
- One sub-composition per scene; captions as their own track; audio as three premixed stems.
- Keep scenes light: no full-canvas SVG displacement filters, no mix-blend-mode, WebP not 2K PNG.
- When a scene needs a filled gauge/battery, the fill layer must sit **after** (above) the opaque image in the DOM.
- Text inside illustrations: measure centring (persian-text.md) and clearance before showing.
