# ElevenLabs through the Claude connector

The creator uses the ElevenLabs connector for images, video, music, SFX, TTS and Scribe. Everything runs in their
account and costs credits — keep a running tally and report it.

## Habits
- `estimate_only: true` first for anything bigger than a sound effect; `generations_count: 1` unless the user wants
  options.
- Put related generations in one flow (`creative_create_flow`) so they can be wired together and found later.
- Music/SFX/images with parameters: `creative_add_flow_node` (model_parameters such as `duration_seconds`,
  `instrumental`, `prompt_influence`) then `creative_run_flow_nodes`; poll `creative_get_flow_run_status` for the
  media URLs, then download them into the project (these are the user's own generations).
- Never call a generate tool twice to "retry" — that charges again. Poll instead.

## Uploading the user's files
- Some sessions expose `creative_create_asset_upload` + `creative_finalize_asset_upload` (upload bytes yourself).
  When they are missing, tools that need a local file (e.g. `creative_transcribe_audio`) show a **picker**: tell
  the user exactly which file to pick (e.g. the 2 MB `work/audio.mp3` you extracted) and read the result from the
  widget context afterwards. Assets already in the library can be reused with `creative_add_flow_asset_node`.
- Scribe returns plain text through the connector (no word timestamps) — use it for accurate Persian text, and local
  Whisper for timing.

## Uploading local frames for start/end-frame video (learned on the 3D reel)
- `creative_upload_flow_reference` creates an empty image node and a picker; the user must click it and choose the
  file.
  - **One file per picker.** Open the next picker only after the first upload is reported (read it with
    `read_widget_context`).
  - The user may not see the first picker → re-open it, and wire the new node (it replaces the old edge).
  - Tell the user the exact path to pick. Images pasted into the chat do **not** reach ElevenLabs.
- Earlier generations in the same flow (e.g. the photos) can be wired directly, with no upload.
- Wire `start_frame` before `end_frame`, or the connection is refused.
- Seedance clips come back as 720×1280 @ 24 fps for "720p". Conform them with `scripts/video/prep-morph.cjs`
  (download → 1080×1920 @ 30 fps, plus a join-difference check against the frames they must meet).

## Moderation
- gpt-image-2 blocked a prompt describing a child's facial deformity in profile (and probably still charged it).
- Neutral wording plus a reference image passed: "keep his face exactly as in the reference", plus a second
  reference for the pose.

## Rough costs seen (credits)
| Item | Cost |
| --- | --- |
| Nano Banana Pro image, 2K | 1.8–3k |
| Veo 3.1 Lite, 4 s 720p, no audio | ~727 (≈ $0.13) |
| Music v2 | ~15/s (125 s ≈ 1.9k ≈ $0.34) |
| Sound effect 1 s | 3–5 |
| Scribe, 2 min | cheap |
| gpt-image-2, 2K 9:16 medium | ≈ 267 (no ref) · ≈ 502 (1 ref) · ≈ 737 (2 refs) |
| Seedance 2.5, 4 s | 720p ≈ 11.2k · 1080p ≈ 25k (10 s: 28k / 62.6k) |
| Seedance 2.0 Mini, 10 s 720p | ≈ 9.2k |
| Veo 3.1 Lite, 8 s 720p | ≈ 1.45k |
| Music v2, 62 s | ≈ 930 |
| Sound effect 0.6–4 s | 2–13 |
