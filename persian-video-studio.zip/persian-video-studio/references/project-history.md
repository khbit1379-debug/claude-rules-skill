# How these rules were learned (project log)

Read this when a situation looks familiar — the fix is probably here.

## 1 · «کتوبار آبیش» teaser (9:16, keto protein bar)
- Started as a fast, colourful 27.5 s motion-graphics reel in HyperFrames (HTML + GSAP → MP4, Node 22+ and FFmpeg).
- The user disliked the flat vector look → wanted AI-generated, cinematic, illustrated imagery from their reference
  (gritty graphic-novel). Lesson: ask for / follow the style reference; run a style test before a full set; pass
  the real pack photo so packaging stays accurate.
- Free ElevenLabs image cap was hit after ~4 images → used ChatGPT images through the Codex CLI
  (`scripts/images/codex-gen.ps1`); later Codex auth broke (401) — the user must re-login themselves; switch
  provider rather than stall.
- 15 s kraft-paper cut: user approves scene 1 before the rest. Info graphics must be legible (ink on light paper);
  "arrows pointing at nothing" were criticised.
- Music was inaudible: the bed was sparse hits decaying to silence, carved −19 dB under the VO → a continuous bed,
  milder carve, master to −14 LUFS. Check a bed's per-second loudness first.
- 25 s cut: the user rewrote the script; do not add taglines they did not write. Voice casting: a library voice
  was too old, another too teenage → a designed voice. Diacritics made that Persian voice misread; the Latin brand
  spelling fixed the brand name. Claims matched to the label («شکر افزوده نداره»).
- Fonts: the user supplied **Abar** — use it for all Persian text from then on. Boxed text looked off-centre and
  digits clipped → Abar's metrics (ink high); nudge and measure.

## 2 · «مغز و سوخت» (brain fuel, 33 s, charcoal)
- Workflow agreed: storyboard + all images first, animation after approval; the user did all audio themselves.
- Style: black charcoal/ink crosshatching on paper, **a hand holding a charcoal stick draws everything** →
  stroke plans, ink-alpha drawings, SVG mask reveals with the hand tip riding the same paths (`scripts/ink/`,
  `assets/js/charcoal-kit.js`).
- The AI garbled the Persian logo on the pack → asked for an empty oval and composited the real logo.
- A handwritten word touched the man's shirt; the user circled it ("لطفا درست کار کن!!") → lettering only in truly
  empty space, ≥ 80 px, checked until the end of the shot.
- The user added music in Studio (it stretched the root duration) — never overwrite their tracks.

## 3 · «ترن هوایی قند» (GR8 BAR HAPPY, educational, 10 scenes, 30 fps)
- Educational, not a story; painterly gouache style from a reference; exactly 10 scenes; 30 fps delivery.
- TTS (English "Liam" voice via eleven_v3) mispronounced almost every Persian word; the user asked for full
  diacritics; the brand became "Ey-bish" → "Ah-beesh". Then the user sent their own recording → Claude cut the
  retakes and stumbles; the user chose the natural-speed edit and extended the reel to 45 s.
- Images via ElevenLabs (Nano Banana Pro) with style/hero/pack references; cheap motion via Veo 3.1 Lite; the user
  allowed at most two premium video generations and asked to stay economical («اقتصادی»).
- Studio problems: no voice/music, lag → three premixed stems, WebP images, no heavy SVG filters or blend modes,
  and an `Open-Studio.cmd` to open Studio from CMD in their own browser.
- A jump shot lost the legs in the AI matte → clean-plate difference key max'd with the AI matte.
- Typed captions jumped around → the no-jump caption system (one line, zero-width caret, fixed line).

## 4 · «ادیتورت رو اخراج کن» (the creator's own 2-min selfie footage)
- Installed Nate Herk's hyperframes-student-kit (now in `kit/`, MIT).
- Understood the story first (the user tested this). A 3 s then 14.6 s sample before the full piece.
- Curly hair: u2net failed → RVM on the GPU → refine. The user still saw a bad key: white sticker outline and a white
  glow behind the head → removed; then wall showing between curls beside the ear → colour unmixing fixed it.
- «No cuts» — keep stumbles; only the leading silence trimmed. B-roll allowed, the speaker may leave the frame.
  Background removal only for the showcase moment.
- Captions: must sit centred in the pill → pill hugs the text, padding measured.
- Captions/graphics out of sync mid-video → envelope timing had drifted 6 s → local Whisper + alignment + a
  re-timing pass over every graphic, cue and camera move.
- Final: 117.8 s, 30 fps, −14 LUFS, A/V 3 ms, an Instagram copy; spend ≈ $0.36.

## 5 · «جراح فک و صورت دکتر romeo» — 3D surgery reel recreated for a new brand (60 s, music only)
- Brief: "can you make exactly this?" The reference was a doctor's Instagram reel: a child with Crouzon syndrome,
  face scan, a CT-rendered skull, an external distraction device bolting on, the midface advancing, before/after
  photos, and a logo. The user wanted the same for another brand, with the name and logo sent later.
  Kept a `BRAND` slot plus placeholders, and never reused the reference's patient photos or logo.
- Tools: the user ruled out Blender/Cinema 4D, then found Seedance 2.5 1080p too expensive (about 62k credits per
  10 s). Built real 3D in **Three.js inside HyperFrames** for free.
  - Skull: NIH 3D, CC BY, with every bone as a separate mesh.
  - The device was built from code.
  - The 60 s rendered in about 2 min.
- AI photos of the child (gpt-image-2): one front photo first, the rest with it as a reference.
  - A prompt that described the deformity in profile was **blocked**. Neutral wording worked, and so did two
    references (face + pose) for a strict profile.
  - The user noticed a three-quarter "profile" was crooked («کج») → regenerated a strict profile.
  - Small «تصویر نمایشی، ساخته‌شده با هوش مصنوعی» tag on all AI patient photos.
- v1 feedback:
  - The photo → skull crossfade with hologram rings felt abrupt («یهویی»).
  - The user disliked the rings.
  - A hard edge at the neck.
  - The scan SFX was shrill («جیغ»): almost all its energy was above 5 kHz.
- v2 fix: **AI morph clips with start/end frames.**
  - Seedance 2.5 at **720p**, about 11.2k credits each. The user said no to 1080p («از اون گرونه استفاده نکن»).
  - Start frame = the photo; end frame = a clean render of the 3D's first frame.
  - The 3D camera was fitted to the photo's nasion/menton, and the adult skull was warped to child proportions.
  - The joins measured 0.2–0.9/255 mean difference, i.e. invisible.
- The upload picker for local frames was invisible to the user the first time → re-open it. One file per picker.
  Images pasted into chat do not reach ElevenLabs.
- SFX: the user asked for real metal sounds — screws, nut, ratchet, sliding bar, lock clunk. Cue each one so the
  file's peak lands on the visual contact.
- Final score from the user: **7/10** — "good, but not the detail of the original". What would raise it is listed
  in `references/3d-threejs.md` → "Getting closer to a reference's detail".
