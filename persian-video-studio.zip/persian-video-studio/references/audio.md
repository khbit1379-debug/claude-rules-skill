# Voice, music, sound effects, mix

## Voice-over

**Best: the creator's own voice.** They record, you clean it up:
- Transcribe with word times (Whisper), find retakes/stumbles, cut them on word boundaries with short crossfades
  and keep natural breaths; offer a natural-speed and a slightly faster version if the timing is tight; the user
  picks. Timing map of every line → drives the storyboard.
- If they send a DAW mixdown of the camera audio, check its offset by cross-correlation and use it.

**TTS in Persian (ElevenLabs)** — what happened:
- `eleven_v3` speaks Persian; multilingual v2 did not do it well.
- Library/English voices (e.g. "Liam") mispronounce plain Persian: write the script **fully diacritized**
  («پُرشِکَر», «تِرَنِ هَوایی», ezafe kasras). They read slowly (~1.7 words/s).
- A Persian designed voice did the opposite: diacritics made it misread; plain text worked.
- Brand names: test spellings. «آبیش» was read "Abiyash"; Latin "Abish" worked for the Persian voice but became
  "Ey-bish" with an English voice, where "Ah-beesh" worked. Always verify every take with Scribe before using it.
- Voice casting: offer 2–3 voices with a short sample line; this user found one "too old", one "too teenage" before
  a designed voice fit. After many failed takes, the user may prefer to record themselves — accept gracefully.

## Music

- ElevenLabs music v2, instrumental, prompt the mood and "sparse mid-range so speech sits on top", request the
  full length (≈ 15 credits/s; 125 s ≈ $0.34). Generate one take.
- Check per-second loudness: a bed made of sparse hits decayed to silence and was inaudible under the VO; another
  take ended 4 s early. Tempo helps place hits (the reel bed was exactly 100 BPM).
- Duck under the voice with sidechain compression (not a flat −19 dB carve that buries it). Music can *act*: swell it
  when the speaker says the AI "adds the music" (`--swell a,b`).

## Sound effects

- The user wants many, small, cute SFX — never harsh or screechy — and **captions must always make an audible
  typing sound**.
- Starter kit in `assets/sfx/kit` (pops at four pitches, boing, ding, shimmer, stamp, sad-boop, swirl, slide,
  xylophone steps, tick-tock, whoosh, cash register, marker scribble, camera focus beep, paper peel + drop, cartoon
  kick) and typing clicks in `assets/sfx/clicks`. Generate more with ElevenLabs sound effects (≈ 3–5 credits each):
  describe "short, soft, cute, clean, no harsh highs", 0.8–1.6 s.
- Cue list `[name, time, volume]` from the word/visual map: land the audible impact on the visual contact, vary
  pitch for sequences (pop-0.84 → 1.41, xylophone up a scale), let some cuts pass without a whoosh.

- **Mechanical / medical 3D:** the user wanted real metal — screws threading, a nut seating, a ratchet, a bar
  sliding, a lock clunk, a glide while the bone moves, a light-wipe shimmer, a logo hit.
  - Measure each file's peak time (10 ms RMS) and start the cue so the **peak** lands on the visual contact.
  - The screw file's final tick was at 1.1 s, so it starts 1.1 s before the screw seats.
- **Shrill check:** `ffmpeg -af "highpass=f=5000,highpass=f=5000,volumedetect"` vs the plain `volumedetect`. If
  the two means are close, the sound is mostly highs → regenerate with "warm, low, no high frequencies".
- Watch momentary loudness at the start: a 4 s morph whoosh peaking at −9 LUFS (momentary) over a −14 mix was
  too much; keep transition sweeps at about −15…−17.

## Mix and master

```bash
node SKILL_DIR/scripts/audio/mix_stems.cjs --voice assets/audio/voice.wav --end 117.8 --out assets/audio \
     --music assets/audio/music-src.mp3 --cues tools/sfx-cues.json --sfx-dir assets/sfx \
     --typing assets/audio/typing.wav [--swell 63.1,65.0]
# after rendering:
node SKILL_DIR/scripts/audio/master.cjs renders/final.mp4 117.8 --stems assets/audio --lufs -14
```
- **No voice-over** (music-only reel): run `mix_stems.cjs` without `--voice`. The music is not ducked. Aim for
  music ≈ −18 and SFX stem ≈ −19…−21, soften the SFX stem with `treble=g=-4:f=7000`, then `master.cjs` → −14.
- Targets: voice ≈ −16…−18 LUFS, music bed 10–13 LU under it, SFX stem ≈ −23…−26 LUFS.
- The composition places only three `<audio>` elements (voice, music-bed, sfx-mix) — Studio stays smooth. Set each
  `data-duration` to the real file length (the checker warns otherwise).
- HyperFrames' own render mix comes out around −25 LUFS; `master.cjs` re-sums the stems, lifts to −14 LUFS with a
  transparent limiter (≤ −1 dBFS) and remuxes onto the rendered picture.
- Verify A/V sync by cross-correlating the final audio with the source at three points (expect a constant ≈ 3 ms).
- Don't overwrite audio tracks the user added themselves in Studio.
