# Real 3D reels with Three.js (no Blender, no paid video AI)

Built for a 60-second maxillofacial-surgery reel (CT-style skull, external distraction device that bolts on, the
midface moving forward, before/after photos). The user did not want Blender/Cinema 4D, and Seedance 2.5 was too
expensive (≈ 62.6k credits per 10 s at 1080p). Three.js inside HyperFrames rendered the whole 60 s in about 2 minutes
on the creator's RTX GPU and cost nothing. The full working example is in `assets/examples/skull-distraction/`.

## When to pick what

| Need | Use |
| --- | --- |
| Precise mechanical motion (screws turning, parts sliding, bones moving) | **Three.js** — exact and repeatable |
| A real anatomical/product shape | a free 3D model (GLB/STL) loaded in Three.js |
| One organic "wow" shot (a face morphing, liquid, people) | a cheap AI video model (Veo 3.1 Lite ≈ 1.45k credits per 8 s at 720p) |
| Photos that only need depth | 2.5D: AI image + slow camera move |

Price the AI video models with `estimate_only` and show the user a table before choosing.

## Models

- Medical: **NIH 3D** (3d.nih.gov) has CT-derived skulls. "Skull and Eyes – Visible Human Male" (3DPX-020591, CC BY 4.0)
  has every bone as a separate mesh (maxilla, zygomatic, nasal, lacrimal, palatine, vomer, mandible, teeth …), which
  makes surgical moves trivial. Downloading needs the user's OK for the file *and* the site terms. The working URL
  is `https://3d.nih.gov/api/download?submissionId=<submission>&fileIds=<file>`. Read both IDs off the network
  request the Download button makes; the entry ID and the thumbnail endpoints return images, not the model.
- Credit CC BY models in the post caption ("Skull model: NIH 3D – Visible Human Male (CC BY 4.0)").
- Mechanical parts: build them in code from primitives. Use `ExtrudeGeometry` with real holes for plates, a helix
  `TubeGeometry` for screw threads, cylinders for rods, and anodized `MeshPhysicalMaterial` with clearcoat.

## Scene recipe (see `skull-scene.js`)

1. Load the GLB, then **orient it from anatomy**, not by guessing rotations. Build a basis where face = maxilla
   centre − occipital centre and up = parietal − mandible, orthogonalise it, and map face → screen-left and
   crown → up. Then centre on the bounding box.
2. Move bone groups with `group.attach(mesh)` (keeps world placement). The jaw rotates on a pivot near the
   condyle. Find attachment points with a raycast from in front of the face.
3. All motion is a pure function of time: a table `T` of `[start, end]` windows plus easing helpers. Use
   `hf-seek` → `renderAt(t)`. No clocks, no `requestAnimationFrame`.
4. Look: an ACES tone map; a warm key light, a cool rim light and a hemisphere fill; RoomEnvironment PMREM;
   and soft shadows so plates shadow the bone.
   - Add **GTAO** for crevices (radius ≈ 4.5 in model cm).
   - Add a warm split-tone ShaderPass on low-saturation pixels, so shadows go amber like a CT volume render while
     the purple device stays purple.
5. **Determinism:** GTAOPass builds its noise with `Math.random`. Construct it inside a seeded `Math.random`
   override, or different render workers flicker.
6. Register `window.__hf.buildReady[...]` with the load promise. Skip `composer.render()` outside the section's time
   window, because the scene is heavy.
7. Fade in with `toneMappingExposure` 0→1. Do a slow push with a few degrees of yaw. One 30° orbit mid-way
   proves it is real 3D.

## Story beats that worked (60 s, music only)

1. Face scan on the profile photo: a scan line and a wireframe that follows the head silhouette
   (`make-scanmesh.cjs` thresholds the black background).
2. Hologram rings carry the viewer into the 3D skull.
3. In 3D:
   - The problem area glows red, with a label.
   - The device assembles: plate slides in, screws spin in, post drops, arms with wires.
   - Two screwdriver activations; each one moves the bone forward a step.
   - A 30° orbit.
   - "After 4 months", then the device comes out in reverse.
4. Rings carry the viewer back to the photos.
5. Front photo with red dashed guide lines and circles («Exophthalmos»), then the same with green lines
   («Normal eye»).
6. A profile wipe with a light line, AFTER above it and BEFORE below.
7. Before → flash → After.
8. A brand end card.

## AI "patient" photos

- Make one photo first. Make the others with it as a reference, all on a pure black studio background, same shirt.
- The image model **blocked** a prompt that described a child's facial deformity in profile. What worked:
  - neutral wording ("keep his face exactly as in the reference");
  - for a strict profile, two references: the face, plus an existing profile photo for the pose.
- Always add a small «تصویر نمایشی، ساخته‌شده با هوش مصنوعی» tag on AI before/after photos. A clinic ad must not
  pass them off as real results.

## Sound for mechanical 3D

The user wants real metal: screws threading, a nut seating, a ratchet, a bar sliding, a lock clunk, a glide when the
bone moves, a hologram whoosh, a light-wipe shimmer and a logo hit. Generate each 0.6–2.5 s (≈ 2–8 credits). Measure
each file's **peak time** and place the cue so the peak lands on the visual contact (e.g. the screw file's final tick
was at 1.1 s → start it 1.1 s before the screw seats). With no voice, run `mix_stems.cjs` without `--voice`.
Music −18 LUFS, SFX stem ≈ −20, then `master.cjs` to −14.

## Photo <-> 3D transitions (learned the hard way)

- A crossfade + hologram rings between the patient photo and the skull looked cheap. The user called it «یهویی».
  They also disliked the rings, and the photo's neck left a hard edge under the skull.
- What works is a **real morph** made with an AI video model, using **start and end frames**:
  - **Start frame:** the photo (already in the ElevenLabs flow as a generation, so no upload is needed).
  - **End frame:** a clean render of the 3D scene's first frame (no labels or brand; capture it with a temporary
    `display:none` style on the overlays).
  - Seedance 2.5, 4 s, **720p** (about 11.2k credits each). The user rejected 1080p at about 25k each.
  - The morph's last frame equals the live 3D's first frame, so the join is seamless. Do the reverse at the end
    (3D last frame → healed photo).
- **Match the camera to the photo**, not the photo to the camera.
  - Measure soft-tissue nasion and menton on the photo. Move them about 7 mm and 10 mm inside to reach the bone.
  - `fitPose()` solves distance, target and roll so the bone landmarks project there, with 0 px error.
  - Do it at the first and the last tau. Blend those matched poses with the working camera over about 1.5 s.
- **Adult model vs child photo:** an adult skull fitted to a child's face has a far too small vault.
  - Warp it once at load with a smooth field: scale up around the sphenoid, weight 1 in the face and jaw, 0 in the
    vault. `VAULT_SCALE ≈ {x 1.45, y 1.68, z 1.38}` (a tall vault also fits Crouzon).
  - The field is continuous, so there are no gaps at the sutures.
  - Bake the world transforms into the geometry first.
- **Uploading local frames to ElevenLabs:**
  - `creative_upload_flow_reference` shows a picker and the user must pick the file. It takes **one file per
    picker**; open the next one after the first upload is reported.
  - Images pasted into the chat do **not** reach ElevenLabs.
  - The user may not see the first picker: re-open it, and wire the new node (it replaces the old edge on that port).
  - Wire `start_frame` before `end_frame`, or the connection is refused.
- **Check SFX for harshness before the user hears them.**
  - A "scanner" effect had almost all its energy above 5 kHz (`highpass=5000` mean ≈ overall mean) and the user
    called it «جیغ».
  - Regenerate with "warm, low, no high frequencies". Keep a gentle `treble=g=-4:f=7000` on the SFX stem.

## Getting closer to a reference's detail (the user scored v2 7/10: "good, but not the original's detail")

Plan these in **before** building next time, in order of impact:

1. **Better source anatomy.**
   - The NIH Visible Human skull is low-poly (≈ 54k triangles) and adult.
   - Look first for a **paediatric / higher-resolution CT skull** (NIH 3D, MorphoSource, Embodi3D, TCIA
     head-and-neck CT with a CC BY licence).
   - Or segment a public CT yourself: DICOM → marching cubes at full resolution, with pydicom + scikit-image in
     the local venv. Then decimate to about 300–500k triangles. Ask before downloading datasets.
2. **CT volume look instead of a plastic mesh.** The reference is a *volume render*: semi-transparent bone with
   orange/red inner structures visible through the orbits and the nasal cavity.
   - Options: real raymarched volume rendering in Three.js from the CT (`Data3DTexture`, about 256³ in a
     WebGL2 shader).
   - Or fake it on the mesh: two-sided bone with a warm **back-face / thickness shader**, fresnel rim, a cavity
     map baked from AO into vertex colours (amber in the crevices), a fine noise normal map for porous bone texture,
     and slight subsurface.
   - Look-dev against a still of the reference before animating.
3. **Device fidelity.** The reference device is CAD-modelled:
   - real hex nuts and lock nuts;
   - knurled knobs;
   - a threaded rod with crisp threads (a normal map, not tori);
   - twisted wires into bone screws;
   - an anodised purple with **anisotropic** highlights;
   - bevels on every edge.
   Model the parts with bevels (`ExtrudeGeometry` with bevel segments). Add small details: engraved numbers and
   millimetre marks on the rod. Use a real-world scale (cm).
4. **Camera language.** The reference cuts between angles and pushes close.
   - Plan 4–6 shots: a wide establishing shot, a macro on the screw thread entering bone, the driver turning in
     close-up, a ¾ view of the advancement, and a frontal view.
   - Use depth of field (`BokehPass`, deterministic) for macro shots.
   - Use match-cuts between shots instead of one continuous camera.
5. **Labels like a medical film:** thin leader lines from the label to the anatomy, small caps, with the line drawn
   on. Not just a label floating at the side.
6. **More frames of motion per beat:** screws spin *and* push the bone slightly; the osteotomy line glows before
   the segment moves; the gap fills with "new bone" (an emissive mesh growing) during the 4-month step.
7. **AI where it beats code:** organic transitions (morphs) and maybe one hero close-up (Veo 3.1 Lite or
   Seedance 720p). Keep mechanical precision in Three.js.
