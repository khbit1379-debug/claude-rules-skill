# Credits

- **Persian Video Studio** — by **romeo.designs6**. Workflow, rules, Persian typography and caption system, tools in
  `scripts/`, templates in `assets/`, and the sound-effect kit (generated with ElevenLabs for romeo.designs6's projects).
- **kit/** — *hyperframes-student-kit* by **Nate Herk**, MIT License (see `kit/LICENSE`) and the Student Kit Use
  Permission (`kit/licenses/PIPELINE-USE-PERMISSION.txt`). Included unchanged except that the AI Automation Society
  brand files, example projects/videos and the bundled copies of the HyperFrames/GSAP skills were left out. Names,
  handles and figures inside the style-library cards are placeholders — replace them before publishing.
- **HyperFrames** by HeyGen (Apache-2.0) · **GSAP** (its own licence) · **RobustVideoMatting** (GPL-3.0 model weights,
  downloaded by the user, not redistributed) · **faster-whisper** (MIT) / Whisper models (MIT).
- Fonts (Abar) and brand logos are not included.
