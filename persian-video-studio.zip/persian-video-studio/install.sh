#!/usr/bin/env bash
# Installs Persian Video Studio into Claude Code (macOS / Linux). Run from the unzipped folder: bash install.sh
set -e
src="$(cd "$(dirname "$0")" && pwd)"; dst="$HOME/.claude/skills/persian-video-studio"
mkdir -p "$HOME/.claude/skills"
[ "$src" = "$dst" ] || cp -R "$src" "$dst"
echo "Installed to $dst — restart Claude, then ask: «ابزارهای استودیوی فارسی رو چک کن»"
